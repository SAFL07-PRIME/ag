import { Buffer } from "buffer";
import crypto from "crypto";

export const SNAKE_HTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>🐍 Snake Neon</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}
html,body{width:100%;height:100%;overflow:hidden;background:#03010a;font-family:Arial,sans-serif;touch-action:none;user-select:none;-webkit-user-select:none}
#app{max-width:440px;margin:0 auto;padding:6px;height:100vh;display:flex;flex-direction:column;gap:6px}
.hdr{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;border:2px solid rgba(122,255,138,.35);border-radius:14px;background:linear-gradient(145deg,#0a2010,#030a06);box-shadow:0 0 18px rgba(122,255,138,.15),inset 0 1px 0 rgba(255,255,255,.08)}
.title{font:900 15px 'Arial Black';color:#7aff8a;letter-spacing:1px;text-shadow:0 0 12px rgba(122,255,138,.5)}
.title small{display:block;font:700 7px Arial;letter-spacing:2px;color:#5a8a6a;margin-top:2px}
.stats{display:flex;gap:5px;align-items:center}
.st{background:rgba(0,0,0,.5);border:1px solid rgba(122,255,138,.3);border-radius:9px;padding:3px 7px;text-align:center;min-width:44px}
.st i{display:block;font:700 7px Arial;font-style:normal;letter-spacing:1px;color:#5a8a6a}
.st b{font:900 12px 'Arial Black';color:#ffd75e;font-variant-numeric:tabular-nums}
.mbtn{width:32px;height:32px;border:2px solid rgba(122,255,138,.35);border-radius:9px;background:rgba(0,0,0,.5);color:#fff;font-size:14px;cursor:pointer;touch-action:none}
.mbtn:active{filter:brightness(1.6)}
.board{position:relative;flex:1;border:2px solid rgba(122,255,138,.35);border-radius:14px;overflow:hidden;background:#000;box-shadow:0 0 24px rgba(122,255,138,.2),inset 0 0 60px rgba(122,255,138,.05);min-height:0}
canvas{width:100%;height:100%;display:block;touch-action:none}
.pad{display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr;gap:6px;height:120px}
.dbtn{border:2px solid rgba(122,255,138,.4);border-radius:12px;background:linear-gradient(#0d2a18,#051208);color:#a8ffb8;font-size:22px;cursor:pointer;touch-action:none;box-shadow:inset 0 2px rgba(255,255,255,.1),0 3px #031208;display:flex;align-items:center;justify-content:center}
.dbtn:active,.dbtn.held{transform:translateY(2px);background:linear-gradient(#7aff8a,#3aa04a);color:#0a3010;box-shadow:0 0 15px rgba(122,255,138,.6)}
.dbtn.empty{border:none;background:transparent;box-shadow:none;pointer-events:none}
.hint{text-align:center;font:600 9px Arial;color:#5a8a6a;padding:2px 0}
.credit{text-align:center;font:600 8px Arial;color:#3a5a44;padding-bottom:2px}
.credit a{color:#7aff8a;text-decoration:none}
</style>
</head>
<body>
<div id="app">
  <div class="hdr">
    <div class="title">🐍 SNAKE NEON<small id="modeLabel">SANTAI MODE</small></div>
    <div class="stats">
      <div class="st"><i>SCORE</i><b id="scEl">0</b></div>
      <div class="st"><i>BEST</i><b id="bsEl">0</b></div>
      <div class="st"><i>LEN</i><b id="lnEl">3</b></div>
      <button class="mbtn" id="muteB">🔊</button>
    </div>
  </div>
  <div class="board"><canvas id="cv"></canvas></div>
  <div class="pad">
    <div class="dbtn empty"></div>
    <div class="dbtn" id="upB">▲</div>
    <div class="dbtn empty"></div>
    <div class="dbtn" id="leftB">◀</div>
    <div class="dbtn" id="downB">▼</div>
    <div class="dbtn" id="rightB">▶</div>
  </div>
  <div class="hint">🎮 Swipe / D-pad · 🍎 makan · 🛡️ shield · ⭐ bonus · 💎 gem</div>
  <div class="credit">Fitur by: Lynx · <a href="https://whatsapp.com/channel/0029VbCt25oHVvTfEwfLOu1G" target="_blank">WhatsApp Channel</a></div>
</div>
<script>
window.onerror=function(m,s,l){var e=document.querySelector('.hint');if(e){e.textContent='⚠ '+m+' @'+l;e.style.color='#ff7a8a'}};
(function(){
'use strict';
var cv=document.getElementById('cv'),x=cv.getContext('2d');
var scEl=document.getElementById('scEl'),bsEl=document.getElementById('bsEl'),lnEl=document.getElementById('lnEl');
var modeLabel=document.getElementById('modeLabel');
var W=0,H=0,DPR=1;

/* ==================== MODE ==================== */
var MODE='easy'; /* easy | pro */
var MODES={
  easy:{label:'SANTAI MODE', speed:220, speedMin:120, speedStep:0.6, wrap:true, obstacles:false, puEvery:2, combo:360, grid:15},
  pro:{label:'PRO MODE', speed:170, speedMin:70, speedStep:1.1, wrap:false, obstacles:true, puEvery:3, combo:240, grid:17}
};

/* ==================== STATE ==================== */
var COLS=15,ROWS=15,CELL=20,GRID_PX=300;
var state='ready';
var snake,dir,nextDir,food,score=0,best=0;
var tickMs=220,tickAcc=0,last=0;
var frame=0;
var particles=[],floaters=[],shake=0,wflash=0,fflash=0;
var obstacles=[];
var powerup=null,powerupTimer=0;
var comboCount=0,comboTimer=0;
var banner=null;
var wallPass=false,wallPassT=0;
var slowMo=false,slowMoT=0;
var shield=0;
var foodGlowPh=0,headPulse=0;
var deathAnim=null;

try{best=parseInt(localStorage.getItem('snake_best')||'0',10)||0}catch(e){}
try{var savedMode=localStorage.getItem('snake_mode');if(savedMode&&MODES[savedMode])MODE=savedMode}catch(e){}
bsEl.textContent=best;
modeLabel.textContent=MODES[MODE].label;

/* ==================== AUDIO ==================== */
var AC=null,MUTED=false;
try{MUTED=localStorage.getItem('snake_mute')==='1'}catch(e){}
function ac(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return null}}if(AC&&AC.state==='suspended'){try{AC.resume()}catch(e){}}return AC}
function tone(f,d,t,v,at,sl){var a=AC;if(!a||MUTED)return;try{var n=a.currentTime+(at||0),o=a.createOscillator(),g=a.createGain();o.type=t||'square';o.frequency.setValueAtTime(f,n);if(sl)o.frequency.exponentialRampToValueAtTime(sl,n+d);g.gain.setValueAtTime(v||.08,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(a.destination);o.start(n);o.stop(n+d+.03)}catch(e){}}
function noiz(d,v,at,fc){var a=AC;if(!a||MUTED)return;try{var n=a.currentTime+(at||0),len=Math.floor(a.sampleRate*d),b=a.createBuffer(1,len,a.sampleRate),c=b.getChannelData(0),i;for(i=0;i<len;i++)c[i]=Math.random()*2-1;var s=a.createBufferSource(),g=a.createGain(),f=a.createBiquadFilter();s.buffer=b;f.type='lowpass';f.frequency.value=fc||1200;g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);s.connect(f);f.connect(g);g.connect(a.destination);s.start(n);s.stop(n+d+.03)}catch(e){}}

function sEat(){tone(660,.06,'square',.09);tone(880,.09,'square',.08,.04)}
function sBonus(){[880,1047,1319,1568].forEach(function(f,i){tone(f,.1,'triangle',.1,i*.05)})}
function sGem(){[1047,1319,1568,2093,2637].forEach(function(f,i){tone(f,.11,'sine',.1,i*.05)})}
function sDie(){[440,349,262,196,131,98].forEach(function(f,i){tone(f,.22,'sawtooth',.14,i*.13)});noiz(.6,.22,.65,300)}
function sTurn(){tone(500,.02,'square',.03)}
function sLevel(){[523,659,784,1047,1319].forEach(function(f,i){tone(f,.1,'square',.1,i*.06)})}
function sCombo(n){tone(660+n*80,.06,'triangle',.11);tone(990+n*80,.1,'triangle',.09,.04)}
function sWall(){tone(1200,.08,'square',.12,0,600);tone(800,.12,'sine',.1,.06)}
function sSlow(){tone(600,.4,'sine',.1,0,200);tone(400,.5,'triangle',.08,.05,150)}
function sShield(){[659,784,1047].forEach(function(f,i){tone(f,.1,'triangle',.11,i*.06)})}
function sShieldBreak(){noiz(.3,.25,0,900);[600,400,300].forEach(function(f,i){tone(f,.15,'sawtooth',.13,i*.08)})}

/* ==================== RESIZE ==================== */
function resize(){
  var box=cv.parentElement.getBoundingClientRect();
  W=box.width|0;H=box.height|0;
  if(W<=0||H<=0){W=340;H=340}
  DPR=Math.min(window.devicePixelRatio||1,2);
  cv.width=W*DPR;cv.height=H*DPR;
  cv.style.width=W+'px';cv.style.height=H+'px';
  x.setTransform(DPR,0,0,DPR,0,0);
  CELL=Math.floor(Math.min(W,H)/COLS);
  GRID_PX=CELL*COLS;
}
window.addEventListener('resize',resize);
window.addEventListener('orientationchange',function(){setTimeout(resize,200)});

/* ==================== SNAKE ==================== */
function applyMode(){
  var m=MODES[MODE];
  COLS=m.grid;ROWS=m.grid;
  modeLabel.textContent=m.label;
  try{localStorage.setItem('snake_mode',MODE)}catch(e){}
  resize();
  reset();
}
function reset(){
  var m=MODES[MODE];
  var cx=(COLS/2)|0,cy=(ROWS/2)|0;
  snake=[{x:cx,y:cy},{x:cx-1,y:cy},{x:cx-2,y:cy}];
  dir={x:1,y:0};nextDir={x:1,y:0};
  score=0;tickMs=m.speed;tickAcc=0;
  obstacles=[];particles=[];floaters=[];deathAnim=null;
  powerup=null;powerupTimer=0;comboCount=0;comboTimer=0;
  wallPass=false;wallPassT=0;slowMo=false;slowMoT=0;
  shield=0;
  spawnFood();
  updateHUD();
}
function updateHUD(){
  scEl.textContent=score;lnEl.textContent=snake.length;
  bsEl.textContent=best;
}
function spawnFood(){
  var tries=0;
  while(tries<300){
    var fx=(Math.random()*COLS)|0,fy=(Math.random()*ROWS)|0;
    if(!occupied(fx,fy)){food={x:fx,y:fy,ph:Math.random()*6};return}
    tries++;
  }
  food={x:0,y:0,ph:0};
}
function occupied(fx,fy){
  for(var i=0;i<snake.length;i++)if(snake[i].x===fx&&snake[i].y===fy)return true;
  for(var j=0;j<obstacles.length;j++)if(obstacles[j].x===fx&&obstacles[j].y===fy)return true;
  if(powerup&&powerup.x===fx&&powerup.y===fy)return true;
  if(food&&food.x===fx&&food.y===fy)return true;
  return false;
}
function spawnPowerup(){
  var types=['star','gem','wall','slow','shield'];
  /* weight: shield lebih sering di easy */
  var weights=MODE==='easy'?[3,1,2,2,4]:[3,2,2,2,1];
  var pool=[];
  for(var w=0;w<types.length;w++){
    for(var c=0;c<weights[w];c++)pool.push(types[w]);
  }
  var t=pool[(Math.random()*pool.length)|0];
  var tries=0;
  while(tries<300){
    var px=(Math.random()*COLS)|0,py=(Math.random()*ROWS)|0;
    if(!occupied(px,py)){
      powerup={x:px,y:py,type:t,ph:0};powerupTimer=1000;return;
    }
    tries++;
  }
}
function spawnObstacles(){
  if(!MODES[MODE].obstacles)return;
  var n=Math.min(2+((score/300)|0),6);
  obstacles=[];
  var tries=0;
  while(obstacles.length<n&&tries<300){
    var ox=(Math.random()*COLS)|0,oy=(Math.random()*ROWS)|0;
    var head=snake[0];
    if(Math.abs(ox-head.x)<3&&Math.abs(oy-head.y)<3){tries++;continue}
    if(!occupied(ox,oy)){obstacles.push({x:ox,y:oy,ph:Math.random()*6})}
    tries++;
  }
}

/* ==================== MOVEMENT ==================== */
function setDir(nx,ny){
  if(state!=='play')return;
  if(dir.x===nx&&dir.y===ny)return;
  if(dir.x===-nx&&dir.y===-ny)return;
  nextDir={x:nx,y:ny};
  sTurn();
}
function step(){
  dir=nextDir;
  var head=snake[0];
  var nx=head.x+dir.x,ny=head.y+dir.y;
  var m=MODES[MODE];
  /* wall handling */
  if(nx<0||nx>=COLS||ny<0||ny>=ROWS){
    if(m.wrap||wallPass){
      nx=(nx+COLS)%COLS;ny=(ny+ROWS)%ROWS;
      if(!m.wrap&&wallPass){
        /* consume wall pass tiap 3 kali wrap? bukan, biarin */
      }
    }else{
      /* coba pakai shield */
      if(shield>0){
        shield--;sShieldBreak();
        burst(head.x,head.y,20,'#7ae6ff');
        banner={t:0,txt:'🛡️ SHIELD PECAH!'};
        /* paksa balik arah */
        nx=head.x-dir.x;ny=head.y-dir.y;
        dir={x:-dir.x,y:-dir.y};nextDir=dir;
        if(nx<0||nx>=COLS||ny<0||ny>=ROWS){die('wall');return}
      }else{
        die('wall');return;
      }
    }
  }
  /* self collision - EASY: hanya cek kalau panjang > 5 */
  var checkSelf=snake.length>5||MODE==='pro';
  if(checkSelf){
    for(var i=0;i<snake.length-1;i++){
      if(snake[i].x===nx&&snake[i].y===ny){
        if(shield>0){
          shield--;sShieldBreak();
          burst(nx,ny,20,'#7ae6ff');
          banner={t:0,txt:'🛡️ SHIELD PECAH!'};
          snake.pop();
          break;
        }else{die('self');return}
      }
    }
  }
  /* obstacle collision */
  for(var j=0;j<obstacles.length;j++){
    if(obstacles[j].x===nx&&obstacles[j].y===ny){
      if(shield>0){
        shield--;sShieldBreak();
        burst(nx,ny,20,'#7ae6ff');
        banner={t:0,txt:'🛡️ SHIELD PECAH!'};
        obstacles.splice(j,1);
        break;
      }else{die('obstacle');return}
    }
  }
  snake.unshift({x:nx,y:ny});
  headPulse=1;
  if(nx===food.x&&ny===food.y){
    eatFood();
  }else{
    snake.pop();
  }
  if(powerup&&nx===powerup.x&&ny===powerup.y){
    pickupPowerup();
  }
  updateHUD();
}

function eatFood(){
  score+=10;
  comboCount++;comboTimer=MODES[MODE].combo;
  if(comboCount>1){
    var bonus=comboCount*2;
    score+=bonus;
    floater(snake[0].x,snake[0].y,'x'+comboCount,'#ffd75e');
    sCombo(comboCount);
  }else sEat();
  burst(snake[0].x,snake[0].y,8,'#ff5577');
  /* speed up gently */
  var m=MODES[MODE];
  if(tickMs>m.speedMin)tickMs-=m.speedStep;
  /* spawn obstacles setiap 5 makanan (pro only) */
  if(m.obstacles&&(snake.length-3)%5===0&&snake.length>5)spawnObstacles();
  /* spawn powerup */
  if(snake.length%m.puEvery===0)spawnPowerup();
  spawnFood();
  if(score>=500&&score-10<500){banner={t:0,txt:'500 PTS!'};sLevel()}
  if(score>=2000&&score-10<2000){banner={t:0,txt:'2000 PTS!'};sLevel();wflash=.4}
  fflash=.3;
}

function pickupPowerup(){
  var t=powerup.type;
  if(t==='star'){
    score+=50;floater(powerup.x,powerup.y,'+50','#ffd75e');
    sBonus();
    for(var i=0;i<5;i++)snake.push({x:snake[snake.length-1].x,y:snake[snake.length-1].y});
    banner={t:0,txt:'⭐ BONUS +50'};
  }else if(t==='gem'){
    score+=150;floater(powerup.x,powerup.y,'+150','#7ae6ff');
    sGem();wflash=.6;
    for(var j=0;j<7;j++)snake.push({x:snake[snake.length-1].x,y:snake[snake.length-1].y});
    banner={t:0,txt:'💎 GEM +150'};
  }else if(t==='wall'){
    wallPass=true;wallPassT=600;
    sWall();banner={t:0,txt:'🌐 WALL PASS!'};
  }else if(t==='slow'){
    slowMo=true;slowMoT=360;
    sSlow();banner={t:0,txt:'🐢 SLOW MOTION!'};
  }else if(t==='shield'){
    shield=Math.min(3,shield+1);
    sShield();banner={t:0,txt:'🛡️ SHIELD +1'};
  }
  burst(powerup.x,powerup.y,14,'#7ae6ff');
  powerup=null;powerupTimer=0;
  updateHUD();
}

function die(reason){
  state='dead';
  sDie();shake=18;fflash=1;
  if(score>best){best=score;try{localStorage.setItem('snake_best',String(best))}catch(e){}}
  updateHUD();
  deathAnim={t:0,reason:reason};
  var head=snake[0];
  burst(head.x,head.y,30,'#ff5577');
}

/* ==================== FX ==================== */
function burst(cx,cy,n,c){
  for(var i=0;i<n;i++){
    var a=Math.random()*6.283,sp=1+Math.random()*4;
    particles.push({x:cx*CELL+CELL/2,y:cy*CELL+CELL/2,
      vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,
      life:1,c:c,s:2+Math.random()*3});
  }
}
function floater(cx,cy,txt,c){
  floaters.push({x:cx*CELL+CELL/2,y:cy*CELL+CELL/2,txt:txt,c:c,t:1});
}

/* ==================== UPDATE ==================== */
function update(dt){
  frame++;
  shake=Math.max(0,shake-.5);
  wflash=Math.max(0,wflash-.04);
  fflash=Math.max(0,fflash-.05);
  headPulse=Math.max(0,headPulse-.05);
  foodGlowPh+=dt*4;

  for(var i=particles.length-1;i>=0;i--){
    var p=particles[i];
    p.x+=p.vx;p.y+=p.vy;p.vx*=.94;p.vy*=.94;
    if((p.life-=.03)<=0)particles.splice(i,1);
  }
  for(i=floaters.length-1;i>=0;i--){
    var f=floaters[i];f.y-=1;if((f.t-=.025)<=0)floaters.splice(i,1);
  }
  if(banner){banner.t+=dt;if(banner.t>1.4)banner=null}
  if(comboTimer>0){comboTimer--;if(comboTimer<=0)comboCount=0}
  if(wallPassT>0){wallPassT--;if(wallPassT<=0)wallPass=false}
  if(slowMoT>0){slowMoT--;if(slowMoT<=0)slowMo=false}
  if(powerup){powerup.ph+=.15;powerupTimer--;if(powerupTimer<=0)powerup=null}
  if(deathAnim){deathAnim.t+=dt}

  if(state==='play'){
    var tMul=slowMo?2.5:1;
    tickAcc+=dt*1000;
    if(tickAcc>=tickMs*tMul){
      tickAcc=0;
      step();
    }
  }
}

/* ==================== DRAW ==================== */
function drawBoard(){
  x.fillStyle='#02040a';
  x.fillRect(0,0,W,H);
  var ox=(W-GRID_PX)/2,oy=(H-GRID_PX)/2;
  x.save();x.translate(ox,oy);

  /* grid */
  x.strokeStyle='rgba(122,255,138,.05)';x.lineWidth=1;
  for(var i=0;i<=COLS;i++){
    x.beginPath();x.moveTo(i*CELL,0);x.lineTo(i*CELL,GRID_PX);x.stroke();
    x.beginPath();x.moveTo(0,i*CELL);x.lineTo(GRID_PX,i*CELL);x.stroke();
  }
  /* border */
  var borderCol=wallPass||MODES[MODE].wrap?'rgba(200,107,255,.7)':'rgba(122,255,138,.6)';
  x.strokeStyle=borderCol;x.lineWidth=2;
  x.strokeRect(1,1,GRID_PX-2,GRID_PX-2);

  /* obstacles */
  for(i=0;i<obstacles.length;i++){
    var o=obstacles[i];
    var obx=o.x*CELL,oby=o.y*CELL;
    var pulse=.5+.5*Math.sin(frame*.15+o.ph);
    x.fillStyle='rgba(80,80,100,.9)';
    x.fillRect(obx+1,oby+1,CELL-2,CELL-2);
    x.fillStyle='rgba(200,200,220,'+(0.4+pulse*0.4)+')';
    x.fillRect(obx+2,oby+2,CELL-4,CELL-4);
    x.strokeStyle='rgba(255,255,255,.3)';x.lineWidth=1;
    x.strokeRect(obx+1.5,oby+1.5,CELL-3,CELL-3);
  }

  /* food */
  if(food){
    var fx=food.x*CELL+CELL/2,fy=food.y*CELL+CELL/2;
    var pulse2=1+Math.sin(foodGlowPh+food.ph)*0.15;
    var fg=x.createRadialGradient(fx,fy,2,fx,fy,CELL*1.2*pulse2);
    fg.addColorStop(0,'rgba(255,60,100,.7)');
    fg.addColorStop(1,'rgba(255,60,100,0)');
    x.fillStyle=fg;x.beginPath();x.arc(fx,fy,CELL*1.2*pulse2,0,7);x.fill();
    x.fillStyle='#ff3355';
    x.beginPath();x.arc(fx,fy,CELL*.35*pulse2,0,7);x.fill();
    x.fillStyle='#ff8aa0';
    x.beginPath();x.arc(fx-CELL*.1,fy-CELL*.1,CELL*.12,0,7);x.fill();
    x.fillStyle='#3a8a3a';
    x.fillRect(fx-1,fy-CELL*.45,2,CELL*.15);
    x.fillStyle='#5ac85a';
    x.beginPath();x.ellipse(fx+CELL*.15,fy-CELL*.38,CELL*.12,CELL*.06,-.5,0,7);x.fill();
  }

  /* powerup */
  if(powerup){
    var px=powerup.x*CELL+CELL/2,py=powerup.y*CELL+CELL/2;
    var pp=1+Math.sin(powerup.ph*2)*0.15;
    var col='#ffd75e',sym='⭐';
    if(powerup.type==='gem'){col='#7ae6ff';sym='💎'}
    else if(powerup.type==='wall'){col='#c86bff';sym='🌐'}
    else if(powerup.type==='slow'){col='#7aff8a';sym='🐢'}
    else if(powerup.type==='shield'){col='#a8e0ff';sym='🛡️'}
    x.globalAlpha=.25;x.fillStyle=col;
    x.beginPath();x.arc(px,py,CELL*.75*pp,0,7);x.fill();
    x.globalAlpha=1;
    x.font=Math.max(12,CELL*.8)+'px Arial';
    x.textAlign='center';x.textBaseline='middle';
    x.fillText(sym,px,py);
  }

  /* snake */
  for(var si=snake.length-1;si>=0;si--){
    var seg=snake[si];
    var sx=seg.x*CELL,sy=seg.y*CELL;
    var isHead=si===0;
    var t=si/snake.length;
    var r=Math.floor(122-t*40),g=Math.floor(255-t*80),b=Math.floor(138-t*40);
    if(isHead){
      var hg=x.createRadialGradient(sx+CELL/2,sy+CELL/2,2,sx+CELL/2,sy+CELL/2,CELL*1.3);
      hg.addColorStop(0,'rgba(122,255,138,.8)');
      hg.addColorStop(1,'rgba(122,255,138,0)');
      x.fillStyle=hg;
      x.beginPath();x.arc(sx+CELL/2,sy+CELL/2,CELL*1.3,0,7);x.fill();
      x.fillStyle='rgb(200,255,210)';
    }else{
      x.fillStyle='rgb('+r+','+g+','+b+')';
    }
    var pad=isHead?1:2;
    var pulseHead=isHead?headPulse*.15:0;
    var size=CELL-pad*2+pulseHead*CELL;
    var offset=(CELL-size)/2;
    roundRect(sx+offset,sy+offset,size,size,isHead?5:3);
    x.fill();
    if(!isHead){
      x.fillStyle='rgba(255,255,255,.15)';
      roundRect(sx+offset+1,sy+offset+1,size-2,Math.max(1,size*.3),2);x.fill();
    }
    if(isHead){
      var eyeOff=CELL*.22;
      var ex1=sx+CELL/2+dir.x*eyeOff+(dir.x===0?-eyeOff:0);
      var ey1=sy+CELL/2+dir.y*eyeOff+(dir.y===0?-eyeOff:0);
      var ex2=sx+CELL/2+dir.x*eyeOff+(dir.x===0?eyeOff:0);
      var ey2=sy+CELL/2+dir.y*eyeOff+(dir.y===0?eyeOff:0);
      x.fillStyle='#fff';
      x.beginPath();x.arc(ex1,ey1,CELL*.13,0,7);x.fill();
      x.beginPath();x.arc(ex2,ey2,CELL*.13,0,7);x.fill();
      x.fillStyle='#0a1538';
      x.beginPath();x.arc(ex1+dir.x*CELL*.05,ey1+dir.y*CELL*.05,CELL*.07,0,7);x.fill();
      x.beginPath();x.arc(ex2+dir.x*CELL*.05,ey2+dir.y*CELL*.05,CELL*.07,0,7);x.fill();
    }
  }

  /* particles */
  for(i=0;i<particles.length;i++){
    var p2=particles[i];
    x.globalAlpha=Math.max(p2.life,0);
    x.fillStyle=p2.c;
    x.fillRect(p2.x-p2.s/2,p2.y-p2.s/2,p2.s,p2.s);
  }
  x.globalAlpha=1;
  for(i=0;i<floaters.length;i++){
    var f2=floaters[i];
    x.globalAlpha=Math.max(f2.t,0);
    x.font='900 14px Arial';x.textAlign='center';
    x.lineWidth=3;x.strokeStyle='rgba(0,0,0,.8)';x.strokeText(f2.txt,f2.x,f2.y);
    x.fillStyle=f2.c;x.fillText(f2.txt,f2.x,f2.y);
  }
  x.globalAlpha=1;x.textAlign='left';

  if(wallPass){
    x.strokeStyle='rgba(200,107,255,'+(0.5+0.4*Math.sin(frame*.2))+')';
    x.lineWidth=4;
    x.strokeRect(2,2,GRID_PX-4,GRID_PX-4);
  }
  if(slowMo){
    x.fillStyle='rgba(122,255,138,.08)';
    x.fillRect(0,0,GRID_PX,GRID_PX);
  }
  x.restore();

  /* shield indicator */
  if(shield>0){
    for(var sh=0;sh<shield;sh++){
      var shx=14+sh*26,shy=14;
      x.fillStyle='rgba(168,224,255,.2)';
      x.beginPath();x.arc(shx,shy,11,0,7);x.fill();
      x.font='16px Arial';x.textAlign='center';x.textBaseline='middle';
      x.fillText('🛡️',shx,shy+1);
    }
    x.textAlign='left';
  }

  /* banner */
  if(banner){
    var bt=banner.t,k=Math.min(bt*4,1),al=bt>1?(1.4-bt)/.4:1,sc=1+(1-k)*.5;
    x.save();x.translate(W/2,H*0.35);x.scale(sc,sc);x.globalAlpha=Math.max(0,al*k);
    x.font='900 20px Arial';x.textAlign='center';
    x.lineWidth=5;x.strokeStyle='rgba(0,0,0,.9)';x.strokeText(banner.txt,0,0);
    var bg=x.createLinearGradient(0,-16,0,8);
    bg.addColorStop(0,'#fff3b0');bg.addColorStop(.5,'#ffd75e');bg.addColorStop(1,'#ff9a3c');
    x.fillStyle=bg;x.fillText(banner.txt,0,0);
    x.restore();x.globalAlpha=1;x.textAlign='left';
  }

  if(comboCount>1&&state==='play'){
    x.font='900 14px Arial';x.textAlign='center';
    var ca=Math.min(1,comboTimer/60);
    x.globalAlpha=ca;
    x.lineWidth=3;x.strokeStyle='rgba(0,0,0,.8)';
    x.strokeText('🔥 x'+comboCount,GRID_PX-60,26);
    x.fillStyle='#ffd75e';
    x.fillText('🔥 x'+comboCount,GRID_PX-60,26);
    x.globalAlpha=1;x.textAlign='left';
  }

  /* overlays */
  if(state==='ready'){
    x.fillStyle='rgba(2,4,10,.8)';x.fillRect(0,0,W,H);
    x.textAlign='center';
    x.font='900 30px Arial';x.lineWidth=6;x.strokeStyle='rgba(0,0,0,.9)';
    x.strokeText('🐍 SNAKE',W/2,H*0.22);
    var tg=x.createLinearGradient(0,H*0.19-20,0,H*0.25+10);
    tg.addColorStop(0,'#c8ffd0');tg.addColorStop(.5,'#7aff8a');tg.addColorStop(1,'#3aa04a');
    x.fillStyle=tg;x.fillText('🐍 SNAKE',W/2,H*0.22);

    /* mode buttons */
    var bw=100,bh=34;
    var by=H*0.32;
    var gap=10;
    var cx1=W/2-bw-gap/2,cx2=W/2+gap/2;
    /* EASY button */
    ctxFill=cx1;ctxRoundedButton(cx1,by,bw,bh,MODE==='easy','#7aff8a','SANTAI');
    ctxRoundedButton(cx2,by,bw,bh,MODE==='pro','#ff9a3c','PRO');

    x.font='600 10px Arial';x.fillStyle='#a8ffb8';
    x.fillText('🎮 Swipe / Arrow / D-pad',W/2,H*0.48);
    x.fillText('🍎 makan · 🛡️ shield · ⭐ bonus · 💎 gem',W/2,H*0.51);
    x.fillText('🌐 wall pass · 🐢 slow motion',W/2,H*0.54);
    x.fillText('🔥 combo = score gede!',W/2,H*0.57);

    if(best>0){
      x.font='900 12px Arial';x.fillStyle='#ffd75e';
      x.fillText('🏆 BEST: '+best,W/2,H*0.64);
    }

    x.font='900 15px Arial';
    x.fillStyle='rgba(255,255,255,'+(.55+.45*Math.sin(frame*.09))+')';
    x.fillText('TAP UNTUK MULAI',W/2,H*0.74);
    x.textAlign='left';
  }

  if(state==='dead'&&deathAnim){
    x.fillStyle='rgba(2,4,10,.82)';x.fillRect(0,0,W,H);
    x.textAlign='center';
    x.font='900 28px Arial';x.lineWidth=6;x.strokeStyle='rgba(0,0,0,.9)';
    x.strokeText('GAME OVER',W/2,H*0.32);
    var dg=x.createLinearGradient(0,H*0.28-20,0,H*0.33+10);
    dg.addColorStop(0,'#ff8aa0');dg.addColorStop(1,'#d61f3e');
    x.fillStyle=dg;x.fillText('GAME OVER',W/2,H*0.32);

    x.font='900 13px Arial';x.fillStyle='#eaf2ff';
    x.fillText('SCORE: '+score,W/2,H*0.40);
    x.fillText('LENGTH: '+snake.length,W/2,H*0.44);

    var reason='💥';
    if(deathAnim.reason==='wall')reason='🧱 NABRAK DINDING';
    else if(deathAnim.reason==='self')reason='🐍 GIGIT DIRI SENDIRI';
    else if(deathAnim.reason==='obstacle')reason='🪨 NABRAK BATU';
    x.font='700 11px Arial';x.fillStyle='#a8b8d0';
    x.fillText(reason,W/2,H*0.50);

    if(score>=best&&score>0){
      x.font='900 14px Arial';
      x.fillStyle='rgba(255,215,94,'+(.6+.4*Math.sin(frame*.2))+')';
      x.fillText('★ NEW BEST! ★',W/2,H*0.56);
    }else if(best>0){
      x.font='700 11px Arial';x.fillStyle='#ffd75e';
      x.fillText('BEST: '+best,W/2,H*0.56);
    }

    if(deathAnim.t>0.8){
      x.font='900 14px Arial';
      x.fillStyle='rgba(255,255,255,'+(.55+.45*Math.sin(frame*.09))+')';
      x.fillText('TAP UNTUK COBA LAGI',W/2,H*0.66);
      x.font='700 9px Arial';x.fillStyle='#7aff8a';
      x.fillText('(tap kanan atas = ganti mode)',W/2,H*0.71);
    }
    x.textAlign='left';
  }
}

function ctxRoundedButton(bx,by,bw,bh,active,color,label){
  /* bg */
  x.fillStyle=active?color:'rgba(0,0,0,.5)';
  roundRect(bx,by,bw,bh,10);x.fill();
  x.strokeStyle=color;x.lineWidth=2;
  roundRect(bx,by,bw,bh,10);x.stroke();
  x.font='900 13px Arial';x.textAlign='center';x.textBaseline='middle';
  x.fillStyle=active?'#0a3010':color;
  x.fillText(label,bx+bw/2,by+bh/2);
  x.textBaseline='alphabetic';
}

function roundRect(px,py,w,h,r){
  x.beginPath();
  x.moveTo(px+r,py);
  x.lineTo(px+w-r,py);
  x.quadraticCurveTo(px+w,py,px+w,py+r);
  x.lineTo(px+w,py+h-r);
  x.quadraticCurveTo(px+w,py+h,px+w-r,py+h);
  x.lineTo(px+r,py+h);
  x.quadraticCurveTo(px,py+h,px,py+h-r);
  x.lineTo(px,py+r);
  x.quadraticCurveTo(px,py,px+r,py);
  x.closePath();
}

function draw(){
  x.setTransform(DPR,0,0,DPR,0,0);
  x.save();
  if(shake>0)x.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);
  drawBoard();
  x.restore();
  if(fflash>0){x.fillStyle='rgba(255,80,80,'+(fflash*.3)+')';x.fillRect(0,0,W,H)}
  if(wflash>0){x.fillStyle='rgba(255,255,255,'+(wflash*.25)+')';x.fillRect(0,0,W,H)}
}

/* ==================== LOOP ==================== */
function loop(now){
  requestAnimationFrame(loop);
  var dt=(now-last)/1000;
  if(!(dt>0)||dt>.05)dt=.016;
  last=now;
  update(dt);
  draw();
}

/* ==================== INPUT ==================== */
function start(){
  ac();
  if(state==='ready'||state==='dead'){
    if(state==='dead'&&deathAnim&&deathAnim.t<0.8)return;
    reset();
    state='play';
  }
}

/* swipe */
var touchSX=0,touchSY=0,touchActive=false,swiped=false;
cv.addEventListener('pointerdown',function(e){
  e.preventDefault();
  var rect=cv.getBoundingClientRect();
  var px=(e.clientX-rect.left),py=(e.clientY-rect.top);
  touchSX=e.clientX;touchSY=e.clientY;
  touchActive=true;swiped=false;
  /* tap di tombol mode */
  if(state==='ready'&&py>H*0.30&&py<H*0.38){
    var bw=100,bh=34,by=H*0.32,gap=10;
    var cx1=W/2-bw-gap/2,cx2=W/2+gap/2;
    if(px>=cx1&&px<=cx1+bw){if(MODE!=='easy'){MODE='easy';applyMode();}return}
    if(px>=cx2&&px<=cx2+bw){if(MODE!=='pro'){MODE='pro';applyMode();}return}
  }
  try{cv.setPointerCapture(e.pointerId)}catch(e2){}
});
cv.addEventListener('pointermove',function(e){
  if(!touchActive||swiped)return;
  var dx=e.clientX-touchSX,dy=e.clientY-touchSY;
  var d=Math.hypot(dx,dy);
  if(d>20){
    swiped=true;
    if(Math.abs(dx)>Math.abs(dy)){setDir(dx>0?1:-1,0)}
    else{setDir(0,dy>0?1:-1)}
  }
});
cv.addEventListener('pointerup',function(e){
  if(!touchActive)return;
  touchActive=false;
  if(!swiped){
    /* tap */
    var rect=cv.getBoundingClientRect();
    var py=(e.clientY-rect.top);
    /* skip kalau tap mode button */
    if(state==='ready'&&py>H*0.30&&py<H*0.38)return;
    start();
  }
});
cv.addEventListener('pointercancel',function(){touchActive=false});

/* D-pad */
function bindBtn(id,fn){
  var el=document.getElementById(id);
  el.addEventListener('pointerdown',function(e){
    e.preventDefault();e.stopPropagation();
    ac();
    if(state!=='play'){start();return}
    fn();el.classList.add('held');
    setTimeout(function(){el.classList.remove('held')},150);
  });
}
bindBtn('upB',function(){setDir(0,-1)});
bindBtn('downB',function(){setDir(0,1)});
bindBtn('leftB',function(){setDir(-1,0)});
bindBtn('rightB',function(){setDir(1,0)});

/* keyboard */
document.addEventListener('keydown',function(e){
  ac();
  if(state!=='play'){
    if(e.code==='Space'||e.code==='Enter'){e.preventDefault();start()}
    if(e.code==='Digit1'){MODE='easy';applyMode()}
    if(e.code==='Digit2'){MODE='pro';applyMode()}
    return;
  }
  var k=e.key;
  if(k==='ArrowUp'||k==='w'||k==='W'){e.preventDefault();setDir(0,-1)}
  else if(k==='ArrowDown'||k==='s'||k==='S'){e.preventDefault();setDir(0,1)}
  else if(k==='ArrowLeft'||k==='a'||k==='A'){e.preventDefault();setDir(-1,0)}
  else if(k==='ArrowRight'||k==='d'||k==='D'){e.preventDefault();setDir(1,0)}
});

/* mute */
document.getElementById('muteB').addEventListener('pointerdown',function(e){
  e.preventDefault();e.stopPropagation();
  MUTED=!MUTED;this.textContent=MUTED?'🔇':'🔊';
  try{localStorage.setItem('snake_mute',MUTED?'1':'0')}catch(e2){}
  if(!MUTED)ac();
});
if(MUTED)document.getElementById('muteB').textContent='🔇';

document.addEventListener('contextmenu',function(e){e.preventDefault()});

/* ==================== INIT ==================== */
applyMode();
last=performance.now();
requestAnimationFrame(loop);
})();
</script>
</body>
</html>`;

const SIG = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YcN55YRyad2+ZA==";
const CERT1 = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg";
const CERT2 = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZlXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYvNBkuLoZnQAq4j8yRekrQ==";

export async function snakeHandler(m, sock) {
  try {
    const targetChat = m.chat || m.key?.remoteJid;
    if (!targetChat) return;
    const data = Buffer.from(JSON.stringify({
      __typename: "GenAIUnifiedResponse",
      response_id: "snake-" + crypto.randomUUID(),
      sections: [{ __typename: "GenAIUnifiedResponseSection",
        view_model: { __typename: "GenAISingleLayoutViewModel",
          primitive: { __typename: "GenAIaeacdsnwHtmlPrimitive", payload: SNAKE_HTML, trusted_sources: [] } } }]
    })).toString("base64");
    await sock.relayMessage(targetChat, {
      messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2,
        botMetadata: { messageDisclaimerText: "", botResponseId: crypto.randomUUID(),
          verificationMetadata: { proofs: [{ version: 1, useCase: 1, signature: SIG, certificateChain: [CERT1, CERT2] }] } } },
      botForwardedMessage: { message: { richResponseMessage: { messageType: 1,
        submessages: [{ messageType: 2, messageText: "🐍 Snake Neon" }],
        unifiedResponse: { data },
        contextInfo: { forwardingScore: 1, isForwarded: true,
          forwardedAiBotMessageInfo: { botJid: "867051314767696@bot" }, forwardOrigin: 4 } } } } }, {});
  } catch (err) {
    console.error("[SNAKE ERROR]", err);
    try {
      if (typeof m.reply === "function") await m.reply("❌ Gagal: " + (err?.message || err));
    } catch (e) {}
  }
}

// Format legacyBridge: export default = fungsi handler(m, { conn })
async function handler(m, { conn } = {}) {
  if (!conn?.relayMessage) return m.reply?.("〄 Client tidak support relayMessage().");
  return snakeHandler(m, conn);
}

handler.help = ['snake'];
handler.tags = ['game'];
handler.command = /^(snake|ular|snaken)$/i;

export default handler;

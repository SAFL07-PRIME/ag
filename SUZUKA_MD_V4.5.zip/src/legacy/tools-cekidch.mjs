/*
  Tolong Jangan Pernah Hapus Watermark Ini
  Script By : JazxCode
  Name Script : Interindah - Assistant MD 
  Version : V1.0
  Follow Saluran : https://whatsapp.com/channel/0029VaylUlU77qVT3vDPjv11
*/
// .cekidch — cek ID, nama, followers saluran WhatsApp.
//
//  .cekidch <link saluran>           → lewat link
//  reply post saluran (forward)      → .cekidch   (paling stabil, ID langsung dari post)
//
// Urutan metode (otomatis lanjut ke berikutnya kalau gagal):
//  1. ID dari post saluran yang di-forward + di-reply
//  2. conn.newsletterMetadata('invite', kode)         (bawaan Baileys)
//  3. query langsung ke WhatsApp dengan parsing toleran (cadangan kalau Baileys error "not valid JSON")
//  4. API eksternal — hanya jika env CHANNEL_API_TOKEN diisi
import axios from 'axios'

const API_URL = process.env.CHANNEL_API_URL ||
    'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/metadata-proxy'
const API_TOKEN = process.env.CHANNEL_API_TOKEN || ''
const MEX_METADATA_QUERY_ID = '6563316087068696'

const extractInviteCode = (input = '') => {
    const match = String(input).match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i)
    return match ? match[1] : null
}

const cleanId = (v) => {
    const d = String(v || '').trim().replace('@newsletter', '')
    return /^\d{10,}$/.test(d) ? `${d}@newsletter` : null
}

// cari objek saluran (punya id ...@newsletter) di dalam struktur apa pun
function findNewsletter(o, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 8) return null
    if (typeof o.id === 'string' && (o.id.endsWith('@newsletter') || (o.thread_metadata && /^\d{10,}$/.test(o.id)))) return o
    for (const v of Object.values(o)) {
        const r = findNewsletter(v, depth + 1)
        if (r) return r
    }
    return null
}

// samakan bentuk data dari berbagai sumber → { id, name, followers, role }
function shape(raw) {
    const n = findNewsletter(raw) || raw
    if (!n || typeof n !== 'object') return null
    const id = cleanId(n.id || n.jid)
    if (!id) return null
    const tm = n.thread_metadata || n.threadMetadata || {}
    const name = n.name?.text || (typeof n.name === 'string' ? n.name : '') || tm.name?.text || ''
    const followers = Number(n.subscribers ?? n.subscribers_count ?? tm.subscribers_count ?? n.followers ?? 0) || 0
    const role = String(n.viewer_metadata?.role || n.viewerMetadata?.role || n.role || '').toUpperCase()
    return { id, name, followers, role }
}

// ID saluran dari post yang di-forward (contextInfo.forwardedNewsletterMessageInfo)
function forwardedChannel(q) {
    if (!q) return null
    const nodes = [q.msg, ...(q.message && typeof q.message === 'object' ? Object.values(q.message) : [])]
    for (const n of nodes) {
        const info = n?.contextInfo?.forwardedNewsletterMessageInfo
        const id = cleanId(info?.newsletterJid)
        if (id) return { id, name: info?.newsletterName || '' }
    }
    return null
}

// Query langsung dengan parsing toleran (buang byte sampah sebelum '{')
async function rawInviteLookup(conn, code) {
    if (typeof conn.query !== 'function') throw new Error('conn.query tidak tersedia')
    const tag = typeof conn.generateMessageTag === 'function' ? conn.generateMessageTag() : `cekidch-${Date.now()}`
    const payload = JSON.stringify({
        variables: {
            input: { key: code, type: 'INVITE', view_role: 'GUEST' },
            fetch_viewer_metadata: true,
            fetch_full_image: true,
            fetch_creation_time: true,
        },
    })
    const res = await conn.query({
        tag: 'iq',
        attrs: { id: tag, type: 'get', xmlns: 'w:mex', to: 's.whatsapp.net' },
        content: [{ tag: 'query', attrs: { query_id: MEX_METADATA_QUERY_ID }, content: Buffer.from(payload, 'utf-8') }],
    })
    const child = Array.isArray(res?.content) ? res.content.find((c) => c.tag === 'result') : null
    if (!child?.content) throw new Error('balasan kosong')
    const str = Buffer.from(child.content).toString('utf8')
    console.error('[CEKIDCH] raw preview:', JSON.stringify(str.slice(0, 300)))

    // a) JSON normal (buang byte sampah sebelum '{')
    const start = str.indexOf('{')
    if (start >= 0) {
        try {
            const parsed = shape(JSON.parse(str.slice(start)))
            if (parsed) return parsed
        } catch { /* lanjut ke cadangan */ }
    }

    // b) cadangan: ambil ID langsung dari teks balasan (mis. 120363xxxxxxxxxxx)
    const idMatch = str.match(/(\d{15,20})(?:@newsletter)?/)
    const id = idMatch ? cleanId(idMatch[1]) : null
    if (id) {
        const nameMatch = str.match(/"text"\s*:\s*"([^"]{1,100})"/)
        return { id, name: nameMatch ? nameMatch[1] : '', followers: 0, role: '' }
    }
    throw new Error(`balasan tidak berisi data saluran: ${JSON.stringify(str.slice(0, 80))}`)
}

async function apiLookup(url) {
    if (!API_TOKEN) throw new Error('CHANNEL_API_TOKEN belum diisi')
    const { data } = await axios.get(`${API_URL}?url=${encodeURIComponent(url)}`, {
        headers: {
            Accept: 'application/json, text/plain, */*',
            Authorization: `Bearer ${API_TOKEN}`,
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36',
        },
        timeout: 20000,
    })
    return shape({ id: data?.jid, name: data?.name, followers: data?.followers })
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const input = (text || args?.join(' ') || '').trim()
    const quotedText = m.quoted?.text || ''
    const code = extractInviteCode(input) || extractInviteCode(quotedText)
    const fwd = forwardedChannel(m.quoted)

    if (!code && !fwd) {
        return m.reply(
            `🍌 Kirim link saluran atau reply post saluran yang di-forward!\n\n` +
            `Contoh:\n*${usedPrefix || '.'}${command || 'cekidch'} https://whatsapp.com/channel/xxxxxxxx*\n` +
            `atau forward 1 post saluran ke chat ini, reply, lalu ketik *${usedPrefix || '.'}${command || 'cekidch'}*`
        )
    }

    await m.react('⏳').catch(() => {})
    const url = code ? `https://whatsapp.com/channel/${code}` : ''
    const errors = []
    let info = null

    // 1) forward post → ID langsung, lalu coba lengkapi nama/followers
    if (fwd) {
        info = { id: fwd.id, name: fwd.name, followers: 0, role: '' }
        try {
            const meta = shape(await conn.newsletterMetadata('jid', fwd.id))
            if (meta) info = { ...info, ...meta, name: meta.name || info.name }
        } catch (e) {
            errors.push(`metadata jid: ${e?.message || e}`)
        }
    }

    // 2) bawaan Baileys lewat link
    if (!info && code && typeof conn.newsletterMetadata === 'function') {
        try {
            info = shape(await conn.newsletterMetadata('invite', code))
        } catch (e) {
            errors.push(`newsletterMetadata: ${e?.message || e}`)
        }
    }

    // 3) query langsung, parsing toleran
    if (!info && code) {
        try {
            info = await rawInviteLookup(conn, code)
        } catch (e) {
            errors.push(`raw query: ${e?.message || e}`)
        }
    }

    // 4) API eksternal (opsional)
    if (!info && code && API_TOKEN) {
        try {
            info = await apiLookup(url)
        } catch (e) {
            const st = e?.response?.status
            errors.push(`api: ${st || ''} ${e?.message || e}`)
        }
    }

    if (!info?.id) {
        console.error('[CEKIDCH]', errors.join(' | '))
        await m.react('❌').catch(() => {})
        return m.reply(
            `❌ Gagal ambil ID saluran lewat link (library Baileys error).\n\n` +
            `*Cara pasti berhasil:* forward 1 post dari saluran itu ke chat ini, reply post-nya, lalu ketik *${usedPrefix || '.'}${command || 'cekidch'}*.\n\n` +
            `_Detail: ${errors.join(' | ').slice(0, 400) || '-'}_`
        )
    }

    await m.react('✅').catch(() => {})
    const lines = [
        `*📱 WhatsApp Channel Information*\n`,
        `⌯ *Nama:* ${info.name || 'N/A'}`,
        `⌯ *Followers:* ${info.followers ? info.followers.toLocaleString('id-ID') : 'N/A'}`,
        `⌯ *ID:* ${info.id}`,
    ]
    if (info.role) lines.push(`⌯ *Role bot:* ${info.role}`)
    if (url) lines.push(`⌯ *Link:* ${url}`)
    return m.reply(lines.join('\n'))
}

handler.help = ['cekidch']
handler.tags = ['tools']
handler.command = ['cekidch', 'idch', 'cekchannel']
export default handler

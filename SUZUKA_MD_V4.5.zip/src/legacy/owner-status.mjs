// VPS Status Monitor (owner) — dashboard status server jadi gambar.
// Command: .status / .vpsstatus (khusus owner, dicek di src/commands/owner.js).
// Render gambar memakai puppeteer / playwright kalau terpasang (npm i puppeteer).
// Kalau tidak ada, bot mengirim ringkasan teks + file HTML dashboard.
import os from "os";
import { execSync } from "child_process";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);

/* =========================================================
 *                 VPS STATUS MONITOR V2
 * ========================================================= */

/* ==================== SYSTEM STATS ==================== */

function getSystemStats() {
  /* ---------- CPU ---------- */
  const cpus = os.cpus();
  const cpuModel = cpus[0]?.model || "Unknown CPU";
  const cpuCores = cpus.length || 1;

  const loadAvg = os.loadavg();

  const cpuUsage = Math.min(
    100,
    Math.max(
      0,
      Math.round((loadAvg[0] / cpuCores) * 100)
    )
  );

  /* ---------- RAM ---------- */
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;

  const memPct =
    totalMem > 0
      ? Math.round((usedMem / totalMem) * 100)
      : 0;

  /* ---------- SYSTEM UPTIME ---------- */
  const uptime = os.uptime();

  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);

  /* ---------- OS ---------- */
  const platform = os.platform();
  const arch = os.arch();
  const hostname = os.hostname();
  const osType = os.type();
  const osRelease = os.release();

  /* ---------- DISK ---------- */
  let diskTotal = 0;
  let diskUsed = 0;
  let diskFree = 0;
  let diskPct = 0;

  try {
    const df = execSync(
      "df -B1 / | tail -1",
      {
        encoding: "utf8",
        timeout: 2000
      }
    )
      .trim()
      .split(/\s+/);

    diskTotal = parseInt(df[1]) || 0;
    diskUsed = parseInt(df[2]) || 0;
    diskFree = parseInt(df[3]) || 0;

    diskPct =
      diskTotal > 0
        ? Math.round((diskUsed / diskTotal) * 100)
        : 0;
  } catch {
    diskTotal = 0;
    diskUsed = 0;
    diskFree = 0;
    diskPct = 0;
  }

  /* ---------- PROCESS ---------- */
  let procCount = 0;

  try {
    procCount = parseInt(
      execSync(
        "ps aux | wc -l",
        {
          encoding: "utf8",
          timeout: 2000
        }
      ).trim()
    ) || 0;
  } catch {
    procCount = 0;
  }

  /* ---------- CPU TEMP ---------- */
  let cpuTemp = null;

  try {
    const temp = execSync(
      "cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null",
      {
        encoding: "utf8",
        timeout: 1000
      }
    ).trim();

    if (temp) {
      cpuTemp = Math.round(parseInt(temp) / 1000);
    }
  } catch {}

  /* ---------- NODE ---------- */
  const nodeVer = process.version;
  const botUptime = process.uptime();
  const memProcess = process.memoryUsage();

  return {
    cpuModel,
    cpuCores,
    cpuUsage,
    loadAvg,

    totalMem,
    freeMem,
    usedMem,
    memPct,

    uptime: {
      days,
      hours,
      minutes,
      seconds
    },

    platform,
    arch,
    hostname,
    osType,
    osRelease,

    diskTotal,
    diskUsed,
    diskFree,
    diskPct,

    procCount,
    cpuTemp,

    nodeVer,
    botUptime,

    botMemRSS: memProcess.rss,
    botMemHeap: memProcess.heapUsed,

    timestamp: Date.now()
  };
}

/* ==================== FORMAT ==================== */

function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return "0 B";

  const units = [
    "B",
    "KB",
    "MB",
    "GB",
    "TB"
  ];

  const i = Math.floor(
    Math.log(bytes) / Math.log(1024)
  );

  return (
    (bytes / Math.pow(1024, i)).toFixed(
      i >= 3 ? 2 : 1
    ) +
    " " +
    units[i]
  );
}

function formatUptime(u) {
  return `${u.days}d ${u.hours}h ${u.minutes}m ${u.seconds}s`;
}

function runtime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  return `${d}d ${h}h ${m}m ${s}s`;
}

function getUsageClass(value) {
  if (value >= 85) return "danger";
  if (value >= 65) return "warning";
  return "success";
}

function escapeHTML(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/* =========================================================
 *                      HTML DASHBOARD
 * ========================================================= */

function buildStatusHTML(stats) {
  const cpuClass = getUsageClass(stats.cpuUsage);
  const ramClass = getUsageClass(stats.memPct);
  const diskClass = getUsageClass(stats.diskPct);

  const tempClass =
    stats.cpuTemp === null
      ? "muted"
      : stats.cpuTemp >= 80
        ? "danger"
        : stats.cpuTemp >= 65
          ? "warning"
          : "success";

  const now = new Date(stats.timestamp);

  return `<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">

<meta
  name="viewport"
  content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
>

<title>WELPER VPS Monitor</title>

<style>

/* =====================================================
   RESET
===================================================== */

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  -webkit-tap-highlight-color: transparent;
}

html,
body {
  width: 100%;
  min-height: 100%;
}

body {
  background:
    radial-gradient(
      circle at 50% -10%,
      rgba(0, 183, 255, .14),
      transparent 38%
    ),
    #030711;

  color: #eef7ff;

  font-family:
    Inter,
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Arial,
    sans-serif;

  padding: 10px;

  overflow-x: hidden;
}

/* =====================================================
   APP
===================================================== */

#app {
  width: 100%;
  max-width: 440px;
  margin: auto;

  display: flex;
  flex-direction: column;

  gap: 9px;
}

/* =====================================================
   GLASS
===================================================== */

.glass {
  background:
    linear-gradient(
      145deg,
      rgba(13, 28, 49, .96),
      rgba(4, 9, 19, .98)
    );

  border:
    1px solid rgba(88, 199, 255, .18);

  box-shadow:
    0 12px 35px rgba(0, 0, 0, .35),
    inset 0 1px 0 rgba(255,255,255,.04);

  backdrop-filter: blur(15px);
}

/* =====================================================
   HEADER
===================================================== */

.header {
  position: relative;

  padding: 16px;

  border-radius: 19px;

  overflow: hidden;

  background:
    radial-gradient(
      circle at 100% 0%,
      rgba(0, 204, 255, .16),
      transparent 40%
    ),
    linear-gradient(
      145deg,
      #0a1b31,
      #030711
    );

  border: 1px solid rgba(83, 210, 255, .28);

  box-shadow:
    0 0 35px rgba(0, 190, 255, .08),
    inset 0 1px 0 rgba(255,255,255,.06);
}

.header::before {
  content: "";

  position: absolute;

  left: -30%;
  top: 0;

  width: 160%;
  height: 1px;

  background:
    linear-gradient(
      90deg,
      transparent,
      #56dcff,
      #9c6cff,
      #56dcff,
      transparent
    );

  animation: scan 4s linear infinite;
}

@keyframes scan {
  from {
    transform: translateX(-35%);
  }

  to {
    transform: translateX(35%);
  }
}

.header-main {
  display: flex;
  justify-content: space-between;
  align-items: center;

  gap: 10px;
}

.brand {
  display: flex;
  align-items: center;

  gap: 10px;
}

.server-icon {
  width: 43px;
  height: 43px;

  border-radius: 13px;

  display: flex;
  align-items: center;
  justify-content: center;

  font-size: 22px;

  background:
    linear-gradient(
      145deg,
      #0d75a9,
      #06324d
    );

  border:
    1px solid rgba(93, 222, 255, .35);

  box-shadow:
    0 0 18px rgba(0, 197, 255, .2);
}

.title {
  font-size: 17px;
  font-weight: 950;

  letter-spacing: 1px;

  color: #7ee7ff;

  text-shadow:
    0 0 15px rgba(82, 220, 255, .45);
}

.subtitle {
  margin-top: 3px;

  font-size: 8px;
  font-weight: 800;

  letter-spacing: 2px;

  color: #587493;
}

.online {
  display: flex;
  align-items: center;

  gap: 5px;

  padding: 6px 8px;

  border-radius: 9px;

  background: rgba(73, 255, 139, .07);

  border:
    1px solid rgba(73, 255, 139, .18);

  color: #73ff9a;

  font-size: 8px;
  font-weight: 900;

  letter-spacing: 1px;
}

.online-dot {
  width: 7px;
  height: 7px;

  border-radius: 50%;

  background: #6cff95;

  box-shadow:
    0 0 10px #6cff95;

  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0%,100% {
    opacity: 1;
    transform: scale(1);
  }

  50% {
    opacity: .35;
    transform: scale(.7);
  }
}

.header-bottom {
  display: flex;
  justify-content: space-between;

  margin-top: 13px;

  padding-top: 10px;

  border-top:
    1px solid rgba(255,255,255,.05);
}

.head-stat {
  display: flex;
  align-items: center;

  gap: 5px;

  color: #7894b3;

  font-size: 8px;
  font-weight: 800;
}

.head-stat b {
  color: #dff7ff;
}

/* =====================================================
   GRID
===================================================== */

.grid {
  display: grid;

  grid-template-columns:
    repeat(2, minmax(0, 1fr));

  gap: 9px;
}

/* =====================================================
   CARD
===================================================== */

.card {
  position: relative;

  padding: 13px;

  border-radius: 16px;

  overflow: hidden;

  background:
    linear-gradient(
      145deg,
      rgba(12, 25, 44, .96),
      rgba(3, 8, 17, .98)
    );

  border:
    1px solid rgba(107, 195, 255, .15);

  box-shadow:
    0 8px 25px rgba(0,0,0,.25),
    inset 0 1px 0 rgba(255,255,255,.035);

  transition:
    transform .15s ease,
    border-color .15s ease;
}

.card:active {
  transform: scale(.985);
}

.card::after {
  content: "";

  position: absolute;

  width: 90px;
  height: 90px;

  right: -40px;
  top: -40px;

  border-radius: 50%;

  background:
    rgba(74, 209, 255, .05);

  filter: blur(10px);

  pointer-events: none;
}

.wide {
  grid-column: 1 / -1;
}

/* =====================================================
   CARD HEADER
===================================================== */

.card-head {
  display: flex;
  align-items: center;

  gap: 8px;

  margin-bottom: 11px;
}

.icon {
  width: 29px;
  height: 29px;

  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 9px;

  font-size: 15px;

  background:
    rgba(67, 199, 255, .10);

  border:
    1px solid rgba(84, 213, 255, .18);
}

.card-title {
  font-size: 9px;
  font-weight: 950;

  letter-spacing: 1.5px;

  color: #7d99b8;
}

/* =====================================================
   VALUE
===================================================== */

.value {
  font-size: 25px;
  font-weight: 950;

  line-height: 1;

  color: #ffffff;

  letter-spacing: -.5px;
}

.value small {
  margin-left: 3px;

  font-size: 10px;

  color: #7894b3;

  letter-spacing: 0;
}

/* =====================================================
   BAR
===================================================== */

.bar {
  position: relative;

  width: 100%;
  height: 6px;

  margin-top: 10px;

  border-radius: 99px;

  overflow: hidden;

  background:
    rgba(255,255,255,.06);
}

.fill {
  height: 100%;

  border-radius: inherit;

  position: relative;

  transition: width .6s ease;
}

.fill::after {
  content: "";

  position: absolute;

  inset: 0;

  background:
    linear-gradient(
      90deg,
      transparent,
      rgba(255,255,255,.5),
      transparent
    );

  animation: shine 2s linear infinite;
}

@keyframes shine {
  from {
    transform: translateX(-100%);
  }

  to {
    transform: translateX(100%);
  }
}

.success {
  background:
    linear-gradient(
      90deg,
      #18a653,
      #6cff9a
    );

  box-shadow:
    0 0 10px rgba(75,255,143,.25);
}

.warning {
  background:
    linear-gradient(
      90deg,
      #c58a14,
      #ffd85e
    );

  box-shadow:
    0 0 10px rgba(255,216,94,.25);
}

.danger {
  background:
    linear-gradient(
      90deg,
      #c12b3a,
      #ff6474
    );

  box-shadow:
    0 0 10px rgba(255,74,95,.25);
}

.muted {
  color: #7894b3;
}

/* =====================================================
   CARD FOOT
===================================================== */

.card-foot {
  display: flex;
  justify-content: space-between;

  margin-top: 7px;

  font-size: 8px;
  font-weight: 800;

  color: #587493;
}

.card-foot strong {
  color: #b9d7ef;
}

/* =====================================================
   BIG STORAGE
===================================================== */

.storage-top {
  display: flex;
  justify-content: space-between;

  align-items: flex-end;
}

.storage-percent {
  font-size: 28px;
  font-weight: 950;
}

.storage-percent small {
  font-size: 9px;
  color: #7794b3;
}

/* =====================================================
   MINI STATS
===================================================== */

.mini-grid {
  display: grid;

  grid-template-columns:
    repeat(3, 1fr);

  gap: 6px;

  margin-top: 9px;
}

.mini {
  padding: 8px;

  border-radius: 10px;

  background:
    rgba(0,0,0,.22);

  border:
    1px solid rgba(255,255,255,.035);

  text-align: center;
}

.mini-icon {
  font-size: 14px;
}

.mini-label {
  margin-top: 3px;

  font-size: 7px;
  font-weight: 800;

  color: #56708d;

  letter-spacing: .6px;
}

.mini-value {
  margin-top: 2px;

  font-size: 9px;
  font-weight: 950;

  color: #d9f5ff;
}

/* =====================================================
   SYSTEM ROW
===================================================== */

.rows {
  display: flex;

  flex-direction: column;

  gap: 5px;
}

.row {
  display: flex;

  align-items: center;
  justify-content: space-between;

  gap: 8px;

  min-height: 34px;

  padding: 7px 9px;

  border-radius: 9px;

  background:
    rgba(0,0,0,.24);

  border:
    1px solid rgba(255,255,255,.025);
}

.row-left {
  display: flex;
  align-items: center;

  gap: 7px;

  min-width: 0;
}

.row-icon {
  width: 20px;
  height: 20px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 6px;

  background:
    rgba(86,205,255,.08);

  font-size: 11px;

  flex-shrink: 0;
}

.row-name {
  font-size: 8px;
  font-weight: 900;

  color: #6d89a8;

  letter-spacing: .6px;
}

.row-value {
  max-width: 58%;

  overflow: hidden;

  white-space: nowrap;

  text-overflow: ellipsis;

  text-align: right;

  font-size: 8px;
  font-weight: 900;

  color: #cceeff;
}

/* =====================================================
   PROCESSOR
===================================================== */

.processor-name {
  font-size: 11px;
  font-weight: 950;

  line-height: 1.35;

  color: #f1faff;

  margin-bottom: 9px;
}

.cores {
  display: flex;

  flex-wrap: wrap;

  gap: 4px;
}

.core {
  width: 18px;
  height: 15px;

  border-radius: 4px;

  background:
    rgba(83,193,255,.07);

  border:
    1px solid rgba(83,193,255,.14);

  transition: .3s;
}

.core.active {
  background:
    linear-gradient(
      180deg,
      #63e5ff,
      #19739b
    );

  border-color:
    rgba(99,229,255,.55);

  box-shadow:
    0 0 7px rgba(80,220,255,.3);
}

/* =====================================================
   RUNTIME
===================================================== */

.runtime-main {
  display: grid;

  grid-template-columns:
    repeat(2, 1fr);

  gap: 7px;
}

.runtime-box {
  padding: 10px;

  border-radius: 11px;

  background:
    rgba(0,0,0,.22);

  border:
    1px solid rgba(255,255,255,.035);
}

.runtime-icon {
  font-size: 16px;
}

.runtime-label {
  margin-top: 5px;

  font-size: 7px;

  font-weight: 900;

  color: #5e7897;

  letter-spacing: .7px;
}

.runtime-value {
  margin-top: 2px;

  font-size: 10px;

  font-weight: 950;

  color: #dff8ff;
}

/* =====================================================
   STATUS FOOTER
===================================================== */

.footer {
  text-align: center;

  padding: 9px 5px 5px;

  color: #3e5874;

  font-size: 7px;
  font-weight: 800;

  letter-spacing: 1px;

  line-height: 1.7;
}

.footer b {
  color: #63dfff;
}

/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:340px) {

  body {
    padding: 7px;
  }

  #app {
    gap: 7px;
  }

  .grid {
    gap: 7px;
  }

  .card {
    padding: 11px;
  }

  .value {
    font-size: 21px;
  }

  .server-icon {
    width: 38px;
    height: 38px;
  }

  .title {
    font-size: 14px;
  }
}

</style>
</head>

<body>

<div id="app">

  <!-- =================================================
       HEADER
  ================================================== -->

  <section class="header">

    <div class="header-main">

      <div class="brand">

        <div class="server-icon">
          🖥️
        </div>

        <div>

          <div class="title">
            VPS STATUS
          </div>

          <div class="subtitle">
            REAL-TIME SERVER MONITOR
          </div>

        </div>

      </div>

      <div class="online">
        <span class="online-dot"></span>
        ONLINE
      </div>

    </div>

    <div class="header-bottom">

      <div class="head-stat">
        🕐
        <span>UPTIME</span>
        <b>${formatUptime(stats.uptime)}</b>
      </div>

      <div class="head-stat">
        🧩
        <span>CORES</span>
        <b>${stats.cpuCores}</b>
      </div>

    </div>

  </section>


  <!-- =================================================
       CPU + RAM
  ================================================== -->

  <div class="grid">

    <!-- CPU -->

    <section class="card">

      <div class="card-head">

        <div class="icon">
          ⚡
        </div>

        <div class="card-title">
          CPU USAGE
        </div>

      </div>

      <div class="value">
        ${stats.cpuUsage}<small>%</small>
      </div>

      <div class="bar">

        <div
          class="fill ${cpuClass}"
          style="width:${stats.cpuUsage}%"
        ></div>

      </div>

      <div class="card-foot">
        <span>LOAD</span>
        <strong>${stats.loadAvg[0].toFixed(2)}</strong>
      </div>

    </section>


    <!-- RAM -->

    <section class="card">

      <div class="card-head">

        <div class="icon">
          🧠
        </div>

        <div class="card-title">
          MEMORY
        </div>

      </div>

      <div class="value">
        ${stats.memPct}<small>%</small>
      </div>

      <div class="bar">

        <div
          class="fill ${ramClass}"
          style="width:${stats.memPct}%"
        ></div>

      </div>

      <div class="card-foot">

        <span>USED</span>

        <strong>
          ${formatBytes(stats.usedMem)}
        </strong>

      </div>

    </section>

  </div>


  <!-- =================================================
       DISK
  ================================================== -->

  <section class="card wide">

    <div class="card-head">

      <div class="icon">
        💾
      </div>

      <div class="card-title">
        DISK STORAGE
      </div>

    </div>

    <div class="storage-top">

      <div class="storage-percent">
        ${stats.diskPct}<small>% USED</small>
      </div>

      <div style="
        text-align:right;
        font-size:8px;
        line-height:1.7;
        color:#6885a4;
        font-weight:800;
      ">

        <div>
          🟢 FREE
          <b style="color:#74ff9a">
            ${formatBytes(stats.diskFree)}
          </b>
        </div>

        <div>
          💿 TOTAL
          <b style="color:#cceeff">
            ${formatBytes(stats.diskTotal)}
          </b>
        </div>

      </div>

    </div>

    <div class="bar">

      <div
        class="fill ${diskClass}"
        style="width:${stats.diskPct}%"
      ></div>

    </div>

    <div class="mini-grid">

      <div class="mini">

        <div class="mini-icon">
          📦
        </div>

        <div class="mini-label">
          USED
        </div>

        <div class="mini-value">
          ${formatBytes(stats.diskUsed)}
        </div>

      </div>

      <div class="mini">

        <div class="mini-icon">
          🟢
        </div>

        <div class="mini-label">
          FREE
        </div>

        <div class="mini-value">
          ${formatBytes(stats.diskFree)}
        </div>

      </div>

      <div class="mini">

        <div class="mini-icon">
          💽
        </div>

        <div class="mini-label">
          TOTAL
        </div>

        <div class="mini-value">
          ${formatBytes(stats.diskTotal)}
        </div>

      </div>

    </div>

  </section>


  <!-- =================================================
       SYSTEM INFO
  ================================================== -->

  <section class="card wide">

    <div class="card-head">

      <div class="icon">
        🖥️
      </div>

      <div class="card-title">
        SYSTEM INFORMATION
      </div>

    </div>

    <div class="rows">

      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🏷️
          </div>

          <div class="row-name">
            HOSTNAME
          </div>

        </div>

        <div
          class="row-value"
          style="color:#73ff9a"
        >
          ${escapeHTML(stats.hostname)}
        </div>

      </div>


      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🐧
          </div>

          <div class="row-name">
            OPERATING SYSTEM
          </div>

        </div>

        <div class="row-value">
          ${escapeHTML(stats.osType)}
          ${escapeHTML(stats.osRelease)}
        </div>

      </div>


      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🏗️
          </div>

          <div class="row-name">
            ARCHITECTURE
          </div>

        </div>

        <div
          class="row-value"
          style="color:#ffd85e"
        >
          ${escapeHTML(stats.arch)}
        </div>

      </div>


      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            ⚙️
          </div>

          <div class="row-name">
            PLATFORM
          </div>

        </div>

        <div class="row-value">
          ${escapeHTML(stats.platform)}
        </div>

      </div>


      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🔄
          </div>

          <div class="row-name">
            PROCESSES
          </div>

        </div>

        <div
          class="row-value"
          style="color:#c891ff"
        >
          ${stats.procCount} running
        </div>

      </div>


      ${
        stats.cpuTemp !== null
          ? `
      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🌡️
          </div>

          <div class="row-name">
            CPU TEMPERATURE
          </div>

        </div>

        <div
          class="row-value"
          style="
            color:
              ${
                stats.cpuTemp >= 80
                  ? "#ff6878"
                  : stats.cpuTemp >= 65
                    ? "#ffd85e"
                    : "#73ff9a"
              };
          "
        >
          ${stats.cpuTemp}°C
        </div>

      </div>
      `
          : `
      <div class="row">

        <div class="row-left">

          <div class="row-icon">
            🌡️
          </div>

          <div class="row-name">
            CPU TEMPERATURE
          </div>

        </div>

        <div
          class="row-value"
          style="color:#637d99"
        >
          NOT AVAILABLE
        </div>

      </div>
      `
      }

    </div>

  </section>


  <!-- =================================================
       PROCESSOR
  ================================================== -->

  <section class="card wide">

    <div class="card-head">

      <div class="icon">
        🔥
      </div>

      <div class="card-title">
        PROCESSOR
      </div>

    </div>

    <div class="processor-name">
      ${escapeHTML(stats.cpuModel)}
    </div>

    <div class="cores">

      ${
        Array.from({
          length: Math.min(stats.cpuCores, 64)
        })
          .map((_, i) => {

            const active =
              i <
              Math.round(
                stats.cpuCores *
                stats.cpuUsage /
                100
              );

            return `
              <div
                class="core ${
                  active ? "active" : ""
                }"
              ></div>
            `;

          })
          .join("")
      }

    </div>

    <div class="card-foot">

      <span>
        🧩 ${stats.cpuCores} LOGICAL CORES
      </span>

      <strong>
        ⚡ ${stats.cpuUsage}%
      </strong>

    </div>

    <div
      style="
        margin-top:8px;
        padding-top:8px;
        border-top:1px solid rgba(255,255,255,.04);
        display:flex;
        justify-content:space-between;
        font-size:8px;
        color:#607d9b;
        font-weight:800;
      "
    >

      <span>
        1M
        <b style="color:#cceeff">
          ${stats.loadAvg[0].toFixed(2)}
        </b>
      </span>

      <span>
        5M
        <b style="color:#cceeff">
          ${stats.loadAvg[1].toFixed(2)}
        </b>
      </span>

      <span>
        15M
        <b style="color:#cceeff">
          ${stats.loadAvg[2].toFixed(2)}
        </b>
      </span>

    </div>

  </section>


  <!-- =================================================
       BOT RUNTIME
  ================================================== -->

  <section class="card wide">

    <div class="card-head">

      <div class="icon">
        🤖
      </div>

      <div class="card-title">
        BOT RUNTIME
      </div>

    </div>

    <div class="runtime-main">

      <div class="runtime-box">

        <div class="runtime-icon">
          🟢
        </div>

        <div class="runtime-label">
          NODE.JS
        </div>

        <div class="runtime-value">
          ${escapeHTML(stats.nodeVer)}
        </div>

      </div>


      <div class="runtime-box">

        <div class="runtime-icon">
          ⏱️
        </div>

        <div class="runtime-label">
          BOT UPTIME
        </div>

        <div class="runtime-value">
          ${runtime(stats.botUptime)}
        </div>

      </div>


      <div class="runtime-box">

        <div class="runtime-icon">
          📊
        </div>

        <div class="runtime-label">
          RSS MEMORY
        </div>

        <div class="runtime-value">
          ${formatBytes(stats.botMemRSS)}
        </div>

      </div>


      <div class="runtime-box">

        <div class="runtime-icon">
          💠
        </div>

        <div class="runtime-label">
          HEAP USED
        </div>

        <div class="runtime-value">
          ${formatBytes(stats.botMemHeap)}
        </div>

      </div>

    </div>

  </section>


  <!-- =================================================
       QUICK INFO
  ================================================== -->

  <div class="grid">

    <section class="card">

      <div class="card-head">

        <div class="icon">
          🕐
        </div>

        <div class="card-title">
          SERVER UPTIME
        </div>

      </div>

      <div
        style="
          font-size:17px;
          font-weight:950;
          color:#e8f8ff;
        "
      >
        ${formatUptime(stats.uptime)}
      </div>

      <div class="card-foot">
        <span>STATUS</span>
        <strong style="color:#73ff9a">
          ● STABLE
        </strong>
      </div>

    </section>


    <section class="card">

      <div class="card-head">

        <div class="icon">
          📡
        </div>

        <div class="card-title">
          MONITOR
        </div>

      </div>

      <div
        style="
          font-size:17px;
          font-weight:950;
          color:#e8f8ff;
        "
      >
        LIVE
      </div>

      <div class="card-foot">
        <span>UPDATE</span>
        <strong>
          REAL-TIME
        </strong>
      </div>

    </section>

  </div>


  <!-- =================================================
       FOOTER
  ================================================== -->

  <div class="footer">

    <div>
      🛡️ SECURE VPS MONITOR
    </div>

    <div>
      ${now.toLocaleString("id-ID")}
    </div>

    <div>
      POWERED BY
      <b>WELPER ID</b>
    </div>

  </div>

</div>

</body>
</html>`;
}

/* =========================================================
 *                      RENDER & HANDLER
 * ========================================================= */

async function renderImage(html) {
  const launchArgs = ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"];
  const executablePath = process.env.CHROME_PATH || process.env.PUPPETEER_EXECUTABLE_PATH || undefined;

  for (const name of ["puppeteer", "puppeteer-core"]) {
    let lib;
    try { lib = require(name); } catch { continue; }
    const browser = await lib.launch({ headless: true, args: launchArgs, ...(executablePath ? { executablePath } : {}) });
    try {
      const page = await browser.newPage();
      await page.setViewport({ width: 460, height: 900, deviceScaleFactor: 2 });
      await page.setContent(html, { waitUntil: "load" });
      return Buffer.from(await page.screenshot({ type: "png", fullPage: true }));
    } finally {
      await browser.close();
    }
  }

  let pw;
  try { pw = require("playwright"); } catch { try { pw = require("playwright-core"); } catch { pw = null; } }
  if (pw) {
    const browser = await pw.chromium.launch({ args: launchArgs, ...(executablePath ? { executablePath } : {}) });
    try {
      const page = await browser.newPage({ viewport: { width: 460, height: 900 }, deviceScaleFactor: 2 });
      await page.setContent(html, { waitUntil: "load" });
      return Buffer.from(await page.screenshot({ type: "png", fullPage: true }));
    } finally {
      await browser.close();
    }
  }
  return null;
}

function buildCaption(s) {
  return (
`🖥️ *VPS STATUS*

⚡ CPU     : ${s.cpuUsage}% (load ${s.loadAvg[0].toFixed(2)}, ${s.cpuCores} core)
🧠 RAM     : ${s.memPct}% (${formatBytes(s.usedMem)} / ${formatBytes(s.totalMem)})
💾 Disk    : ${s.diskPct}% (${formatBytes(s.diskUsed)} / ${formatBytes(s.diskTotal)})
🌡️ Suhu    : ${s.cpuTemp === null ? "-" : s.cpuTemp + "°C"}
🔄 Proses  : ${s.procCount}

🕐 Uptime server : ${formatUptime(s.uptime)}
⏱️ Uptime bot    : ${runtime(s.botUptime)}
🟢 Node ${s.nodeVer} • RSS ${formatBytes(s.botMemRSS)}

🏷️ ${s.hostname} • ${s.osType} ${s.osRelease} (${s.arch})`
  );
}

const handler = async (m) => {
  await m.react("⏳");
  try {
    const stats = getSystemStats();
    const html = buildStatusHTML(stats);
    const caption = buildCaption(stats);

    let img = null;
    try { img = await renderImage(html); } catch (e) { console.error("[STATUS] render gagal:", e.message); }

    if (img) {
      await m.reply({ image: img, caption });
    } else {
      await m.reply({
        document: Buffer.from(html, "utf8"),
        mimetype: "text/html",
        fileName: "vps-status.html",
        caption: caption + "\n\n_Buka file HTML di atas untuk dashboard lengkap. Pasang puppeteer (npm i puppeteer) agar dikirim sebagai gambar._",
      });
    }
    await m.react("✅");
  } catch (e) {
    console.error("[STATUS]", e);
    await m.react("❌");
    await m.reply("❌ Gagal mengambil status server.");
  }
};

export default handler;

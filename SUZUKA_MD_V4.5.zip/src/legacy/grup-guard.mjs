// Pengaturan fitur proteksi grup: adminonly, ammode, antilink, antispam, antitagall, antitagsw,
// antitoxic, antiunadmin, antivirtex, bungkam, delswgc.
// Penegakannya (hapus pesan, kick, dll) ada di src/utils/groupGuard.js.
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const store = require('../utils/groupStore.js')
const gctx = require('../utils/groupContext.js')
const { sendButtons } = require('../utils/interactiveHelper.js')
const brand = require('../utils/brand.js')

const parseOpt = (args) => (args[0] || '').toLowerCase().replace(/^--/, '')
const bot = (b) => (b ? '' : '\n\n⚠️ _Bot belum jadi admin grup — fitur baru bekerja setelah bot dijadikan admin._')

// toggle on/off sederhana: antispam, antitagall, antitoxic, antivirtex, antiunadmin, adminonly
const TOGGLES = {
    adminonly:   { key: 'adminOnly',   title: '🛡️ *ADMIN ONLY*',   desc: 'Hanya admin yang bisa memakai command bot di grup ini.', needBot: false },
    antispam:    { key: 'antispam',    title: '🚫 *ANTI SPAM*',    desc: 'Pesan beruntun terlalu cepat (5x) dihapus.', needBot: true },
    antitagall:  { key: 'antitagall',  title: '🚫 *ANTI TAGALL*',  desc: 'Pesan dengan 5 mention atau lebih dihapus.', needBot: true },
    antitoxic:   { key: 'antitoxic',   title: '🚫 *ANTI TOXIC*',   desc: 'Pesan berisi kata kasar dihapus.', needBot: true },
    antivirtex:  { key: 'antivirtex',  title: '🚫 *ANTI VIRTEX*',  desc: 'Pesan super panjang / karakter berulang dihapus.', needBot: true },
    antiunadmin: { key: 'antiunadmin', title: '🛡️ *ANTI UNADMIN*', desc: 'Admin yang di-unadmin otomatis dijadikan admin lagi.', needBot: true },
}

// ---- bungkam helpers ----
function resolveTarget(m, args, participants) {
    let raw = m.quoted?.sender || m.mentionedJid?.[0] || ''
    if (!raw && args[1]) raw = args[1].replace(/\D/g, '')
    const number = gctx.num(raw)
    if (!number) return null
    const p = participants.find((x) => gctx.idsOf(x).has(number))
    if (p) {
        const ids = [...gctx.idsOf(p)]
        const phone = gctx.num(p.phoneNumber) || (String(p.id || '').endsWith('@s.whatsapp.net') ? gctx.num(p.id) : '')
        return { ids, jid: phone ? `${phone}@s.whatsapp.net` : (p.id || `${number}@s.whatsapp.net`) }
    }
    return { ids: [number], jid: `${number}@s.whatsapp.net` }
}

const handler = async (m, { conn, args, command, usedPrefix, isOwner, isAdmin, isBotAdmin, participants }) => {
    if (!m.isGroup) return m.reply('❌ Fitur ini hanya untuk grup!')
    const chat = store.getChat(m.chat)
    const p = usedPrefix
    const staff = isAdmin || isOwner

    // ======================= bungkam (owner) =======================
    if (command === 'bungkam') {
        if (!isOwner) return m.reply('❌ Command ini khusus owner.')
        chat.bungkam = Array.isArray(chat.bungkam) ? chat.bungkam : []
        const action = (args[0] || '').toLowerCase()

        if (!['on', 'off', 'list'].includes(action)) {
            return m.reply(
                '🔇 *BUNGKAM TARGET*\n\n' +
                'Cara penggunaan:\n\n' +
                `• ${p}bungkam on 628xxx\n• ${p}bungkam off 628xxx\n\n` +
                `Reply pesan target:\n• ${p}bungkam on\n• ${p}bungkam off\n\n` +
                `Tag target:\n• ${p}bungkam on @628xxx\n• ${p}bungkam off @628xxx\n\n` +
                `• ${p}bungkam list`
            )
        }

        if (action === 'list') {
            if (!chat.bungkam.length) return m.reply('📭 Belum ada target yang dibungkam.')
            const text = '🔇 *DAFTAR TARGET BUNGKAM*\n\n' +
                chat.bungkam.map((e, i) => `${i + 1}. @${gctx.num(e.jid)}`).join('\n')
            return m.reply(text, null, { mentions: chat.bungkam.map((e) => e.jid) })
        }

        const target = resolveTarget(m, args, participants)
        if (!target) {
            return m.reply(
                '❌ Target tidak ditemukan.\n\nReply pesan target, tag target, atau masukkan nomor.\n\n' +
                `Contoh:\n${p}bungkam on 628123456789`
            )
        }
        const idx = chat.bungkam.findIndex((e) => e.ids.some((i) => target.ids.includes(i)))
        const name = '@' + gctx.num(target.jid)

        if (action === 'on') {
            if (idx !== -1) return m.reply(`⚠️ ${name} sudah dibungkam.`, null, { mentions: [target.jid] })
            chat.bungkam.push(target)
            store.save()
            return m.reply(`🔇 Berhasil membungkam ${name}.\n\nPesan dari target tersebut akan otomatis dibungkam.`, null, { mentions: [target.jid] })
        }
        if (idx === -1) return m.reply(`⚠️ ${name} tidak ada dalam daftar bungkam.`, null, { mentions: [target.jid] })
        chat.bungkam.splice(idx, 1)
        store.save()
        return m.reply(`🔊 Bungkam ${name} berhasil dinonaktifkan.`, null, { mentions: [target.jid] })
    }

    // ======================= kick (owner) =======================
    if (command === 'kick') {
        if (!isOwner) return m.reply('❌ Command ini khusus owner.')

        // target: semua yang di-tag + pengirim pesan yang di-reply + nomor yang diketik
        const raw = [
            ...(m.mentionedJid || []),
            ...(m.quoted?.sender ? [m.quoted.sender] : []),
            ...args.map((a) => a.replace(/\D/g, '')).filter((n) => n.length >= 8),
        ]
        const numbers = [...new Set(raw.map((j) => gctx.num(j)).filter(Boolean))]

        if (!numbers.length) {
            return m.reply(
                '👢 *KICK MEMBER*\n\n' +
                'Cara penggunaan:\n\n' +
                `• ${p}kick @user1 @user2\n` +
                `• ${p}kick 628xxxxxxxxxx\n` +
                `• Reply pesan target lalu ketik ${p}kick\n\n` +
                '_Khusus owner. Bot harus jadi admin grup._'
            )
        }
        if (!isBotAdmin) return m.reply('❌ Jadikan bot sebagai admin grup dulu ya.')

        const botIds = gctx.botIds(conn)
        const toKick = [], skipped = [], notFound = []
        for (const n of numbers) {
            const part = participants.find((x) => gctx.idsOf(x).has(n))
            if (!part) { notFound.push(n); continue }
            const ids = gctx.idsOf(part)
            if (gctx.intersects(ids, botIds)) { skipped.push([n, 'itu bot sendiri']); continue }
            if (part.admin === 'superadmin') { skipped.push([n, 'pembuat grup tidak bisa dikick']); continue }
            toKick.push({ n, jid: part.id })
        }

        const lines = []
        if (toKick.length) {
            try {
                await conn.groupParticipantsUpdate(m.chat, toKick.map((t) => t.jid), 'remove')
                gctx.invalidate(m.chat)
                lines.push(`✅ *Berhasil dikeluarkan:*\n${toKick.map((t) => '• @' + t.n).join('\n')}`)
            } catch (e) {
                console.error('[KICK]', e)
                lines.push('❌ Gagal mengeluarkan member. Pastikan bot admin dan target bukan pembuat grup.')
                toKick.length = 0
            }
        }
        if (skipped.length) lines.push(`⚠️ *Dilewati:*\n${skipped.map(([n, why]) => `• @${n} (${why})`).join('\n')}`)
        if (notFound.length) lines.push(`❓ *Tidak ada di grup ini:*\n${notFound.map((n) => '• ' + n).join('\n')}`)

        const mentions = [...toKick.map((t) => t.jid), ...skipped.map(([n]) => `${n}@s.whatsapp.net`)]
        return m.reply(`👢 *KICK MEMBER*\n\n${lines.join('\n\n')}`, null, { mentions })
    }

    // ======================= ammode (owner) =======================
    if (command === 'ammode' || command === 'modeam') {
        if (!isOwner) return m.reply('❌ Command ini khusus owner.')
        const opt = parseOpt(args)
        if (!opt) {
            return m.reply(`Gunakan:\n${p}${command} on / off\n\nStatus: ${chat.am_mode ? 'ON ✅' : 'OFF ❌'}\n\nCatatan:\nMengaktifkan mode Alight Motion Premium gratis untuk seluruh member grup.`)
        }
        if (opt === 'on') {
            if (chat.am_mode) return m.reply('AM Mode sudah aktif di grup ini.')
            chat.am_mode = true; store.save()
            return m.reply('✅ *AM MODE AKTIF!*\n\nGrup ini sekarang beralih ke Mode Khusus Alight Motion Premium.\nSeluruh member bisa menggunakan fitur AM Prem secara gratis!')
        }
        if (opt === 'off') {
            if (!chat.am_mode) return m.reply('AM Mode sudah nonaktif.')
            chat.am_mode = false; store.save()
            return m.reply('❌ *AM MODE DIMATIKAN!*\n\nFitur Alight Motion kembali normal (Khusus Premium).')
        }
        return m.reply("Opsi tidak valid. Gunakan 'on' atau 'off'.")
    }

    // ======================= delswgc (admin) =======================
    if (command === 'delswgc') {
        if (!staff) return m.reply('🚫 Khusus admin grup!')
        if (!m.quoted) return m.reply(`📌 Reply status grup yang ingin dihapus!\n\nContoh: ${p}delswgc (reply status)`)
        if (!isBotAdmin) return m.reply('❌ Jadikan bot sebagai admin grup dulu ya.')
        try {
            await conn.sendMessage(m.chat, {
                delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender },
            })
            return m.reply('✅ Status berhasil dihapus!')
        } catch (e) {
            console.error('[DELSWGC]', e)
            return m.reply('❌ Gagal menghapus status.\n\nPastikan bot adalah admin grup dan reply ke pesan status yang benar.')
        }
    }

    // semua command di bawah ini khusus admin grup / owner
    if (!staff) return m.reply('🚫 Khusus admin grup!')

    // ======================= antilink (soft / hard / off) =======================
    if (command === 'antilink') {
        const mode = chat.antilinkMode || (chat.antilink ? 'soft' : 'off')
        const opt = parseOpt(args)
        const label = { soft: '🟢 Anti Link', hard: '🔴 Anti Link Hard', off: '⚪ Nonaktif' }

        if (!['soft', 'hard', 'off', 'on'].includes(opt)) {
            return sendButtons(conn, m.chat, {
                text: `╭─「 *ANTI LINK GRUP* 」─\n│\n│ Status: ${label[mode]}\n│\n│ Pilih mode:\n│ • Anti Link → hapus pesan\n│ • Anti Link Hard → hapus + kick\n╰──────────────`,
                footer: brand.footer,
                buttons: [
                    { text: '🟢 Anti Link', id: `${p}antilink soft` },
                    { text: '🔴 Anti Link Hard', id: `${p}antilink hard` },
                    { text: '⚪ Nonaktifkan', id: `${p}antilink off` },
                ],
            })
        }
        const next = opt === 'on' ? 'soft' : opt
        chat.antilink = next !== 'off'
        chat.antilinkMode = next
        store.save()
        const msgs = {
            soft: '🟢 *Anti Link berhasil diaktifkan!*\n\nLink grup akan otomatis dihapus.',
            hard: '🔴 *Anti Link Hard berhasil diaktifkan!*\n\nPengirim link grup akan otomatis dihapus pesannya dan dikeluarkan.',
            off: '⚪ *Anti Link berhasil dinonaktifkan!*',
        }
        return m.reply(msgs[next] + (next !== 'off' ? bot(isBotAdmin) : ''))
    }

    // ======================= antitagsw (on / off / set) =======================
    if (command === 'antitagsw') {
        const opt = parseOpt(args)
        if (!opt) {
            return m.reply(
                `Anti Tag Status: ${chat.antitagsw ? 'ON ✅' : 'OFF ❌'}\nLimit: ${chat.antitagswLimit ?? 0}x/hari\n\n` +
                `Gunakan:\n${p}antitagsw on / off\n${p}antitagsw set <jumlah>\n\n` +
                `Catatan:\nDefault = langsung dihapus (0x)\nContoh:\n${p}antitagsw set 1`
            )
        }
        if (opt === 'on') {
            if (chat.antitagsw) return m.reply('Anti Tag Status sudah aktif.')
            chat.antitagsw = true; store.save()
            return m.reply(`✅ Anti Tag Status aktif!\nLimit saat ini: ${chat.antitagswLimit ?? 0}x/hari (0 = langsung dihapus)${bot(isBotAdmin)}`)
        }
        if (opt === 'off') {
            if (!chat.antitagsw) return m.reply('Anti Tag Status sudah nonaktif.')
            chat.antitagsw = false; store.save()
            return m.reply('❌ Anti Tag Status dimatikan.')
        }
        if (opt === 'set') {
            const limit = parseInt(args[1], 10)
            if (isNaN(limit) || limit < 0) return m.reply(`Masukkan angka yang valid.\nContoh: ${p}antitagsw set 1`)
            chat.antitagswLimit = limit; store.save()
            return m.reply(`✅ Limit tag SW diatur menjadi ${limit}x per hari`)
        }
        return m.reply('Opsi tidak valid.')
    }

    // ======================= toggle on/off =======================
    const t = TOGGLES[command]
    if (!t) return
    const opt = parseOpt(args)

    if (command === 'antitoxic' && !['on', 'off'].includes(opt)) {
        return sendButtons(conn, m.chat, {
            text: `*– 乂 Anti Toxic –*\n\nStatus: ${chat.antitoxic ? 'ON ✅' : 'OFF ❌'}\n\nPilih mode Anti Toxic untuk grup ini.`,
            footer: brand.footer,
            buttons: [
                { text: '✅ ON', id: `${p}antitoxic on` },
                { text: '❌ OFF', id: `${p}antitoxic off` },
            ],
        })
    }
    if (!['on', 'off'].includes(opt)) {
        return m.reply(`${t.title}\n\nStatus: ${chat[t.key] ? 'ON ✅' : 'OFF ❌'}\n${t.desc}\n\nGunakan:\n• ${p}${command} on\n• ${p}${command} off`)
    }
    const on = opt === 'on'
    if (!!chat[t.key] === on) return m.reply(`${t.title}\n\n${on ? '🟢 Sudah aktif sebelumnya.' : '🔴 Sudah nonaktif sebelumnya.'}`)
    chat[t.key] = on
    store.save()
    return m.reply(`${t.title}\n\n${on ? '✅ Berhasil diaktifkan.' : '❌ Berhasil dinonaktifkan.'}\n${t.desc}${on && t.needBot ? bot(isBotAdmin) : ''}`)
}

export default handler

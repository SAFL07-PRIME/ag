import { Buffer } from "buffer";
import crypto from "crypto";

export const LUDO_HTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>🎲 Ludo Pro</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}
html,body{width:100%;height:100%;overflow:hidden;background:#0d0d18;font-family:-apple-system,'Segoe UI',Arial,sans-serif;touch-action:none;user-select:none;-webkit-user-select:none;color:#fff}
#app{max-width:440px;margin:0 auto;padding:6px;height:100vh;display:flex;flex-direction:column;gap:5px;position:relative}

/* ============ SETUP SCREEN ============ */
#setup{position:absolute;inset:0;background:linear-gradient(165deg,#1a1030 0%,#0a0a18 60%,#050510 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;z-index:100;transition:.4s}
#setup.hide{opacity:0;pointer-events:none;transform:scale(.95)}
.setupTitle{font:900 28px 'Arial Black';background:linear-gradient(135deg,#ffd75e,#ff6b9d 60%,#7ae6ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:1px;margin-bottom:4px;text-align:center}
.setupSub{font:700 10px Arial;color:#6a7a9a;letter-spacing:2px;margin-bottom:22px;text-align:center}
.slots{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;width:100%;max-width:300px}
.slot{aspect-ratio:1;border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:3px solid;position:relative;transition:.2s;background:rgba(0,0,0,.4);gap:6px}
.slot:active{transform:scale(.95)}
.slot .icon{font-size:38px;line-height:1;transition:.2s}
.slot .label{font:900 11px Arial;letter-spacing:1px;text-transform:uppercase}
.slot .badge{position:absolute;top:-6px;right:-6px;width:22px;height:22px;border-radius:50%;background:#ffd75e;color:#1a1000;font:900 11px Arial;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.4)}
.slot[data-state="empty"]{border-color:rgba(255,255,255,.15);color:#556}
.slot[data-state="empty"] .icon{opacity:.35}
.slot[data-state="human"]{border-color:#ffd75e;color:#ffd75e;box-shadow:0 0 24px rgba(255,215,94,.3);background:rgba(255,215,94,.08)}
.slot[data-state="bot"]{border-color:#7ae6ff;color:#7ae6ff;box-shadow:0 0 20px rgba(122,230,255,.2);background:rgba(122,230,255,.06)}
.setupHint{font:600 10px Arial;color:#8892a8;text-align:center;margin-bottom:20px;line-height:1.5}
.btnStart{padding:14px 50px;border:none;border-radius:14px;font:900 15px 'Arial Black';letter-spacing:1px;cursor:pointer;color:#1a1000;background:linear-gradient(135deg,#ffd75e,#ffaa3c);box-shadow:0 5px 0 #8a5a00,0 10px 24px rgba(255,170,60,.4);transition:.15s}
.btnStart:active{transform:translateY(4px);box-shadow:0 1px 0 #8a5a00,0 4px 12px rgba(255,170,60,.4)}
.btnStart:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none}
.diffRow{display:flex;gap:8px;margin-bottom:16px}
.diffBtn{padding:8px 16px;border:2px solid rgba(255,255,255,.2);border-radius:10px;background:rgba(0,0,0,.4);color:#8892a8;font:900 10px Arial;letter-spacing:1px;cursor:pointer;transition:.15s;text-transform:uppercase}
.diffBtn.active{border-color:#7aff8a;color:#7aff8a;background:rgba(122,255,138,.1);box-shadow:0 0 12px rgba(122,255,138,.3)}

/* ============ MAIN GAME ============ */
#game{display:flex;flex-direction:column;gap:5px;height:100%}
#game.hide{display:none}
.hdr{display:flex;justify-content:space-between;align-items:center;padding:6px 10px;border:2px solid rgba(255,255,255,.12);border-radius:12px;background:linear-gradient(145deg,#1a1a2a,#0a0a14);min-height:54px;gap:6px}
.tt{font:900 12px 'Arial Black';color:#ffd75e;letter-spacing:.5px;flex-shrink:0}
.players{display:flex;gap:4px;flex:1;justify-content:center;flex-wrap:wrap}
.pcard{display:flex;align-items:center;gap:3px;padding:3px 7px 3px 5px;border-radius:8px;background:rgba(0,0,0,.45);border:1.5px solid rgba(255,255,255,.15);transition:.25s;font:700 9px Arial;min-width:0}
.pcard.active{box-shadow:0 0 14px currentColor;transform:scale(1.05);border-width:2px}
.pcard.done{opacity:.4}
.pcard .dot{width:11px;height:11px;border-radius:50%;flex-shrink:0;box-shadow:inset 0 -1px 2px rgba(0,0,0,.3)}
.pcard .info-col{display:flex;flex-direction:column;line-height:1.1;min-width:0}
.pcard .nm{font:900 8.5px Arial;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:52px}
.pcard .sc{font:600 8px Arial;opacity:.7}
.mbtn{width:32px;height:32px;border:2px solid rgba(255,255,255,.2);border-radius:8px;background:rgba(0,0,0,.5);color:#fff;font-size:14px;cursor:pointer;flex-shrink:0;padding:0}
.mbtn:active{filter:brightness(1.6)}

.boardWrap{position:relative;flex:1;border-radius:14px;overflow:hidden;background:#000;min-height:0;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 40px rgba(0,0,0,.8)}
canvas{display:block;max-width:100%;max-height:100%;touch-action:none}

.ctrl{padding:6px 8px;border:2px solid rgba(255,255,255,.12);border-radius:12px;background:linear-gradient(145deg,#1a1a2a,#0a0a14);display:flex;gap:8px;align-items:center}
.diceBox{width:56px;height:56px;perspective:200px;flex-shrink:0;cursor:pointer}
.dice{width:100%;height:100%;position:relative;transform-style:preserve-3d;transition:transform .6s cubic-bezier(.4,1.6,.6,1)}
.dice .face{position:absolute;inset:0;background:linear-gradient(145deg,#fff,#d8d8d8);border-radius:10px;border:1px solid #999;box-shadow:inset 0 3px 8px rgba(0,0,0,.15);display:grid;padding:6px;grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr 1fr;gap:2px}
.dice .pip{background:#1a1a2a;border-radius:50%;box-shadow:inset 0 1px 2px rgba(0,0,0,.6)}
.dice .pip.off{visibility:hidden}
.dice.rolling{animation:rollSpin .5s linear infinite}
@keyframes rollSpin{from{transform:rotateX(0) rotateY(0) rotateZ(0)}to{transform:rotateX(360deg) rotateY(720deg) rotateZ(180deg)}}
.info{flex:1;text-align:center;font:700 10px Arial;color:#a8b8d0;line-height:1.35;min-width:0}
.info b{color:#ffd75e}
.info .turn{display:inline-block;font-weight:900;padding:1px 6px;border-radius:6px;margin:0 2px}
#rollBtn{height:56px;padding:0 18px;border:2px solid #ffd75e;border-radius:12px;background:linear-gradient(#4a3a0a,#1a1000);color:#ffd75e;font:900 13px 'Arial Black';letter-spacing:1px;cursor:pointer;box-shadow:0 5px 0 #0a0600,inset 0 2px rgba(255,255,255,.1);flex-shrink:0;transition:.15s}
#rollBtn:active{transform:translateY(3px);box-shadow:0 2px 0 #0a0600}
#rollBtn:disabled{opacity:.3;cursor:not-allowed;transform:none}

.hint{text-align:center;font:600 8px Arial;color:#5a6a80;padding-bottom:2px;line-height:1.4}

/* ============ WIN MODAL ============ */
.modal{position:absolute;inset:0;background:rgba(5,5,15,.92);z-index:200;display:none;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(6px)}
.modal.show{display:flex;animation:fadeIn .35s ease}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.winCard{width:100%;max-width:320px;padding:26px 22px;border:3px solid #ffd75e;border-radius:22px;background:linear-gradient(145deg,#2a1a3a,#12081a);box-shadow:inset 0 0 30px rgba(0,0,0,.6),0 10px 0 #06020a,0 20px 50px rgba(255,215,94,.3);text-align:center;animation:popIn .5s cubic-bezier(.4,1.6,.6,1)}
@keyframes popIn{from{transform:scale(.5);opacity:0}to{transform:scale(1);opacity:1}}
.winIcon{font-size:64px;margin-bottom:6px;animation:winBounce 1.2s ease infinite}
@keyframes winBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.winTitle{font:900 26px 'Arial Black';color:#ffd75e;margin-bottom:4px;letter-spacing:1px;text-shadow:0 2px 0 #000,0 0 20px rgba(255,215,94,.6)}
.winName{font:900 16px Arial;margin:10px 0;padding:8px 14px;border-radius:10px;background:rgba(0,0,0,.5);display:inline-block}
.winBtn{margin-top:16px;padding:12px 32px;border:none;border-radius:12px;font:900 13px 'Arial Black';letter-spacing:1px;cursor:pointer;color:#1a1000;background:linear-gradient(135deg,#ffd75e,#ffaa3c);box-shadow:0 4px 0 #8a5a00;width:100%}
.winBtn:active{transform:translateY(3px);box-shadow:0 1px 0 #8a5a00}
.winBtn.sec{margin-top:8px;background:linear-gradient(135deg,#3a4a6a,#1a2a4a);color:#c8d8f0;box-shadow:0 4px 0 #0a1a2a}

/* ============ INVITE MODAL ============ */
.invCard{padding:22px;background:linear-gradient(145deg,#1a2a3a,#0a1520);border-color:#7ae6ff;box-shadow:0 10px 0 #020810,0 20px 50px rgba(122,230,255,.3)}
.invCard .winTitle{color:#7ae6ff;text-shadow:0 2px 0 #000,0 0 20px rgba(122,230,255,.6)}
.invCode{background:#000;padding:14px;border-radius:10px;font:900 20px monospace;color:#7ae6ff;letter-spacing:4px;margin:12px 0;text-align:center;border:1px dashed rgba(122,230,255,.5)}
.invText{font:600 10px Arial;color:#8892a8;line-height:1.5;margin-bottom:8px}
</style>
</head>
<body>
<div id="app">

<!-- SETUP SCREEN -->
<div id="setup">
  <div class="setupTitle">🎲 LUDO PRO</div>
  <div class="setupSub">CLASSIC BOARD · MULTIPLAYER</div>
  <div class="slots" id="slots"></div>
  <div class="diffRow">
    <div class="diffBtn" data-diff="easy">😴 SANTAI</div>
    <div class="diffBtn active" data-diff="normal">⚖️ NORMAL</div>
    <div class="diffBtn" data-diff="hard">🔥 SULIT</div>
  </div>
  <div class="setupHint">Tap slot buat ganti: <b style="color:#8892a8">Kosong → Bot → Kamu</b><br>Minimal 2 pemain · Bisa 2, 3, atau 4 orang</div>
  <button class="btnStart" id="startBtn" disabled>MULAI 🎮</button>
  <div style="margin-top:14px;font:600 8px Arial;color:#3a4a6a">Pass-and-play · 1 HP bergantian buat 2-4 manusia</div>
</div>

<!-- MAIN GAME -->
<div id="game" class="hide">
  <div class="hdr">
    <div class="tt">🎲 LUDO</div>
    <div class="players" id="players"></div>
    <button class="mbtn" id="inviteB" title="Invite">📤</button>
    <button class="mbtn" id="resetB" title="Restart">🔄</button>
  </div>
  <div class="boardWrap"><canvas id="cv"></canvas></div>
  <div class="ctrl">
    <div class="diceBox" id="diceBox">
      <div class="dice" id="dice">
        <div class="face" data-face="1"></div>
      </div>
    </div>
    <div class="info" id="info">Tekan ROLL buat mulai</div>
    <button id="rollBtn">🎲 ROLL</button>
  </div>
  <div class="hint">Tap token buat gerak · ⭐ = safe zone</div>
</div>

<!-- WIN MODAL -->
<div class="modal" id="winModal">
  <div class="winCard">
    <div class="winIcon" id="winIcon">🏆</div>
    <div class="winTitle" id="winTitle">MENANG!</div>
    <div class="winName" id="winName"></div>
    <button class="winBtn" id="againBtn">MAIN LAGI</button>
    <button class="winBtn sec" id="setupBtn">GANTI PEMAIN</button>
  </div>
</div>

<!-- INVITE MODAL -->
<div class="modal" id="invModal">
  <div class="winCard invCard">
    <div class="winIcon">📤</div>
    <div class="winTitle">INVITE TEMAN</div>
    <div class="invText">Salin teks di bawah & share ke teman lo!</div>
    <div class="invCode" id="invCode">----</div>
    <div class="invText" style="font-size:9px">Main bareng di HP yang sama (pass-and-play) atau share link game ke grup WA.</div>
    <button class="winBtn" id="copyBtn" style="background:linear-gradient(135deg,#7ae6ff,#3a9ad6);box-shadow:0 4px 0 #0a5a80;color:#001a2a">📋 SALIN TEXT</button>
    <button class="winBtn sec" id="closeInvBtn">TUTUP</button>
  </div>
</div>

</div>

<script>
window.onerror=function(m,s,l){var e=document.getElementById('info');if(e){e.textContent='⚠ '+m;e.style.color='#ff7a8a'}};
(function(){
'use strict';
var cv=document.getElementById('cv'),ctx=cv.getContext('2d');
var W=390,H=390,CELL=26,dpr=1;

/* ==================== AUDIO ==================== */
var AC=null,MUTED=false;
try{MUTED=localStorage.getItem('ludo_mute')==='1'}catch(e){}
function ac(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){return null}}if(AC&&AC.state==='suspended'){try{AC.resume()}catch(e){}}return AC}
function tone(f,d,t,v,at,sl){var a=AC;if(!a||MUTED)return;try{var n=a.currentTime+(at||0),o=a.createOscillator(),g=a.createGain();o.type=t||'square';o.frequency.setValueAtTime(f,n);if(sl)o.frequency.exponentialRampToValueAtTime(sl,n+d);g.gain.setValueAtTime(v||.08,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(a.destination);o.start(n);o.stop(n+d+.03)}catch(e){}}
function sRoll(){for(var i=0;i<5;i++)tone(600+Math.random()*400,.03,'square',.04,i*.05)}
function sMove(){tone(700,.05,'square',.06)}
function sCapture(){[800,600,400,300].forEach(function(f,i){tone(f,.1,'sawtooth',.1,i*.06)})}
function sHome(){[659,784,1047].forEach(function(f,i){tone(f,.12,'triangle',.12,i*.07)})}
function sWin(){[523,659,784,1047,1319,1568].forEach(function(f,i){tone(f,.18,'triangle',.13,i*.09)})}
function sTurn(){tone(880,.06,'sine',.07)}
function sSkip(){tone(200,.15,'square',.08,0,100)}

/* ==================== TRACK LAYOUT ==================== */
/* (row, col) 0-indexed, 52 cells clockwise from red start */
var TRACK=[
  [13,6],[12,6],[11,6],[10,6],[9,6],
  [8,5],[8,4],[8,3],[8,2],[8,1],[8,0],
  [7,0],
  [6,0],[6,1],[6,2],[6,3],[6,4],[6,5],
  [5,6],[4,6],[3,6],[2,6],[1,6],[0,6],
  [0,7],
  [0,8],[1,8],[2,8],[3,8],[4,8],[5,8],
  [6,9],[6,10],[6,11],[6,12],[6,13],[6,14],
  [7,14],
  [8,14],[8,13],[8,12],[8,11],[8,10],[8,9],
  [9,8],[10,8],[11,8],[12,8],[13,8],[14,8],
  [14,7],
  [14,6]
];

/* Home column (5 cells) leading into center */
var HOME_COL={
  red:   [[7,1],[7,2],[7,3],[7,4],[7,5]],
  green: [[1,7],[2,7],[3,7],[4,7],[5,7]],
  yellow:[[7,13],[7,12],[7,11],[7,10],[7,9]],
  blue:  [[13,7],[12,7],[11,7],[10,7],[9,7]]
};

var STARTS={red:0,green:13,yellow:26,blue:39};
/* Safe cells (indices in global track) */
var SAFE_IDX=new Set([0,8,13,21,26,34,39,47]);
/* Star cell indices (each player has own star start) */
var STAR_CELLS=new Set([8,21,34,47]);

var COLORS={red:'#e63946',green:'#2a9d34',yellow:'#f2c419',blue:'#3a7ad6'};
var DARK  ={red:'#8a1a24',green:'#146020',yellow:'#a08000',blue:'#1a4080'};
var LIGHT ={red:'#ffa8b0',green:'#a0e8a8',yellow:'#fff0a0',blue:'#a8c8ff'};
var NAMES ={red:'Merah',green:'Hijau',yellow:'Kuning',blue:'Biru'};
var ICON  ={red:'🔴',green:'🟢',yellow:'🟡',blue:'🔵'};

/* Yard positions (2x2 grid in each corner yard) */
var YARD={
  red:   [[10,1],[10,4],[13,1],[13,4]],
  green: [[1,1],[1,4],[4,1],[4,4]],
  yellow:[[1,10],[1,13],[4,10],[4,13]],
  blue:  [[10,10],[10,13],[13,10],[13,13]]
};
/* Wait - these are 2x2 positions inside the 6x6 home yard */
/* Actually home yard for red is rows 9-14 cols 0-5. So grid positions inside: rows 10,13 cols 1,4 makes 2x2=4 spots */

/* Build per-player 57-step path */
var PATHS={};
Object.keys(STARTS).forEach(function(k){
  var p=[];
  for(var i=0;i<51;i++)p.push(TRACK[(STARTS[k]+i)%52]);
  HOME_COL[k].forEach(function(c){p.push(c)});
  p.push([7,7]); // center
  PATHS[k]=p;
});

/* ==================== STATE ==================== */
var ORDER=['red','green','yellow','blue'];
var players=null; // {red:{isHuman:true,tokens:[{pos:-1},...]}, ...}
var activePlayers=[];
var currentIdx=0;
var currentPlayer=null;
var dice=0;
var phase='roll'; // roll | move | anim | end
var winner=null;
var highlight=[];
var sixCount=0;
var difficulty='normal';
var setupConfig={red:'human',green:'bot',yellow:'bot',blue:'bot'};
var animating=false;
var diceValue=1;

/* ==================== SETUP ==================== */
function renderSlots(){
  var html='';
  ORDER.forEach(function(k){
    var st=setupConfig[k];
    var icon='❓',label='Kosong';
    if(st==='human'){icon='👤';label='Kamu'}
    else if(st==='bot'){icon='🤖';label='Bot'}
    html+='<div class="slot" data-state="'+st+'" data-color="'+k+'" style="border-color:'+(st==='empty'?'rgba(255,255,255,.15)':COLORS[k])+';color:'+COLORS[k]+'">'+
      '<div class="icon">'+ICON[k]+'</div>'+
      '<div class="label">'+NAMES[k]+'</div>'+
      '<div style="font:900 9px Arial;opacity:.85;letter-spacing:1px;margin-top:2px">'+icon+' '+label.toUpperCase()+'</div>'+
      '</div>';
  });
  document.getElementById('slots').innerHTML=html;
  
  // count
  var cnt=ORDER.filter(function(k){return setupConfig[k]!=='empty'}).length;
  document.getElementById('startBtn').disabled=cnt<2;
  
  // bind
  document.querySelectorAll('.slot').forEach(function(el){
    el.onclick=function(){
      var k=el.dataset.color;
      var cur=setupConfig[k];
      if(cur==='empty')setupConfig[k]='bot';
      else if(cur==='bot')setupConfig[k]='human';
      else setupConfig[k]='empty';
      renderSlots();
    };
  });
}
document.querySelectorAll('.diffBtn').forEach(function(b){
  b.onclick=function(){
    document.querySelectorAll('.diffBtn').forEach(function(x){x.classList.remove('active')});
    b.classList.add('active');
    difficulty=b.dataset.diff;
  };
});
renderSlots();

document.getElementById('startBtn').onclick=function(){
  ac();
  initGame();
  document.getElementById('setup').classList.add('hide');
  document.getElementById('game').classList.remove('hide');
  setTimeout(resize,60);
};

/* ==================== INIT GAME ==================== */
function initGame(){
  players={};
  activePlayers=[];
  ORDER.forEach(function(k){
    var st=setupConfig[k];
    if(st==='empty')return;
    players[k]={
      color:COLORS[k],
      name:NAMES[k],
      icon:ICON[k],
      isHuman:st==='human',
      tokens:[{pos:-1},{pos:-1},{pos:-1},{pos:-1}],
      finished:0
    };
    activePlayers.push(k);
  });
  currentIdx=0;
  currentPlayer=activePlayers[0];
  dice=0;
  phase='roll';
  winner=null;
  highlight=[];
  sixCount=0;
  animating=false;
  diceValue=1;
  updatePlayersUI();
  updateInfo();
  draw();
}

/* ==================== DICE FACE ==================== */
function renderDice(n){
  var dotPos={
    1:[[2,2]],
    2:[[1,1],[3,3]],
    3:[[1,1],[2,2],[3,3]],
    4:[[1,1],[1,3],[3,1],[3,3]],
    5:[[1,1],[1,3],[2,2],[3,1],[3,3]],
    6:[[1,1],[1,3],[2,1],[2,3],[3,1],[3,3]]
  };
  var face=document.querySelector('.dice .face');
  face.innerHTML='';
  for(var r=1;r<=3;r++){
    for(var c=1;c<=3;c++){
      var on=dotPos[n].some(function(p){return p[0]===r&&p[1]===c});
      var d=document.createElement('div');
      d.className='pip'+(on?'':' off');
      face.appendChild(d);
    }
  }
}
renderDice(1);

/* ==================== UI ==================== */
function updatePlayersUI(){
  var html='';
  activePlayers.forEach(function(k){
    var p=players[k];
    var active=k===currentPlayer&&!winner;
    var fin=p.tokens.filter(function(t){return t.pos===56}).length;
    var done=fin===4;
    html+='<div class="pcard'+(active?' active':'')+(done?' done':'')+'" style="color:'+COLORS[k]+';border-color:'+COLORS[k]+'">'+
      '<div class="dot" style="background:'+COLORS[k]+'"></div>'+
      '<div class="info-col">'+
        '<div class="nm">'+(p.isHuman?'👤':'🤖')+' '+NAMES[k]+'</div>'+
        '<div class="sc">'+fin+'/4</div>'+
      '</div>'+
      '</div>';
  });
  document.getElementById('players').innerHTML=html;
}
function updateInfo(){
  var info=document.getElementById('info');
  if(winner){
    info.innerHTML='🏆 <b>'+NAMES[winner]+'</b> MENANG!';
    return;
  }
  var p=players[currentPlayer];
  var nameHtml='<span class="turn" style="background:'+COLORS[currentPlayer]+'33;color:'+COLORS[currentPlayer]+'">'+ICON[currentPlayer]+' '+NAMES[currentPlayer]+(p.isHuman?' 👤':' 🤖')+'</span>';
  if(phase==='roll'){
    if(p.isHuman)info.innerHTML=nameHtml+'<br>Tap ROLL 🎲';
    else info.innerHTML=nameHtml+'<br>Berpikir...';
  }else if(phase==='move'){
    info.innerHTML='🎲 <b>'+dice+'</b> · Tap token';
  }
}

/* ==================== DICE ROLL ==================== */
function roll(){
  if(phase!=='roll'||winner||animating)return;
  if(!players[currentPlayer].isHuman)return;
  ac();
  var diceEl=document.getElementById('dice');
  diceEl.classList.add('rolling');
  sRoll();
  var count=0;
  var iv=setInterval(function(){
    diceValue=1+Math.floor(Math.random()*6);
    renderDice(diceValue);
    count++;
    if(count>8){
      clearInterval(iv);
      diceEl.classList.remove('rolling');
      dice=diceValue;
      finalizeRoll();
    }
  },55);
}
document.getElementById('rollBtn').onclick=roll;
document.getElementById('diceBox').onclick=roll;

function finalizeRoll(){
  var moves=getValidMoves(currentPlayer,dice);
  if(moves.length===0){
    info.innerHTML='🎲 <b>'+dice+'</b> · ❌ Tidak ada gerakan';
    sSkip();
    animating=true;
    setTimeout(function(){animating=false;endTurn()},900);
    return;
  }
  if(players[currentPlayer].isHuman){
    phase='move';
    highlight=moves;
    updateInfo();
    draw();
  }else{
    // AI turn
    animating=true;
    var chosen=aiChoose(currentPlayer,moves);
    setTimeout(function(){animating=false;executeMove(currentPlayer,chosen)},500);
  }
}

/* ==================== VALID MOVES ==================== */
function getValidMoves(player,d){
  var moves=[];
  players[player].tokens.forEach(function(tok,i){
    if(tok.pos===-1){
      if(d===6)moves.push(i);
    }else if(tok.pos>=0&&tok.pos<56){
      if(tok.pos+d<=56)moves.push(i);
    }
  });
  return moves;
}

/* ==================== EXECUTE MOVE ==================== */
function executeMove(player,idx){
  if(phase==='anim')return;
  phase='anim';
  animating=true;
  highlight=[];
  draw();
  var tok=players[player].tokens[idx];
  var from=tok.pos;
  var target=from===-1?0:from+dice;
  
  if(from===-1){
    tok.pos=0;
    sMove();
    draw();
    setTimeout(function(){finishMove(player,tok,idx)},300);
  }else{
    var cur=from;
    var stepFn=function(){
      cur++;
      tok.pos=cur;
      sMove();
      draw();
      if(cur<target)setTimeout(stepFn,75);
      else setTimeout(function(){finishMove(player,tok,idx)},120);
    };
    setTimeout(stepFn,75);
  }
}

function finishMove(player,tok,idx){
  var captured=checkCapture(player,tok);
  var home=checkHome(player,tok);
  var fin=players[player].tokens.filter(function(t){return t.pos===56}).length;
  players[player].finished=fin;
  
  if(fin===4){
    winner=player;
    phase='end';
    animating=false;
    sWin();
    updatePlayersUI();
    draw();
    setTimeout(showWin,700);
    return;
  }
  
  if(dice===6)sixCount++;else sixCount=0;
  var extra=(dice===6&&sixCount<3)||captured||home;
  
  if(extra){
    phase='roll';
    animating=false;
    updatePlayersUI();
    updateInfo();
    draw();
    if(!players[player].isHuman)setTimeout(autoRoll,700);
  }else{
    animating=false;
    endTurn();
  }
}

function checkCapture(player,tok){
  if(tok.pos<0||tok.pos>50)return false;
  var cell=PATHS[player][tok.pos];
  var gidx=(STARTS[player]+tok.pos)%52;
  if(SAFE_IDX.has(gidx))return false;
  var cap=false;
  activePlayers.forEach(function(p){
    if(p===player)return;
    players[p].tokens.forEach(function(opp){
      if(opp.pos<0||opp.pos>50)return;
      var oc=PATHS[p][opp.pos];
      if(oc[0]===cell[0]&&oc[1]===cell[1]){
        opp.pos=-1;
        cap=true;
      }
    });
  });
  if(cap){sCapture();flashRed=1}
  return cap;
}

function checkHome(player,tok){
  if(tok.pos===56){
    sHome();
    return true;
  }
  return false;
}

/* ==================== TURN ==================== */
function endTurn(){
  if(winner)return;
  sixCount=0;
  currentIdx=(currentIdx+1)%activePlayers.length;
  currentPlayer=activePlayers[currentIdx];
  phase='roll';
  animating=false;
  sTurn();
  updatePlayersUI();
  updateInfo();
  draw();
  if(!players[currentPlayer].isHuman)setTimeout(autoRoll,750);
}
function autoRoll(){
  if(phase!=='roll'||winner)return;
  ac();
  var diceEl=document.getElementById('dice');
  diceEl.classList.add('rolling');
  sRoll();
  var count=0;
  var iv=setInterval(function(){
    diceValue=1+Math.floor(Math.random()*6);
    renderDice(diceValue);
    count++;
    if(count>6){
      clearInterval(iv);
      diceEl.classList.remove('rolling');
      dice=diceValue;
      finalizeRoll();
    }
  },55);
}

/* ==================== AI ==================== */
function aiChoose(player,moves){
  var tokens=players[player].tokens;
  var smart=difficulty==='hard';
  var dumb=difficulty==='easy';
  
  if(dumb&&Math.random()<0.4){
    return moves[Math.floor(Math.random()*moves.length)];
  }
  
  // Priority 1: capture opponent
  for(var i=0;i<moves.length;i++){
    var m=moves[i];
    var tok=tokens[m];
    var newPos=tok.pos===-1?0:tok.pos+dice;
    if(newPos>=0&&newPos<=50){
      var cell=PATHS[player][newPos];
      var gi=(STARTS[player]+newPos)%52;
      if(!SAFE_IDX.has(gi)){
        for(var j=0;j<activePlayers.length;j++){
          var p=activePlayers[j];
          if(p===player)continue;
          var opps=players[p].tokens;
          for(var k=0;k<opps.length;k++){
            if(opps[k].pos<0||opps[k].pos>50)continue;
            var oc=PATHS[p][opps[k].pos];
            if(oc[0]===cell[0]&&oc[1]===cell[1])return m;
          }
        }
      }
    }
  }
  
  // Priority 2: reach home
  for(i=0;i<moves.length;i++){
    if(tokens[moves[i]].pos+dice===56)return moves[i];
  }
  
  // Priority 3: release from yard on 6 (if smart, prioritize if yard has few tokens)
  if(smart){
    for(i=0;i<moves.length;i++){
      if(tokens[moves[i]].pos===-1)return moves[i];
    }
  }else{
    for(i=0;i<moves.length;i++){
      if(tokens[moves[i]].pos===-1)return moves[i];
    }
  }
  
  // Priority 4: escape danger (move token that's threatened)
  if(smart){
    var threatened=-1;
    for(i=0;i<moves.length;i++){
      var tk=tokens[moves[i]];
      if(tk.pos<0||tk.pos>50)continue;
      var gi=(STARTS[player]+tk.pos)%52;
      if(SAFE_IDX.has(gi))continue;
      var cell=PATHS[player][tk.pos];
      // check nearby enemies
      for(var j2=0;j2<activePlayers.length;j2++){
        var p2=activePlayers[j2];
        if(p2===player)continue;
        var opps2=players[p2].tokens;
        for(var k2=0;k2<opps2.length;k2++){
          if(opps2[k2].pos<0||opps2[k2].pos>50)continue;
          var oc2=PATHS[p2][opps2[k2].pos];
          var dist=Math.hypot(oc2[0]-cell[0],oc2[1]-cell[1]);
          if(dist<7&&dist>0){threatened=moves[i];break}
        }
      }
      if(threatened>=0)return threatened;
    }
  }
  
  // Priority 5: move furthest
  var best=moves[0],bp=-1;
  for(i=0;i<moves.length;i++){
    if(tokens[moves[i]].pos>bp){bp=tokens[moves[i]].pos;best=moves[i]}
  }
  return best;
}

/* ==================== RESIZE + DRAW ==================== */
function resize(){
  var wrap=cv.parentElement.getBoundingClientRect();
  var size=Math.min(wrap.width,wrap.height);
  if(size<=0)return;
  CELL=Math.floor(size/15);
  W=CELL*15;H=CELL*15;
  dpr=Math.min(window.devicePixelRatio||1,2);
  cv.width=W*dpr;cv.height=H*dpr;
  cv.style.width=W+'px';cv.style.height=H+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
  draw();
}
window.addEventListener('resize',resize);
window.addEventListener('orientationchange',function(){setTimeout(resize,200)});

function draw(){
  if(W<10)return;
  ctx.setTransform(dpr,0,0,dpr,0,0);
  
  // Outer border wood-look
  ctx.fillStyle='#2a1a0a';
  ctx.fillRect(0,0,W,H);
  ctx.fillStyle='#f5e8d0';
  ctx.fillRect(CELL*0.15,CELL*0.15,W-CELL*0.3,H-CELL*0.3);
  ctx.save();
  ctx.translate(CELL*0.15,CELL*0.15);
  var S=CELL*14.7;
  ctx.scale(S/(CELL*15),S/(CELL*15));
  
  // ============ HOME YARDS (6x6 colored squares) ============
  var h=6*CELL;
  // Green top-left
  ctx.fillStyle=COLORS.green; ctx.fillRect(0,0,h,h);
  // Yellow top-right
  ctx.fillStyle=COLORS.yellow; ctx.fillRect(9*CELL,0,h,h);
  // Red bottom-left
  ctx.fillStyle=COLORS.red; ctx.fillRect(0,9*CELL,h,h);
  // Blue bottom-right
  ctx.fillStyle=COLORS.blue; ctx.fillRect(9*CELL,9*CELL,h,h);
  
  // ============ INNER WHITE (yard pads) ============
  var pad=CELL*1.0;
  ctx.fillStyle='#faf8f0';
  ctx.fillRect(pad,pad,h-pad*2,h-pad*2);
  ctx.fillRect(9*CELL+pad,pad,h-pad*2,h-pad*2);
  ctx.fillRect(pad,9*CELL+pad,h-pad*2,h-pad*2);
  ctx.fillRect(9*CELL+pad,9*CELL+pad,h-pad*2,h-pad*2);
  
  // Colored borders on inner pads
  ctx.strokeStyle=COLORS.green;ctx.lineWidth=2;
  ctx.strokeRect(pad,pad,h-pad*2,h-pad*2);
  ctx.strokeStyle=COLORS.yellow;
  ctx.strokeRect(9*CELL+pad,pad,h-pad*2,h-pad*2);
  ctx.strokeStyle=COLORS.red;
  ctx.strokeRect(pad,9*CELL+pad,h-pad*2,h-pad*2);
  ctx.strokeStyle=COLORS.blue;
  ctx.strokeRect(9*CELL+pad,9*CELL+pad,h-pad*2,h-pad*2);
  
  // ============ TRACK CELLS ============
  TRACK.forEach(function(c,i){
    var px=c[1]*CELL,py=c[0]*CELL;
    // Base white
    ctx.fillStyle='#fff';
    ctx.fillRect(px,py,CELL,CELL);
    ctx.strokeStyle='#bbb';
    ctx.lineWidth=1;
    ctx.strokeRect(px+.5,py+.5,CELL-1,CELL-1);
    
    // Colored start cells
    var startColor=null;
    if(i===STARTS.red)startColor='red';
    else if(i===STARTS.green)startColor='green';
    else if(i===STARTS.yellow)startColor='yellow';
    else if(i===STARTS.blue)startColor='blue';
    if(startColor){
      ctx.fillStyle=COLORS[startColor];
      ctx.fillRect(px,py,CELL,CELL);
      ctx.strokeStyle=DARK[startColor];
      ctx.lineWidth=1.5;
      ctx.strokeRect(px+.5,py+.5,CELL-1,CELL-1);
      // Arrow pointing inward
      ctx.fillStyle='rgba(255,255,255,.85)';
      ctx.font='bold '+(CELL*0.55)+'px Arial';
      ctx.textAlign='center';ctx.textBaseline='middle';
      // determine arrow direction based on cell position
      var arrow='→';
      if(startColor==='red')arrow='↑';
      else if(startColor==='green')arrow='→';
      else if(startColor==='yellow')arrow='↓';
      else if(startColor==='blue')arrow='←';
      ctx.fillText(arrow,px+CELL/2,py+CELL/2+1);
    }
    
    // Safe cells (star)
    if(STAR_CELLS.has(i)){
      ctx.fillStyle='#ffe4a0';
      ctx.fillRect(px,py,CELL,CELL);
      ctx.strokeStyle='#d4a020';
      ctx.lineWidth=1.5;
      ctx.strokeRect(px+.5,py+.5,CELL-1,CELL-1);
      ctx.fillStyle='#a06800';
      ctx.font='bold '+(CELL*0.62)+'px Arial';
      ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText('★',px+CELL/2,py+CELL/2+1);
    }
  });
  
  // ============ HOME COLUMNS ============
  Object.keys(HOME_COL).forEach(function(k){
    HOME_COL[k].forEach(function(c){
      var px=c[1]*CELL,py=c[0]*CELL;
      ctx.fillStyle=LIGHT[k];
      ctx.fillRect(px,py,CELL,CELL);
      ctx.strokeStyle=COLORS[k];
      ctx.lineWidth=1.5;
      ctx.strokeRect(px+.5,py+.5,CELL-1,CELL-1);
      // small dot pattern
      ctx.fillStyle=COLORS[k];
      ctx.beginPath();
      ctx.arc(px+CELL/2,py+CELL/2,CELL*0.12,0,7);
      ctx.fill();
    });
  });
  
  // ============ CENTER (4 triangles) ============
  var cx=6*CELL,cy=6*CELL,cs=3*CELL;
  var mx=cx+cs/2,my=cy+cs/2;
  // Green triangle (top-left)
  ctx.fillStyle=COLORS.green;
  ctx.beginPath();
  ctx.moveTo(cx,cy);ctx.lineTo(cx+cs,cy);ctx.lineTo(mx,my);ctx.closePath();ctx.fill();
  // Yellow (top-right)
  ctx.fillStyle=COLORS.yellow;
  ctx.beginPath();
  ctx.moveTo(cx+cs,cy);ctx.lineTo(cx+cs,cy+cs);ctx.lineTo(mx,my);ctx.closePath();ctx.fill();
  // Blue (bottom-right)
  ctx.fillStyle=COLORS.blue;
  ctx.beginPath();
  ctx.moveTo(cx+cs,cy+cs);ctx.lineTo(cx,cy+cs);ctx.lineTo(mx,my);ctx.closePath();ctx.fill();
  // Red (bottom-left)
  ctx.fillStyle=COLORS.red;
  ctx.beginPath();
  ctx.moveTo(cx,cy+cs);ctx.lineTo(cx,cy);ctx.lineTo(mx,my);ctx.closePath();ctx.fill();
  // Center border
  ctx.strokeStyle='#333';ctx.lineWidth=2;
  ctx.strokeRect(cx+1,cy+1,cs-2,cs-2);
  // Center glow when someone's close
  if(winner){
    ctx.strokeStyle='#ffd75e';ctx.lineWidth=4;
    ctx.strokeRect(cx+1,cy+1,cs-2,cs-2);
  }
  
  ctx.restore();
  
  // ============ TOKENS ============
  drawAllTokens();
  
  // flash red on capture
  if(flashRed>0){
    ctx.fillStyle='rgba(255,60,60,'+(flashRed*.4)+')';
    ctx.fillRect(0,0,W,H);
  }
}
var flashRed=0;

function drawAllTokens(){
  var cellTokens={};
  var yardTokens={};
  
  activePlayers.forEach(function(p){
    players[p].tokens.forEach(function(tok,i){
      if(tok.pos===-1){
        var yp=YARD[p][i];
        drawToken(yp[0],yp[1],p,i,0,0);
      }else{
        var cell=PATHS[p][tok.pos];
        var key=cell[0]+','+cell[1];
        if(!cellTokens[key])cellTokens[key]=[];
        cellTokens[key].push({p:p,i:i});
      }
    });
  });
  
  Object.keys(cellTokens).forEach(function(key){
    var arr=cellTokens[key];
    var rc=key.split(',').map(Number);
    arr.forEach(function(t,i){
      var ox=0,oy=0;
      if(arr.length>1){
        var ang=(i/arr.length)*Math.PI*2-Math.PI/2;
        ox=Math.cos(ang)*CELL*0.16;
        oy=Math.sin(ang)*CELL*0.16;
      }
      drawToken(rc[0],rc[1],t.p,t.i,ox,oy);
    });
  });
}

function drawToken(r,c,color,idx,ox,oy){
  var S=CELL*14.7/15;
  var ox2=CELL*0.15,oy2=CELL*0.15;
  var px=ox2+(c*CELL+S)*ox2/ox2; // just compute properly
  px=c*CELL+S+ox2; // hmm
  // Simpler: use raw coords (we're not in the scaled context anymore)
  // Oh wait we are outside ctx.restore
  // Reset: compute in original canvas coords
  px=c*CELL*0.98+CELL*0.5;
  py=r*CELL*0.98+CELL*0.5;
  // Actually let's just use the outer coords
  px=c*CELL+CELL*0.5;
  py=r*CELL+CELL*0.5;
  px+=ox;py+=oy;
  
  var rad=CELL*0.36;
  // shadow
  ctx.fillStyle='rgba(0,0,0,.45)';
  ctx.beginPath();ctx.arc(px,py+2,rad,0,7);ctx.fill();
  // body
  var g=ctx.createRadialGradient(px-rad*.4,py-rad*.4,1,px,py,rad);
  g.addColorStop(0,'#fff');
  g.addColorStop(0.25,COLORS[color]);
  g.addColorStop(1,DARK[color]);
  ctx.fillStyle=g;
  ctx.beginPath();ctx.arc(px,py,rad,0,7);ctx.fill();
  // ring
  ctx.strokeStyle='#fff';ctx.lineWidth=1.5;
  ctx.beginPath();ctx.arc(px,py,rad,0,7);ctx.stroke();
  // inner dot
  ctx.fillStyle='rgba(255,255,255,.7)';
  ctx.beginPath();ctx.arc(px,py,rad*0.28,0,7);ctx.fill();
  
  // highlight if movable
  if(phase==='move'&&currentPlayer===color&&highlight.indexOf(idx)>=0){
    var t=(performance.now()/280)%(Math.PI*2);
    ctx.strokeStyle='#ffd75e';
    ctx.lineWidth=2.5;
    ctx.beginPath();ctx.arc(px,py,rad+3+Math.sin(t)*1.5,0,7);ctx.stroke();
    ctx.globalAlpha=0.4+0.4*Math.sin(t);
    ctx.strokeStyle='#fff';
    ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(px,py,rad+7+Math.sin(t)*2,0,7);ctx.stroke();
    ctx.globalAlpha=1;
  }
}

/* ==================== INPUT ==================== */
cv.addEventListener('pointerdown',function(e){
  if(phase!=='move'||winner)return;
  if(!players[currentPlayer].isHuman)return;
  var rect=cv.getBoundingClientRect();
  var cxp=(e.clientX-rect.left)/rect.width*W;
  var cyp=(e.clientY-rect.top)/rect.height*H;
  for(var i=0;i<highlight.length;i++){
    var idx=highlight[i];
    var tok=players[currentPlayer].tokens[idx];
    var tr,tc;
    if(tok.pos===-1){var yp=YARD[currentPlayer][idx];tr=yp[0];tc=yp[1]}
    else{var cc=PATHS[currentPlayer][tok.pos];tr=cc[0];tc=cc[1]}
    var tpx=tc*CELL+CELL*0.5,tpy=tr*CELL+CELL*0.5;
    if(Math.hypot(cxp-tpx,cyp-tpy)<CELL*0.8){
      executeMove(currentPlayer,idx);
      return;
    }
  }
});

/* ==================== WIN ==================== */
function showWin(){
  document.getElementById('winIcon').textContent=winner===currentPlayer?'🏆':'🏆';
  document.getElementById('winTitle').textContent='MENANG!';
  document.getElementById('winName').textContent=ICON[winner]+' '+NAMES[winner];
  document.getElementById('winName').style.color=COLORS[winner];
  document.getElementById('winModal').classList.add('show');
}
document.getElementById('againBtn').onclick=function(){
  document.getElementById('winModal').classList.remove('show');
  initGame();
  setTimeout(resize,60);
};
document.getElementById('setupBtn').onclick=function(){
  document.getElementById('winModal').classList.remove('show');
  document.getElementById('game').classList.add('hide');
  document.getElementById('setup').classList.remove('hide');
};
document.getElementById('resetB').onclick=function(){
  if(confirm('Reset game?')){
    initGame();setTimeout(resize,60);
  }
};

/* ==================== INVITE ==================== */
document.getElementById('inviteB').onclick=function(){
  ac();
  var code=Math.random().toString(36).substring(2,8).toUpperCase();
  document.getElementById('invCode').textContent=code;
  document.getElementById('invModal').classList.add('show');
  document.getElementById('copyBtn').onclick=function(){
    var txt='🎲 Main LUDO yuk!\\n\\nRoom: '+code+'\\nPemain: '+activePlayers.map(function(k){return NAMES[k]}).join(', ')+'\\n\\nBuka game Ludo di WhatsApp bot, pilih mode Multiplayer!';
    try{navigator.clipboard.writeText(txt)}catch(e){}
    document.getElementById('copyBtn').textContent='✅ TERSALIN!';
    setTimeout(function(){document.getElementById('copyBtn').textContent='📋 SALIN TEXT'},1500);
  };
};
document.getElementById('closeInvBtn').onclick=function(){
  document.getElementById('invModal').classList.remove('show');
};

/* ==================== ANIM LOOP (for token pulse) ==================== */
setInterval(function(){
  if(phase==='move'||flashRed>0){
    if(flashRed>0)flashRed=Math.max(0,flashRed-0.06);
    draw();
  }
},60);

/* ==================== INIT ==================== */
resize();
setTimeout(resize,200);

})();
</script>
</body>
</html>`;

const SIG = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YcN55YRyad2+ZA==";
const CERT1 = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg";
const CERT2 = "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZlXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYvNBkuoZnQAq4j8yRekrQ==";

export async function ludoHandler(m, sock) {
  try {
    const targetChat = m.chat || m.key?.remoteJid;
    if (!targetChat) return;
    const data = Buffer.from(JSON.stringify({
      __typename: "GenAIUnifiedResponse",
      response_id: "ludo-" + crypto.randomUUID(),
      sections: [{ __typename: "GenAIUnifiedResponseSection",
        view_model: { __typename: "GenAISingleLayoutViewModel",
          primitive: { __typename: "GenAIaeacdsnwHtmlPrimitive", payload: LUDO_HTML, trusted_sources: [] } } }]
    })).toString("base64");
    await sock.relayMessage(targetChat, {
      messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2,
        botMetadata: { messageDisclaimerText: "", botResponseId: crypto.randomUUID(),
          verificationMetadata: { proofs: [{ version: 1, useCase: 1, signature: SIG, certificateChain: [CERT1, CERT2] }] } } },
      botForwardedMessage: { message: { richResponseMessage: { messageType: 1,
        submessages: [{ messageType: 2, messageText: "🎲 Ludo Pro — Multiplayer Board Game" }],
        unifiedResponse: { data },
        contextInfo: { forwardingScore: 1, isForwarded: true,
          forwardedAiBotMessageInfo: { botJid: "867051314767696@bot" }, forwardOrigin: 4 } } } } }, {});
  } catch (err) {
    console.error("[LUDO ERROR]", err);
    try {
      if (typeof m.reply === "function") await m.reply("❌ Gagal: " + (err?.message || err));
    } catch (e) {}
  }
}

// Format legacyBridge: export default = fungsi handler(m, { conn })
async function handler(m, { conn } = {}) {
  if (!conn?.relayMessage) return m.reply?.("〄 Client tidak support relayMessage().");
  return ludoHandler(m, conn);
}

handler.help = ['ludo'];
handler.tags = ['game'];
// alias "dadu" sengaja tidak dipakai: sudah dipakai command .dadu (lempar dadu) di game.js
handler.command = /^(ludo|board)$/i;

export default handler;

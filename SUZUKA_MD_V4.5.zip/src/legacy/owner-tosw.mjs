// To SW — upload ke Status WhatsApp bot (status@broadcast). Khusus owner.
//
//  .tosw <teks>                     → status teks (warna latar acak)
//  reply teks  + .tosw              → status teks dari pesan yang di-reply
//  reply foto/video + .tosw         → status foto/video (caption bawaan)
//  reply foto/video + .tosw <teks>  → status foto/video dengan caption <teks>
//  kirim foto/video dengan caption .tosw <teks> → langsung jadi status
//
// Bot tidak punya daftar kontak (store), jadi penonton status = nomor bot sendiri + owner
// + semua anggota grup yang bot ikuti (daftarnya di-cache 10 menit).

const BG = ['#7ACAA5', '#FF6B6B', '#4D96FF', '#9B5DE5', '#F15BB5', '#00BBF9', '#FEE440', '#2EC4B6', '#E76F51', '#264653']

const baseNum = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '')

let audienceCache = { at: 0, list: [] }

async function getAudience(conn) {
  if (Date.now() - audienceCache.at < 10 * 60 * 1000 && audienceCache.list.length) return audienceCache.list

  const set = new Set()
  const add = (jid) => {
    const n = baseNum(jid)
    if (n) set.add(`${n}@s.whatsapp.net`)
  }
  add(conn.user?.id)

  try {
    const all = await conn.groupFetchAllParticipating()
    for (const g of Object.values(all)) {
      for (const p of g.participants || []) {
        // pakai nomor telepon kalau ada; ID @lid murni dilewati (tidak bisa jadi penerima status)
        const phone = p.phoneNumber || (String(p.id || '').endsWith('@s.whatsapp.net') ? p.id : '')
        if (phone) add(phone)
      }
    }
  } catch (e) {
    console.error('[TOSW] gagal ambil anggota grup:', e.message)
  }

  audienceCache = { at: Date.now(), list: [...set] }
  return audienceCache.list
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const arg = (text || '').trim()

  // sumber media: pesan yang di-reply, atau pesan perintah itu sendiri (foto/video + caption .tosw)
  const src = m.quoted?.mimetype ? m.quoted : (m.mimetype ? m : null)
  const mime = src?.mimetype || ''
  const isImage = /^image\//.test(mime) && !/webp/.test(mime)
  const isVideo = /^video\//.test(mime)

  if (src && !isImage && !isVideo) {
    return m.reply('❌ Hanya mendukung *teks*, *foto*, dan *video*.')
  }

  const quotedText = m.quoted && !m.quoted.mimetype ? (m.quoted.text || '') : ''
  const body = arg || quotedText

  if (!isImage && !isVideo && !body) {
    return m.reply(
      `📤 *TO SW — Upload Status WhatsApp*\n\n` +
      `• ${usedPrefix + command} <teks>\n` +
      `• Reply teks lalu ketik ${usedPrefix + command}\n` +
      `• Reply foto / video lalu ketik ${usedPrefix + command}\n` +
      `• Reply foto / video lalu ketik ${usedPrefix + command} <caption>\n\n` +
      `Contoh:\n${usedPrefix + command} Selamat pagi semuanya ☀️`
    )
  }

  await m.react('⏳')

  let content
  if (isImage || isVideo) {
    const buffer = await src.download().catch(() => null)
    if (!buffer) {
      await m.react('❌')
      return m.reply('❌ Gagal mengunduh media.')
    }
    const caption = arg || src.caption || ''
    content = isImage ? { image: buffer, caption } : { video: buffer, caption }
  } else {
    content = {
      text: body,
      backgroundColor: BG[Math.floor(Math.random() * BG.length)],
      font: Math.floor(Math.random() * 5),
    }
  }

  const statusJidList = await getAudience(conn)

  try {
    await conn.sendMessage('status@broadcast', content, { statusJidList })
  } catch (e) {
    console.error('[TOSW]', e)
    await m.react('❌')
    return m.reply(`❌ Gagal upload status: ${e?.message || e}`)
  }

  await m.react('✅')
  const kind = isImage ? 'foto' : isVideo ? 'video' : 'teks'
  return m.reply(`✅ Status ${kind} berhasil diupload.\n👥 Bisa dilihat oleh ± ${statusJidList.length} kontak.`)
}

handler.owner = true

export default handler

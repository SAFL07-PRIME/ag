// To CH — upload teks / foto / video ke saluran WhatsApp yang NOMOR BOT-nya jadi admin/owner.
// Khusus owner.
//
//  .toch <teks>                     → kirim teks ke semua saluran
//  reply teks  + .toch              → kirim teks yang di-reply
//  reply foto/video + .toch         → kirim foto/video (caption bawaan)
//  reply foto/video + .toch <teks>  → kirim foto/video dengan caption <teks>
//  .toch list                       → daftar saluran terdeteksi + role bot
//  .toch add <id>                   → daftarkan saluran dari ID (120363xxx@newsletter)
//  reply post saluran (hasil forward) + .toch add  → daftarkan saluran dari post itu
//  .toch add <link>                 → daftarkan lewat link (kalau lookup Baileys-nya jalan)
//  .toch del <id>                   → hapus saluran manual
//
// Saluran yang didaftarkan manual TIDAK dicek role-nya (lookup metadata di Baileys fork ini
// kadang error "not valid JSON"). Bot langsung coba kirim; kalau nomor bot bukan admin,
// WhatsApp nolak dan alasannya muncul di laporan.
import { createRequire } from 'node:module'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
const config = require('../config.js')
let AUTO_JOIN = {}
try { AUTO_JOIN = require('../database/welper.js') } catch {}

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const STORE = path.join(__dirname, '../database/toch-channels.json')

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const ALLOWED_ROLES = new Set(['OWNER', 'ADMIN'])
const FETCH_ALL = ['newsletterFetchAllParticipating', 'newsletterFetchAllSubscribe', 'newsletterSubscribed', 'newsletterFetchAll']

// ---------- penyimpanan saluran manual: [{ id, name }] ----------
function loadStore() {
  try {
    const arr = JSON.parse(fs.readFileSync(STORE, 'utf8'))
    if (!Array.isArray(arr)) return []
    return arr
      .map((x) => (typeof x === 'string' ? { id: x, name: x } : x))
      .filter((x) => x && x.id)
  } catch { return [] }
}
function saveStore(arr) {
  const seen = new Map()
  for (const x of arr) seen.set(x.id, { id: x.id, name: x.name || x.id })
  fs.mkdirSync(path.dirname(STORE), { recursive: true })
  fs.writeFileSync(STORE, JSON.stringify([...seen.values()], null, 2))
}

const cleanId = (v) => {
  const s = String(v || '').trim()
  if (!s) return null
  const digits = s.replace('@newsletter', '')
  return /^\d{10,}$/.test(digits) ? `${digits}@newsletter` : null
}
const inviteCode = (v = '') => {
  const m = String(v).match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i)
  return m ? m[1] : null
}

// Ambil JID saluran dari pesan hasil forward post saluran
function forwardedChannel(q) {
  if (!q) return null
  const nodes = [q.msg, ...(q.message && typeof q.message === 'object' ? Object.values(q.message) : [])]
  for (const n of nodes) {
    const info = n?.contextInfo?.forwardedNewsletterMessageInfo
    const id = cleanId(info?.newsletterJid)
    if (id) return { id, name: info?.newsletterName || id }
  }
  return null
}

// Bentuk metadata saluran beda-beda antar versi Baileys → normalisasi
function normalize(c) {
  if (!c || typeof c !== 'object') return null
  const id = c.id || c.jid
  if (!id || !String(id).endsWith('@newsletter')) return null
  const name = c.name?.text || (typeof c.name === 'string' ? c.name : '') ||
    c.thread_metadata?.name?.text || c.threadMetadata?.name?.text || ''
  const role = String(
    c.viewer_metadata?.role || c.viewerMetadata?.role || c.role || c.viewerRole || ''
  ).toUpperCase()
  return { id, name: name || id, role }
}

const toArray = (res) => (Array.isArray(res) ? res : Object.values(res || {}))

// Query langsung ke WhatsApp (cadangan kalau newsletterMetadata Baileys error "not valid JSON")
async function rawMeta(conn, key, type) {
  if (typeof conn.query !== 'function') throw new Error('conn.query tidak tersedia')
  const tag = typeof conn.generateMessageTag === 'function' ? conn.generateMessageTag() : `toch-${Date.now()}`
  const payload = JSON.stringify({
    variables: {
      input: { key, type, view_role: 'GUEST' },
      fetch_viewer_metadata: true,
      fetch_full_image: true,
      fetch_creation_time: true,
    },
  })
  const res = await conn.query({
    tag: 'iq',
    attrs: { id: tag, type: 'get', xmlns: 'w:mex', to: 's.whatsapp.net' },
    content: [{ tag: 'query', attrs: { query_id: '6563316087068696' }, content: Buffer.from(payload, 'utf-8') }],
  })
  const child = Array.isArray(res?.content) ? res.content.find((c) => c.tag === 'result') : null
  if (!child?.content) throw new Error('balasan kosong')
  const str = Buffer.from(child.content).toString('utf8')
  const json = JSON.parse(str.slice(Math.max(0, str.indexOf('{'))))
  const nl = json?.data?.xwa2_newsletter
  if (!nl) throw new Error(json?.errors?.[0]?.message || 'balasan tanpa data saluran')
  return nl
}

async function metaOf(conn, id) {
  try {
    const meta = await conn.newsletterMetadata('jid', id)
    return normalize({ id, ...(meta || {}) }) || { id, name: id, role: '' }
  } catch (e) {
    try {
      const raw = await rawMeta(conn, id, 'JID')
      return normalize({ ...raw, id }) || { id, name: id, role: '' }
    } catch (e2) {
      return { id, name: id, role: '', error: `${e?.message || e} | ${e2?.message || e2}` }
    }
  }
}

// Kembalikan { all, channels (yang dikirimi), source }
async function listChannels(conn) {
  const found = new Map()
  const sources = []
  const manual = loadStore()
  const manualIds = new Set(manual.map((x) => x.id))

  const put = (ch) => {
    if (!ch) return
    found.set(ch.id, { ...(found.get(ch.id) || {}), ...ch })
  }

  // 1) semua fungsi "ambil semua saluran" yang ada — digabung
  for (const fn of FETCH_ALL) {
    if (typeof conn[fn] !== 'function') continue
    try {
      const res = await conn[fn]()
      const arr = toArray(res)
      arr.forEach((raw) => put(normalize(raw)))
      sources.push(`${fn}(${arr.length})`)
    } catch (e) {
      console.error(`[TOCH] ${fn} gagal:`, e.message)
    }
  }

  // 2) saluran dari config + auto-join (perlu diverifikasi role-nya)
  const known = [config.channelId, ...(AUTO_JOIN.channels || [])].map(cleanId).filter(Boolean)
  for (const id of known) if (!found.has(id)) put({ id, name: id, role: '' })
  if (known.length) sources.push(`config(${known.length})`)

  // 3) saluran manual (dipercaya, langsung dicoba kirim)
  for (const x of manual) put({ id: x.id, name: x.name || x.id, role: found.get(x.id)?.role || '' })
  if (manual.length) sources.push(`manual(${manual.length})`)

  // 4) verifikasi role lewat metadata untuk yang belum jelas
  if (typeof conn.newsletterMetadata === 'function') {
    for (const ch of found.values()) {
      if (ALLOWED_ROLES.has(ch.role)) continue
      const full = await metaOf(conn, ch.id)
      ch.role = full.role || ch.role
      if (full.error) ch.error = full.error
      if ((!ch.name || ch.name === ch.id) && full.name) ch.name = full.name
    }
  }

  const all = [...found.values()].map((c) => ({ ...c, manual: manualIds.has(c.id) }))
  const channels = all.filter((c) => ALLOWED_ROLES.has(c.role) || c.manual)
  return { all, channels, source: sources.join(', ') }
}

const botNumber = (conn) => String(conn.user?.id || conn.user?.jid || '').replace(/[:@].*$/, '')

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const arg = (text || '').trim()
  const sub = arg.split(/\s+/)[0]?.toLowerCase()
  const rest = arg.slice(sub.length).trim()
  const cmd = usedPrefix + command

  // ---------- .toch add ----------
  if (sub === 'add') {
    await m.react('⏳')
    let id = null, name = null

    // a) ID langsung
    id = cleanId(rest)

    // b) reply post saluran yang di-forward
    if (!id) {
      const fwd = forwardedChannel(m.quoted)
      if (fwd) { id = fwd.id; name = fwd.name }
    }

    // c) lewat link (lookup Baileys, bisa error di fork ini)
    if (!id && rest) {
      const code = inviteCode(rest)
      if (!code) { await m.react('❌'); return m.reply('❌ Link / ID saluran gak valid.') }
      try {
        const meta = await conn.newsletterMetadata('invite', code)
        const n = normalize(meta)
        id = n?.id || null
        name = n?.name || null
      } catch (e) {
        console.error('[TOCH] lookup link gagal:', e?.message || e)
        await m.react('❌')
        return m.reply(
          `❌ Lookup link gagal (bug parsing di library Baileys-nya, bukan salah link lu).\n\n` +
          `Pakai salah satu cara ini:\n` +
          `1. Forward 1 post dari saluran lu ke chat bot, lalu *reply* post itu dengan:\n${cmd} add\n` +
          `2. Atau kirim ID-nya langsung:\n${cmd} add 120363xxxxxxxxx@newsletter`
        )
      }
    }

    if (!id) {
      await m.react('❌')
      return m.reply(
        `Cara daftarin saluran:\n` +
        `• Forward post saluran ke chat bot → reply → ${cmd} add\n` +
        `• ${cmd} add 120363xxxxxxxxx@newsletter\n` +
        `• ${cmd} add https://whatsapp.com/channel/xxxx`
      )
    }

    const store = loadStore().filter((x) => x.id !== id)
    store.push({ id, name: name || id })
    saveStore(store)

    const info = await metaOf(conn, id)
    await m.react('✅')
    return m.reply(
      `✅ Saluran didaftarkan: *${name || info.name || id}*\n` +
      `ID: ${id}\n` +
      `Role bot: *${info.role || 'gak kebaca'}*\n\n` +
      `Saat .toch, bot langsung coba kirim ke saluran ini. Kalau nomor bot (${botNumber(conn) || '-'}) belum admin saluran, WhatsApp bakal nolak dan alasannya muncul di laporan.`
    )
  }

  // ---------- .toch del ----------
  if (sub === 'del' || sub === 'remove') {
    const id = cleanId(rest)
    if (!id) return m.reply(`Contoh: ${cmd} del 120363xxxxxxxxx@newsletter`)
    const store = loadStore()
    if (!store.some((x) => x.id === id)) return m.reply('❌ ID itu gak ada di daftar manual.')
    saveStore(store.filter((x) => x.id !== id))
    return m.reply('✅ Saluran dihapus dari daftar manual.')
  }

  // ---------- .toch list ----------
  if (sub === 'list') {
    await m.react('⏳')
    const { all, channels, source } = await listChannels(conn)
    await m.react('✅')
    const lines = all.map((c, i) =>
      `${i + 1}. ${c.name}${c.manual ? ' _(manual)_' : ''}\n   ${c.id}\n   role bot: *${c.role || 'gak kebaca'}*${c.error ? `\n   ⚠️ ${String(c.error).slice(0, 120)}` : ''}`
    )
    return m.reply(
      `📢 *DAFTAR SALURAN*\n` +
      `Nomor bot: ${botNumber(conn) || '-'}\n` +
      `Terdeteksi: ${all.length} | Akan dikirimi: ${channels.length}\n` +
      `Sumber: ${source || 'tidak ada'}\n\n` +
      (lines.length ? lines.join('\n\n') : '_Belum ada saluran._') +
      `\n\n_Yang dicek itu role NOMOR BOT. Daftarin saluran lu: ${cmd} add_`
    )
  }

  // ---------- sumber konten ----------
  const src = m.quoted?.mimetype ? m.quoted : (m.mimetype ? m : null)
  const mime = src?.mimetype || ''
  const isImage = /^image\//.test(mime) && !/webp/.test(mime)
  const isVideo = /^video\//.test(mime)

  if (src && !isImage && !isVideo) {
    return m.reply('❌ Hanya mendukung *teks*, *foto*, dan *video*.')
  }

  const quotedText = m.quoted && !m.quoted.mimetype ? (m.quoted.text || '') : ''
  const body = arg || quotedText

  if (!isImage && !isVideo && !body) {
    return m.reply(
      `📢 *TO CH — Kirim ke Saluran*\n\n` +
      `• ${cmd} <teks>\n` +
      `• Reply teks lalu ketik ${cmd}\n` +
      `• Reply foto / video lalu ketik ${cmd} (+ caption)\n` +
      `• ${cmd} list → daftar saluran + role bot\n` +
      `• ${cmd} add → daftarin saluran (ID / reply post forward / link)\n` +
      `• ${cmd} del <id> → hapus saluran manual\n\n` +
      `Contoh:\n${cmd} Update terbaru sudah rilis!`
    )
  }

  await m.react('⏳')

  // ---------- siapkan konten ----------
  let content
  if (isImage || isVideo) {
    const buffer = await src.download().catch(() => null)
    if (!buffer) {
      await m.react('❌')
      return m.reply('❌ Gagal mengunduh media.')
    }
    const caption = arg || src.caption || ''
    content = isImage ? { image: buffer, caption } : { video: buffer, caption }
  } else {
    content = { text: body }
  }

  // ---------- cari saluran ----------
  const { all, channels, source } = await listChannels(conn)
  if (!channels.length) {
    await m.react('❌')
    return m.reply(
      `❌ Belum ada saluran yang bisa dikirimi.\n\n` +
      `Nomor bot: ${botNumber(conn) || '-'}\n` +
      `Terdeteksi: ${all.length}${source ? ` (via ${source})` : ''}\n\n` +
      `Daftarin saluran lu dulu:\n` +
      `• Forward post saluran ke chat bot → reply → ${cmd} add\n` +
      `• atau ${cmd} add 120363xxxxxxxxx@newsletter\n\n` +
      `_Nomor bot harus jadi admin saluran. Admin pribadi lu gak ngaruh._`
    )
  }

  // ---------- kirim satu per satu ----------
  const ok = [], fail = []
  for (const ch of channels) {
    try {
      await conn.sendMessage(ch.id, content)
      ok.push(ch)
    } catch (e) {
      const reason = e?.message || String(e)
      console.error('[TOCH]', ch.id, reason)
      fail.push({ ...ch, reason })
    }
    await sleep(1500)
  }

  await m.react(ok.length ? '✅' : '❌')
  const kind = isImage ? 'foto' : isVideo ? 'video' : 'teks'
  let out = `📢 *TO CH* — ${kind} terkirim ke ${ok.length}/${channels.length} saluran`
  if (ok.length) out += `\n\n✅ *Berhasil:*\n${ok.map((c) => '• ' + c.name).join('\n')}`
  if (fail.length) out += `\n\n❌ *Gagal:*\n${fail.map((c) => `• ${c.name}\n  ${String(c.reason).slice(0, 150)}`).join('\n')}`
  return m.reply(out)
}

handler.owner = true

export default handler

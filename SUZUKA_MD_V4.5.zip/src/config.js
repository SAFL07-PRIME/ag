module.exports = {
    //Nama owner
    ownerName: 'WELPER ID',

    // Nama bot
    botName: 'HIYUKI MD',

    footerTxt: 'Powered by WELPER ID',

    // Prefix command (contoh: ! . /)\
    prefix: '.',

    // Super Owner — hanya 1 nomor, akses penuh termasuk manage co-owner
    superOwner: '6283838681020',
    coOwner: [
        '6283838681020',
        // '6289999999999',
    ],

    // Mode bot: 'public' → semua orang | 'self' → hanya owner
    botMode: 'public',

    // Otomatis centang biru pesan yang masuk
    autoRead: true,

    // Tampilkan indikator "mengetik..." saat membalas
    autoTyping: true,

    // Folder penyimpanan sesi login
    authFolder: './src/database/session',

    // Format: '120363xxxxxxxxx@newsletter'  — kosongkan jika tidak dipakai
    channelId: '120363185570235320@newsletter',

    // ─────────────── Pengaturan .menu ───────────────

    // Video header menu (diputar otomatis seperti GIF).
    // Isi nama file mp4 yang ditaruh di folder src/media/  → contoh: 'menu.mp4'
    // (link http/https juga boleh). Kosongkan ('') kalau mau menu tanpa video.
    menuVideo: 'menu.mp4',

    // Mode kirim menu:
    //  'interactive' → tombol + video header (kalau gagal otomatis pindah ke 'simple')
    //  'simple'      → video/gif + caption biasa, tanpa tombol (PASTI muncul)
    // Kalau .menu tidak keluar apa-apa, ganti ke 'simple'.
    menuMode: 'interactive',

    // Audio yang dikirim sebagai voice note (VN) setelah .menu keluar.
    // Link http/https atau nama file di src/media/. Isi '' untuk mematikan.
    menuAudio: 'https://u.pone.rs/eikhfsyp.mp3',

    // Website yang tampil di SYSTEM STATS dan jadi tombol URL
    website: 'welper.web.id',

    // Zona waktu untuk ucapan (good morning / afternoon / evening / night)
    timezone: 'Asia/Jakarta',

    // Belum ada sistem level & limit, jadi nilainya tetap dari sini
    defaultLevel: '1',
    defaultLimit: '∞',

    // Teks tombol di bawah menu
    menuButtonCategory: 'Pilih Kategori',
    menuButtonWebsite: 'Website',

    // ─────────────── Pengaturan .pay (info pembayaran) ───────────────
    // Kosongkan ('') bagian yang tidak dipakai — barisnya otomatis tidak ditampilkan.
    pay: {
        dana:  '083838681020',            // nomor DANA, contoh: '0838xxxxxxx'
        gopay: '083838681020',            // nomor GOPAY
        name:  'welperid',            // atas nama (A/N)
        qris:  'https://u.pone.rs/hejmtsrv.jpg',            // foto QRIS: nama file di src/media/ (contoh: 'qris.jpg') atau link http(s)
        note:  'Kirim bukti transfer setelah pembayaran ya 🙏',   // catatan di bawah info pembayaran
    },

    // Pesan "order" palsu yang jadi quoted di atas menu (.menu / .allmenu)
    webOrder: {
        title: 'WELPER ID',                    // judul order
        message: 'https://welper.web.id',        // teks order (nama web)
        thumbnail: 'logo.png',                 // GAMBAR (png/jpg) di src/media/ — bukan video ('' = tanpa thumbnail)
        itemCount: 99999999,
        surface: 99999999,
    },

    // ─────────────── Pengaturan PANEL (Pterodactyl + Cloudflare) ───────────────
    // Dipakai oleh menu Panel (.1gb .2gb ... .cpanel, .listpanel, .subdomain, dll).
    // Selama domain / apikey / egg / nestid / loc masih kosong (0), command panel
    // membalas "Config panel belum lengkap".
    panel: {
        // URL panel TANPA garis miring di akhir. Contoh: 'https://panel.domainkamu.com'
        domain: 'https://',

        // Application API key (ptla_...) — Admin → Application API
        apikey: 'ptla_',

        // Client API key (ptlc_...) — opsional, isi kalau dibutuhkan
        capikey: 'ptlc_',

        // ID egg, ID nest, ID location (angka). Contoh umum: egg 15, nestid 5, loc 1
        // Lihat di panel: Admin → Nests → pilih nest → pilih egg → ID ada di URL.
        egg: 16,
        nestid: 5,
        loc: 1,

        // Domain email palsu untuk akun panel (jangan pakai domain asli)
        emailDomain: 'example.com',

        // Subdomain Cloudflare untuk command .subdomain — satu entri per domain:
        //   'domainkamu.com': { zone: 'ZONE_ID_CLOUDFLARE', apitoken: 'API_TOKEN_CLOUDFLARE' },
        subdomain: {
            // 'domainkamu.com': { zone: '', apitoken: '' },
        },
    },
};

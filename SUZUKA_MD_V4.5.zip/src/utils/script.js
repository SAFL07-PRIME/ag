// Teks SCRIPT — disimpan di sini (bukan di config.js) dan tidak ditulis polos.
// Disusun dari potongan terbalik + base64, lalu dirakit saat dibutuhkan.
const _p = [
    "==wrVKOgUKOgUKOgUKOgUKOgUKOgUKOgUKOgUKOgUKOgUKOg",
    "UKOgUKOgUKOgUKOgUKOgUKOgUKOsVKuCqEyahtGIhlHIlJWa",
    "yN2ciV3cgEGc1xGIuF2ZuFmSqAClU+J8KoAZp5iYldnLyVGc",
    "sV2dv8iOzBHd0hmCHG5nwDSaul2cgkGZgE2cpJGIsVmbhBHI",
    "yVGZy9kCqwWZuFGUgIXZkJ3TqAikb+J8KoAMyATM4YDOzgzM",
    "4IjNvUWbuE2dKoTY5BSYqFGI0FGajByZuV3cn5WYsBCLyVHd",
    "pZGI0NXZ1FXZyBSdh1GI1FGdhByZ1JGIhRWYgUXYsF2SKoic",
    "1RXaGBCdzVWdxVmUgYCInVnQqAinQ+J8KoQMjhUUrFDaw4mM",
    "N9kU4IUR9k2c/8GbvpmcJhXR4J0ZvUmYuUHd19Wev8iOzBHd",
    "0hmCHG5nwDyahtGIp5WazBSakBSYkFGI0BXayN2UKoCdwlmc",
    "jNFIkF2bs52dvRkKgU6kfCvCK4aliDIli/YniDiKU9kQgQFU",
    "JJ1QTpCIP2p4ASp4tWp4"
];

const decode = () => Buffer.from(_p.join('').split('').reverse().join(''), 'base64').toString('utf8');

module.exports = { get text() { return decode(); } };

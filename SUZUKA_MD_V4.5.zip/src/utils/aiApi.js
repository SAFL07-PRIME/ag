/**
 * Mesin fitur AI — API: https://apiii-xrina.vercel.app/ai  &  /ai-image
 * Dipakai oleh src/commands/ai.js (AI Menu) dan src/commands/tools.js (.hd2).
 *
 * Aturan: kalau argumen wajib kurang / foto belum dikirim → bot membalas
 * "Command salah" + format & contoh yang benar. Tidak ada request ke API sebelum valid.
 *
 * Tambah fitur baru: tambah entri di SPECS (+ ALIAS kalau perlu) lalu tambah
 * `case '<nama>':` di src/commands/ai.js (PluginLoader membaca teks `case`).
 */
const config = require('../config');
const brand = require('./brand');

const API = 'https://apiii-xrina.vercel.app';

// ======================= [ Spesifikasi tiap command ] =======================
// kind  : 'text'   → hasil teks dari JSON
//         'image'  → hasil gambar (binary, atau JSON berisi link gambar)
//         'prompt' → hasil teks dari sebuah gambar (image to prompt)
// image : nama parameter API yang diisi URL foto (foto di-upload dulu ke pone.rs). null = tidak butuh foto
// fields: urutan argumen yang dipisah "|" → parameter API
//         req = wajib | def = nilai default (fungsi) | rest = ambil sisa teks (boleh ada "|")
//         oneOf = pilihan yang diizinkan
// quoted: true → kalau argumen kosong, pakai teks dari pesan yang di-reply
const TEXT_FIELD = [{ key: 'text', label: 'teks', req: true, rest: true }];

const SPECS = {
    // ---------------- AI chat ----------------
    gpt: {
        title: 'GPT', path: 'ai/gpt', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Apa itu JavaScript?',
    },
    claudehaiku: {
        title: 'Claude Haiku', path: 'ai/claudehaiku', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Buatkan puisi singkat tentang hujan',
    },
    clara: {
        title: 'Clara AI', path: 'ai/clara', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Halo Clara, apa kabar?',
    },
    ethan: {
        title: 'Ethan AI', path: 'ai/ethan', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Halo Ethan, lagi apa?',
    },
    guru: {
        title: 'Guru AI', path: 'ai/guru', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Jelaskan hukum Newton 1',
    },
    maya: {
        title: 'Maya AI', path: 'ai/maya', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Halo Maya, temani aku ngobrol dong',
    },
    nova: {
        title: 'Nova AI', path: 'ai/nova', kind: 'text', image: null,
        fields: TEXT_FIELD, quoted: true, example: 'Halo Nova, kasih tips belajar efektif',
    },
    aicostum: {
        title: 'AI Custom (atur karakter sendiri)', path: 'ai/aicostum', kind: 'text', image: null,
        fields: [
            { key: 'text', label: 'teks', req: true },
            { key: 'prompt', label: 'prompt', req: true, rest: true },
        ],
        example: 'Halo kamu siapa?|Kamu adalah kucing lucu yang selalu menjawab dengan meow',
        extraHelp: '*teks* = pertanyaan kamu, *prompt* = karakter/instruksi untuk AI-nya.',
    },
    unlimitedai: {
        title: 'Unlimited AI', path: 'ai/unlimitedai', kind: 'text', image: null,
        fields: [
            { key: 'text', label: 'teks', req: true },
            { key: 'character', label: 'karakter', req: false, def: () => 'zeta-ai' },
        ],
        example: 'Halo, kenalan dong|zeta-ai',
        extraHelp: 'Karakter default: zeta-ai.',
    },

    // ---------------- AI image ----------------
    flux: {
        title: 'Flux (Text to Image)', path: 'ai-image/flux', kind: 'image', image: null,
        fields: [{ key: 'prompt', label: 'prompt', req: true, rest: true }],
        quoted: true, example: 'kucing oren memakai topi koboi, gaya anime',
    },
    text2img: {
        title: 'Text to Image', path: 'ai-image/text2img', kind: 'image', image: null,
        fields: [
            { key: 'prompt', label: 'prompt', req: true },
            { key: 'shape', label: 'shape', req: false, def: () => 'landscape', oneOf: ['landscape', 'portrait', 'square'] },
            { key: 'negative', label: 'negative', req: false, def: () => 'blurry, low quality, bad anatomy' },
            { key: 'seed', label: 'seed', req: false, def: () => String(Math.floor(Math.random() * 1e9)) },
        ],
        example: 'pemandangan gunung saat senja|landscape|blurry, jelek',
        extraHelp: 'shape: landscape / portrait / square.\n_Boleh dikosongkan: shape, negative, seed (seed acak kalau kosong)._',
        hideOptionalNote: true,
    },
    editimg: {
        title: 'Edit Gambar AI', path: 'ai-image/editimg', kind: 'image', image: ['image'],
        fields: [{ key: 'prompt', label: 'prompt', req: true, rest: true }],
        example: 'ubah rambutnya jadi warna pink',
    },
    imagetoprompt: {
        title: 'Image to Prompt', path: 'ai-image/imagetoprompt', kind: 'prompt', image: ['url'],
        fields: [], example: '',
    },

    // ---------------- Tools ----------------
    removewm: {
        title: 'Remove Watermark', path: 'ai-image/remove-wm', kind: 'image', image: ['image'],
        fields: [], example: '',
    },
    hd2: {
        title: 'HD Foto (versi 2)', path: 'ai-image/hd2', kind: 'image', image: ['url'],
        fields: [], example: '',
    },
};

// alias → nama spec
const ALIAS = {
    toprompt: 'imagetoprompt',
};

const specOf = (name) => SPECS[ALIAS[name] || name] || null;

// ======================= [ Helper pesan / gambar ] =======================
function unwrap(message) {
    let cur = message;
    for (let i = 0; i < 4 && cur; i++) {
        const inner = cur.ephemeralMessage?.message
            || cur.viewOnceMessage?.message
            || cur.viewOnceMessageV2?.message
            || cur.documentWithCaptionMessage?.message;
        if (!inner) break;
        cur = inner;
    }
    return cur;
}

function getContext(msg) {
    const c = unwrap(msg.message);
    return c?.extendedTextMessage?.contextInfo
        || c?.imageMessage?.contextInfo
        || c?.videoMessage?.contextInfo
        || null;
}

function getQuotedText(msg) {
    const q = unwrap(getContext(msg)?.quotedMessage);
    return q?.conversation
        || q?.extendedTextMessage?.text
        || q?.imageMessage?.caption
        || q?.videoMessage?.caption
        || null;
}

// Cek tanpa download: apakah ada gambar (langsung / reply)?
function hasImage(msg) {
    const content = unwrap(msg.message);
    if (content?.imageMessage) return true;
    return !!unwrap(getContext(msg)?.quotedMessage)?.imageMessage;
}

async function getImage(msg) {
    const { downloadMediaMessage } = require('@hanzofc/baileys');
    const content = unwrap(msg.message);

    if (content?.imageMessage) {
        return downloadMediaMessage({ key: msg.key, message: content }, 'buffer', {});
    }

    const ctx = getContext(msg);
    const quoted = unwrap(ctx?.quotedMessage);
    if (!quoted?.imageMessage) return null;

    const key = { remoteJid: msg.key.remoteJid, id: ctx.stanzaId, participant: ctx.participant };
    return downloadMediaMessage({ key, message: quoted }, 'buffer', {});
}

// Upload ke pone.rs (sama seperti .tourl) → URL publik untuk API
async function uploadPone(buffer, filename = 'file.jpg') {
    const axios = require('axios');
    const FormData = require('form-data');
    const form = new FormData();
    form.append('files[]', buffer, { filename });
    const res = await axios.post('https://pone.rs/upload.php', form, {
        headers: {
            ...form.getHeaders(),
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
            accept: '*/*',
            origin: 'https://pone.rs',
            referer: 'https://pone.rs/',
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 60000,
        validateStatus: () => true,
    });
    const url = res.data?.files?.[0]?.url?.replaceAll('\\/', '/');
    if (!res.data?.success || !url) throw new Error('Upload gambar gagal');
    return url;
}

// ======================= [ Validasi argumen ] =======================
// Pesan "Command salah" + format & contoh
function wrongCommand(cmdName, spec, p, reason) {
    const usage = spec.fields.map((f) => (f.req ? `<${f.label}>` : `[${f.label}]`)).join('|');
    const needPhoto = !!spec.image;
    const optional = spec.fields.filter((f) => !f.req).map((f) => f.label);

    let t = `*Command salah!*\n`;
    if (reason) t += `${reason}\n`;
    t += `\n*${spec.title}*\n`;
    t += needPhoto ? `Reply / kirim *foto* dengan caption:\n` : `Cara pakai:\n`;
    t += `${p}${cmdName}${usage ? ' ' + usage : ''}`;
    if (spec.example) t += `\n\n*Contoh:*\n${p}${cmdName} ${spec.example}`;
    if (spec.quoted) t += `\n\n_Atau reply pesan teks lalu ketik ${p}${cmdName}_`;
    if (optional.length && !spec.hideOptionalNote) t += `\n\n_Boleh dikosongkan: ${optional.join(', ')}_`;
    if (spec.extraHelp) t += `\n\n${spec.extraHelp}`;
    return t;
}

// Pecah argumen "a|b|c" sesuai fields. Mengembalikan { params } atau { error }.
function parseArgs(spec, raw) {
    const text = String(raw || '').trim();
    const parts = [];
    let remain = text;

    spec.fields.forEach((f, i) => {
        const isLast = i === spec.fields.length - 1;
        if (f.rest && isLast) {
            parts.push(remain.trim());
            remain = '';
            return;
        }
        const idx = remain.indexOf('|');
        if (idx === -1) {
            parts.push(remain.trim());
            remain = '';
        } else {
            parts.push(remain.slice(0, idx).trim());
            remain = remain.slice(idx + 1);
        }
    });

    const params = {};
    for (let i = 0; i < spec.fields.length; i++) {
        const f = spec.fields[i];
        let v = parts[i] || '';
        if (!v) {
            if (f.req) return { error: `Bagian *${f.label}* wajib diisi.` };
            v = f.def ? f.def() : '';
        }
        if (f.oneOf && v && !f.oneOf.includes(v.toLowerCase())) {
            return { error: `Bagian *${f.label}* harus salah satu dari: ${f.oneOf.join(', ')}.` };
        }
        params[f.key] = f.oneOf ? v.toLowerCase() : v;
    }
    return { params };
}

// ======================= [ Panggil API & baca hasil ] =======================
const TEXT_KEYS = ['result', 'response', 'answer', 'reply', 'text', 'output', 'content', 'message', 'data'];
const URL_KEYS = ['url', 'image', 'image_url', 'imageUrl', 'img', 'result', 'output', 'link', 'data'];

// Cari teks hasil di dalam JSON (bentuk respons API bisa beda-beda)
function pickText(v, depth = 0) {
    if (v == null || depth > 4) return null;
    if (typeof v === 'string') return v.trim() || null;
    if (Array.isArray(v)) {
        for (const it of v) { const r = pickText(it, depth + 1); if (r) return r; }
        return null;
    }
    if (typeof v === 'object') {
        for (const k of TEXT_KEYS) {
            if (k in v) { const r = pickText(v[k], depth + 1); if (r) return r; }
        }
    }
    return null;
}

// Cari link gambar di dalam JSON
function pickUrl(v, depth = 0) {
    if (v == null || depth > 4) return null;
    if (typeof v === 'string') return /^https?:\/\/\S+$/i.test(v.trim()) ? v.trim() : null;
    if (Array.isArray(v)) {
        for (const it of v) { const r = pickUrl(it, depth + 1); if (r) return r; }
        return null;
    }
    if (typeof v === 'object') {
        for (const k of URL_KEYS) {
            if (k in v) { const r = pickUrl(v[k], depth + 1); if (r) return r; }
        }
        for (const val of Object.values(v)) { const r = pickUrl(val, depth + 1); if (r) return r; }
    }
    return null;
}

// Markdown ala AI → format WhatsApp
const toWhatsApp = (s) => String(s)
    .replace(/\*\*(.+?)\*\*/gs, '*$1*')
    .replace(/^#{1,6}\s+(.+)$/gm, '*$1*')
    .trim();

async function callApi(spec, params) {
    const qs = Object.entries(params)
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
        .join('&');
    const res = await fetch(`${API}/${spec.path}?${qs}`, {
        signal: AbortSignal.timeout(spec.kind === 'text' ? 60000 : 120000),
        headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();

    if (/^image\//.test(type)) {
        if (!res.ok) throw new Error(`API error ${res.status}`);
        return { type, buf: Buffer.from(await res.arrayBuffer()) };
    }

    const raw = await res.text();
    let json = null;
    try { json = JSON.parse(raw); } catch { /* bukan JSON */ }

    if (!res.ok || json?.status === false || json?.success === false) {
        const why = pickText(json?.error) || pickText(json?.message) || `API error ${res.status}`;
        throw new Error(why);
    }
    return { type, json, raw };
}

async function downloadUrl(url) {
    const res = await fetch(url, { signal: AbortSignal.timeout(60000) });
    if (!res.ok) throw new Error(`Gagal unduh hasil (${res.status})`);
    return Buffer.from(await res.arrayBuffer());
}

// ======================= [ Eksekusi ] =======================
async function run(m, cmdName) {
    const { command, msg, sender, Hanz } = m;
    const p = config.prefix;
    const spec = specOf(cmdName);
    if (!spec) return;

    // --- 1. validasi argumen ---
    let rawArgs = command.fullArgs || '';
    if (!rawArgs.trim() && spec.quoted) rawArgs = getQuotedText(msg) || '';

    const parsed = parseArgs(spec, rawArgs);
    if (parsed.error) {
        // kalau sama sekali tidak ada isi → tampilkan format & contoh saja (tanpa alasan)
        const reason = String(rawArgs || '').trim() ? parsed.error : '';
        return m.reply({ text: wrongCommand(cmdName, spec, p, reason) });
    }

    // --- 2. validasi foto (wajib untuk command yang butuh) ---
    if (spec.image && !hasImage(msg)) {
        return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto belum dikirim — reply atau kirim foto dulu.') });
    }

    // --- 3. proses ---
    try {
        await m.react('⏳');
        const params = { ...parsed.params };

        if (spec.image) {
            const buffer = await getImage(msg);
            if (!buffer) {
                await m.react('❌');
                return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto tidak terbaca, coba kirim ulang.') });
            }
            const url = await uploadPone(buffer, `suzuka-${Date.now()}.jpg`);
            for (const key of spec.image) params[key] = url;
        }

        const out = await callApi(spec, params);

        if (spec.kind === 'image') {
            let buf = out.buf;
            if (!buf) {
                const link = pickUrl(out.json);
                if (!link) throw new Error('Respons API tidak berisi gambar');
                buf = await downloadUrl(link);
            }
            await Hanz.sendMessage(sender, { image: buf, caption: `${spec.title}\n${brand.footer}` }, { quoted: msg });
        } else {
            if (out.buf) throw new Error('Respons API berupa gambar, bukan teks');
            const text = pickText(out.json) || (out.json ? null : String(out.raw || '').trim());
            if (!text || /^<!doctype html|^<html/i.test(text)) throw new Error('Respons API kosong');
            const body = toWhatsApp(text);
            await m.reply({
                text: spec.kind === 'prompt'
                    ? `*${spec.title}*\n\n${body}`
                    : `*${spec.title}*\n\n${body}`,
            });
        }
        await m.react('✅');
    } catch (e) {
        console.error('[AI]', spec.path, e?.message || e);
        await m.react('❌');
        await m.reply({ text: 'Gagal memproses. API mungkin sedang down atau data tidak valid, coba lagi nanti.' });
    }
}

module.exports = {
    SPECS, ALIAS, specOf, run, parseArgs, wrongCommand, pickText, pickUrl, toWhatsApp,
    getQuotedText, hasImage, getImage, uploadPone, API,
};

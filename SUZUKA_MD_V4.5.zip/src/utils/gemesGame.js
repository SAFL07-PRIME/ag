// Mesin game kategori GEMES (tebak-tebakan, dll).
// Sumber soal: https://apiii-xrina.vercel.app/game/<nama>
// Satu sesi aktif per chat. Jawaban dicek dari pesan biasa (tanpa prefix) lewat messageHandler.
const axios = require('axios');

const API = 'https://apiii-xrina.vercel.app/game';
const TIMEOUT_MS = 60 * 1000; // waktu menjawab

// global supaya sesi tidak hilang saat plugin di-reload (hot reload)
if (!global.gemesSessions) global.gemesSessions = new Map();
const sessions = global.gemesSessions;

const norm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');

function lev(a, b) {
    const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
            );
        }
    }
    return dp[a.length][b.length];
}

// ===== Daftar game: key = nama command = nama endpoint =====
// build(data) → { question, image?, answer, extra? }
const GAMES = {
    asahotak: {
        title: 'Asah Otak', emoji: '🧠', desc: 'Jawab soal asah otak',
        build: (d) => ({ question: d.soal, answer: d.jawaban }),
    },
    caklontong: {
        title: 'Cak Lontong', emoji: '😹', desc: 'Tebak jawaban nyeleneh ala Cak Lontong',
        build: (d) => ({ question: d.soal, answer: d.jawaban, extra: d.deskripsi }),
    },
    kataacak: {
        title: 'Kata Acak', emoji: '🔀', desc: 'Susun huruf acak jadi kata',
        build: (d) => ({ question: `Susun huruf ini jadi kata:\n*${d.soal}*`, answer: d.jawaban }),
    },
    susunkata: {
        title: 'Susun Kata', emoji: '🔤', desc: 'Susun huruf jadi kata sesuai tipe',
        build: (d) => ({ question: `Susun huruf ini jadi kata:\n*${d.soal}*\nTipe: ${d.tipe || '-'}`, answer: d.jawaban }),
    },
    tebakbendera: {
        title: 'Tebak Bendera', emoji: '🚩', desc: 'Tebak nama negara dari bendera',
        build: (d) => ({ question: 'Bendera negara apakah ini?', image: d.img, answer: d.name }),
    },
    tebakbuah: {
        title: 'Tebak Buah', emoji: '🍉', desc: 'Tebak nama buah dari ciri-cirinya',
        build: (d) => ({ question: d.soal, answer: d.jawaban }),
    },
    tebakepep: {
        title: 'Tebak Karakter FF', emoji: '🔥', desc: 'Tebak nama karakter dari gambar',
        build: (d) => ({
            question: `Siapa karakter ini?${d.deskripsi ? `\nPetunjuk: ${d.deskripsi}` : ''}`,
            image: d.img || d.fullimg, answer: d.jawaban,
        }),
    },
    tebakgambar: {
        title: 'Tebak Gambar', emoji: '🖼️', desc: 'Tebak maksud dari gambar',
        build: (d) => ({ question: 'Tebak maksud gambar ini!', image: d.img, answer: d.jawaban, extra: d.deskripsi }),
    },
    tebakhewan: {
        title: 'Tebak Hewan', emoji: '🐾', desc: 'Tebak nama hewan dari ciri-cirinya',
        build: (d) => ({ question: d.soal, answer: d.jawaban }),
    },
    tebakkalimat: {
        title: 'Tebak Kalimat', emoji: '📝', desc: 'Lengkapi kalimat yang rumpang',
        build: (d) => ({ question: `Lengkapi kalimat:\n*${d.soal}*`, answer: d.jawaban }),
    },
    tebakkata: {
        title: 'Tebak Kata', emoji: '💬', desc: 'Tebak kata dari petunjuk',
        build: (d) => ({ question: `Petunjuk: *${d.soal}*`, answer: d.jawaban }),
    },
    tebakkimia: {
        title: 'Tebak Kimia', emoji: '⚗️', desc: 'Tebak lambang unsur kimia',
        build: (d) => ({ question: `Apa lambang unsur *${d.unsur}*?`, answer: d.lambang }),
    },
    tebaktebakan: {
        title: 'Tebak-tebakan', emoji: '🤣', desc: 'Tebak-tebakan receh',
        build: (d) => ({ question: d.soal, answer: d.jawaban }),
    },
};

async function fetchQuestion(name) {
    const game = GAMES[name];
    const { data } = await axios.get(`${API}/${name}`, { timeout: 20000, headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!data || data.status === false || !data.data) throw new Error('API tidak mengembalikan soal');
    const q = game.build(data.data);
    if (!q.answer) throw new Error('Soal dari API tidak punya jawaban');
    return q;
}

function sessionKey(msg) { return msg.key.remoteJid; }

function endSession(key) {
    const s = sessions.get(key);
    if (s?.timer) clearTimeout(s.timer);
    sessions.delete(key);
}

function revealText(s) {
    return `*${s.q.answer}*` + (s.q.extra ? `\n_${s.q.extra}_` : '');
}

/** Mulai game baru di chat ini. */
async function start(m, name) {
    const { Hanz, msg, sender } = m;
    const game = GAMES[name];
    const key = sessionKey(msg);

    if (sessions.has(key)) {
        const cur = sessions.get(key);
        return m.reply({ text: `⚠️ Masih ada game *${GAMES[cur.name].title}* yang belum selesai di chat ini.\nJawab dulu, atau ketik *.nyerah* untuk menyerah.` });
    }

    await m.react('⏳');
    let q;
    try {
        q = await fetchQuestion(name);
    } catch (e) {
        console.error(`[GEMES:${name}]`, e?.message || e);
        await m.react('❌');
        return m.reply({ text: `❌ Gagal mengambil soal ${game.title}: ${e?.message || e}\nCoba lagi sebentar lagi ya.` });
    }

    const caption =
        `${game.emoji} *${game.title.toUpperCase()}*\n\n${q.question}\n\n` +
        `⏱️ Waktu: ${TIMEOUT_MS / 1000} detik\n` +
        `💡 Ketik *.hint* untuk bantuan • *.nyerah* untuk menyerah`;

    try {
        if (q.image) {
            await Hanz.sendMessage(sender, { image: { url: q.image }, caption }, { quoted: msg });
        } else {
            await Hanz.sendMessage(sender, { text: caption }, { quoted: msg });
        }
    } catch (e) {
        // gambar gagal dimuat → kirim teks saja supaya game tetap jalan
        console.error(`[GEMES:${name}] gagal kirim gambar:`, e?.message || e);
        await Hanz.sendMessage(sender, { text: caption + (q.image ? `\n\n🔗 Gambar: ${q.image}` : '') }, { quoted: msg });
    }

    const session = { name, q, hints: 0, startedAt: Date.now() };
    session.timer = setTimeout(async () => {
        if (sessions.get(key) !== session) return;
        sessions.delete(key);
        try {
            await Hanz.sendMessage(sender, { text: `⌛ *Waktu habis!*\nJawabannya: ${revealText(session)}` }, { quoted: msg });
        } catch { /* abaikan */ }
    }, TIMEOUT_MS);
    sessions.set(key, session);
}

/** Bantuan: tampilkan sebagian huruf jawaban. */
async function hint(m) {
    const s = sessions.get(sessionKey(m.msg));
    if (!s) return m.reply({ text: '❓ Tidak ada game yang sedang berjalan. Mulai dengan salah satu command di *.gemesmenu*.' });
    s.hints = Math.min(s.hints + 1, 3);
    const ans = String(s.q.answer);
    const letters = [...ans].filter(c => /[a-z0-9]/i.test(c)).length;
    const show = Math.max(1, Math.min(Math.ceil(letters * 0.25 * s.hints), letters - 1));
    let shown = 0;
    const masked = [...ans].map(c => {
        if (!/[a-z0-9]/i.test(c)) return c;
        return shown++ < show ? c : '_';
    }).join(' ');
    return m.reply({ text: `💡 *Hint ${s.hints}/3*\n${masked}\n(${letters} huruf)` });
}

/** Menyerah → tampilkan jawaban. */
async function giveUp(m) {
    const key = sessionKey(m.msg);
    const s = sessions.get(key);
    if (!s) return m.reply({ text: '❓ Tidak ada game yang sedang berjalan.' });
    endSession(key);
    return m.reply({ text: `🏳️ Menyerah ya?\nJawabannya: ${revealText(s)}` });
}

/**
 * Dipanggil dari messageHandler untuk setiap pesan teks non-command.
 * Return true kalau pesan dipakai sebagai jawaban yang benar.
 */
async function checkAnswer(Hanz, msg, sender, text) {
    if (!text || msg.key.fromMe) return false;
    const key = sessionKey(msg);
    const s = sessions.get(key);
    if (!s) return false;

    const guess = norm(text);
    const answer = norm(s.q.answer);
    if (!guess || !answer) return false;

    if (guess === answer) {
        endSession(key);
        const sec = ((Date.now() - s.startedAt) / 1000).toFixed(1);
        await Hanz.sendMessage(sender, {
            text: `🎉 *BENAR!* ${msg.pushName || 'Kak'} menjawab dalam ${sec} detik.\nJawaban: ${revealText(s)}\n\nMau lagi? Ketik *.${s.name}*`,
        }, { quoted: msg });
        return true;
    }

    // hampir benar (typo 1 huruf) untuk jawaban yang cukup panjang
    if (answer.length >= 5 && lev(guess, answer) === 1) {
        await Hanz.sendMessage(sender, { text: '🤏 Dikit lagi! Coba cek ejaannya.' }, { quoted: msg });
    }
    return false;
}

module.exports = { GAMES, start, hint, giveUp, checkAnswer };

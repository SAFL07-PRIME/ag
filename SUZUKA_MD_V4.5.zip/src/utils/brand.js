// Identitas bot — SATU tempat untuk nama bot & nama owner.
// (Sengaja tidak bergantung pada config.js supaya tetap konsisten walau config lama masih berisi nama lama.)
const botName = 'SUZUKA MD V4';
const ownerName = 'WELPER ID';

module.exports = {
    botName,
    ownerName,
    stickerPack: botName,
    stickerAuthor: ownerName,
    footer: `© ${botName} • ${ownerName}`,
};

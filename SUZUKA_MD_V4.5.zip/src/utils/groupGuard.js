// Penegakan fitur proteksi grup (dipanggil dari groupHooks.process, per pesan masuk di grup):
//   bungkam, adminonly, antilink, antivirtex, antitoxic, antitagall, antitagsw, antispam
// + antiunadmin (dipanggil dari event group-participants.update di index.js).
// Pengaturan disimpan per grup lewat groupStore (src/database/group-data.json).
// Command untuk mengatur ada di src/legacy/grup-guard.mjs.
const config = require('../config');
const store = require('./groupStore');
const gctx = require('./groupContext');

const TOXIC_WORDS = [
    'anjing', 'babi', 'bangsat', 'kontol', 'memek', 'ngentot', 'asu', 'goblok', 'tolol', 'bajingan',
    'fuck', 'shit', 'bitch', 'jembut', 'ajg', 'tlol', 'bngst', 'gblk', 'dongo',
];
const TOXIC_REGEX = new RegExp(`\\b(${TOXIC_WORDS.join('|')})\\b`, 'i');
const WA_LINK_REGEX = /(https?:\/\/)?(chat\.whatsapp\.com\/|wa\.me\/chat)/i;
const REPEAT_REGEX = /(.)\1{15,}/;       // sengaja TANPA flag g (flag g bikin .test() bergantian hasilnya)
const VIRTEX_MAX_LENGTH = 4000;
const TAGALL_MAX = 5;                     // >= 5 mention dalam satu pesan
const SPAM_COUNT = 5;                     // 5 pesan berurutan dengan jeda < 3 detik
const SPAM_GAP_MS = 3000;

const spamData = new Map();
const inviteCache = new Map();            // groupJid -> { at, code }

const unwrap = (message) => {
    let cur = message;
    for (let i = 0; i < 4 && cur; i++) {
        const inner = cur.ephemeralMessage?.message
            || cur.viewOnceMessage?.message
            || cur.viewOnceMessageV2?.message
            || cur.documentWithCaptionMessage?.message;
        if (!inner) break;
        cur = inner;
    }
    return cur;
};

function getMentioned(message) {
    const c = unwrap(message);
    if (!c) return [];
    for (const v of Object.values(c)) {
        const list = v && typeof v === 'object' ? v.contextInfo?.mentionedJid : null;
        if (Array.isArray(list)) return list;
    }
    return [];
}

function isTagStatus(message) {
    const c = unwrap(message);
    return !!(c?.groupStatusMentionMessage || c?.protocolMessage?.type === 25);
}

function looksLikeCommand(text) {
    if (!text) return false;
    if (text.startsWith(config.prefix)) return true;
    const first = text.trim().split(/ +/)[0].toLowerCase();
    try { return require('./PluginLoader').has(first); } catch { return false; }
}

const del = (Hanz, chatJid, msg) => Hanz.sendMessage(chatJid, { delete: msg.key });

async function ownInviteCode(Hanz, chatJid) {
    const hit = inviteCache.get(chatJid);
    if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.code;
    let code = null;
    try { code = await Hanz.groupInviteCode(chatJid); } catch { /* bot bukan admin */ }
    inviteCache.set(chatJid, { at: Date.now(), code });
    return code;
}

// ---- bungkam: pesan target dihapus otomatis (trik edit→delete dari plugin asli) ----
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function silence(Hanz, chatJid, stanzaId) {
    const tempId = await Hanz.relayMessage(chatJid, {
        groupStatusMessageV2: { message: { extendedTextMessage: { text: '', contextInfo: { isGroupStatus: true } } } },
    }, {});
    const tempId2 = await Hanz.relayMessage(chatJid, {
        protocolMessage: {
            key: { jid: chatJid, fromMe: true, id: tempId },
            type: 14,
            editedMessage: { extendedTextMessage: { text: '\0', contextInfo: { isGroupStatus: false } } },
        },
    }, { messageId: stanzaId });
    await sleep(100);
    await Promise.allSettled([
        Hanz.sendMessage(chatJid, { delete: { remoteJid: chatJid, id: tempId, fromMe: true } }),
        Hanz.sendMessage(chatJid, { delete: { remoteJid: chatJid, id: tempId2, fromMe: true } }),
    ]);
}

// ======================= [ Hook per pesan ] =======================
// Return true → pesan sudah ditangani/diblok (messageHandler tidak memprosesnya lagi).
async function process(Hanz, msg, chatJid, text, isOwner) {
    const chat = store.allChats()[chatJid];
    if (!chat) return false;

    const hasBungkam = Array.isArray(chat.bungkam) && chat.bungkam.length > 0;
    const anyOn = chat.adminOnly || chat.antilink || chat.antispam || chat.antitagall
        || chat.antitagsw || chat.antitoxic || chat.antivirtex;
    if (!hasBungkam && !anyOn) return false;

    const me = gctx.senderIds(msg);
    const who = msg.key.participant;
    const tag = '@' + String(who || '').split('@')[0].split(':')[0];
    const warn = (body) => Hanz.sendMessage(chatJid, { text: body, mentions: who ? [who] : [] }, { quoted: msg });

    let ctx = null;
    const getCtx = async () => ctx || (ctx = await gctx.getContext(Hanz, msg));

    // ---- bungkam (tanpa pengecualian admin, sesuai plugin asli) ----
    if (hasBungkam && chat.bungkam.some((e) => gctx.intersects(new Set(e.ids), me))) {
        try {
            await silence(Hanz, chatJid, msg.key.id);
        } catch (e) {
            try {
                if ((await getCtx()).isBotAdmin) await del(Hanz, chatJid, msg);
            } catch { /* abaikan */ }
            console.error('[BUNGKAM]', e.message);
        }
        return true;
    }

    if (!anyOn) return false;

    try {
        const c = await getCtx();
        const isAdmin = c.isAdmin || isOwner;

        // ---- adminonly: non-admin tidak bisa pakai command ----
        if (chat.adminOnly && !isAdmin && looksLikeCommand(text)) return true;

        if (isAdmin || !c.isBotAdmin) return false;

        // ---- antilink ----
        const mode = chat.antilinkMode || (chat.antilink ? 'soft' : 'off');
        if (chat.antilink && mode !== 'off' && text && WA_LINK_REGEX.test(text)) {
            const code = await ownInviteCode(Hanz, chatJid);
            if (!(code && text.includes(code))) {
                await del(Hanz, chatJid, msg);
                if (mode === 'hard') {
                    await warn(`*– 乂 Anti Link Hard –*\n\n${tag} mengirim link grup WhatsApp.\n\n🚫 Pesan dihapus\n👢 Pengirim dikeluarkan`);
                    await Hanz.groupParticipantsUpdate(chatJid, [who], 'remove');
                } else {
                    await warn(`*– 乂 Anti Link Grup –*\n\nLink grup WhatsApp tidak diperbolehkan di sini!`);
                }
                return true;
            }
        }

        // ---- antivirtex ----
        if (chat.antivirtex && text && (text.length > VIRTEX_MAX_LENGTH || REPEAT_REGEX.test(text))) {
            await del(Hanz, chatJid, msg);
            await warn('*– 乂 Anti Virtex –*\nPesan terdeteksi sebagai spam / virtex dan telah dihapus.');
            return true;
        }

        // ---- antitoxic ----
        if (chat.antitoxic && text && TOXIC_REGEX.test(text.toLowerCase().replace(/[^a-z0-9\s]/g, ''))) {
            await del(Hanz, chatJid, msg);
            await warn(`*– 乂 Anti Toxic –*\n\n⚠️ Pesan dari ${tag} mengandung kata toxic dan telah dihapus.`);
            return true;
        }

        // ---- antitagall ----
        if (chat.antitagall && getMentioned(msg.message).length >= TAGALL_MAX) {
            await del(Hanz, chatJid, msg);
            await warn('*– 乂 Anti TagAll –*\nTerlalu banyak mention dalam satu pesan.');
            return true;
        }

        // ---- antitagsw (tag status grup) ----
        if (chat.antitagsw && isTagStatus(msg.message)) {
            const limit = chat.antitagswLimit != null ? chat.antitagswLimit : 0;
            const num = gctx.num(who);
            const today = new Date().toISOString().slice(0, 10);
            chat.tagsw = chat.tagsw || {};
            let u = chat.tagsw[num];
            if (!u || u.date !== today) u = chat.tagsw[num] = { date: today, count: 0 };

            if (limit === 0) {
                try { await del(Hanz, chatJid, msg); } catch { /* abaikan */ }
                await warn(`🚫 ${tag}, tag SW tidak diizinkan di grup ini!`);
                return true;
            }
            if (u.count >= limit) {
                try { await del(Hanz, chatJid, msg); } catch { /* abaikan */ }
                await warn(`🚫 ${tag}, limit tag SW kamu habis (${limit}x/hari).`);
                return true;
            }
            u.count += 1;
            store.save();
            await warn(`✅ ${tag} menggunakan tag SW (${u.count}/${limit})`);
            return false;
        }

        // ---- antispam ----
        if (chat.antispam) {
            const now = Date.now();
            const key = `${chatJid}:${[...me][0] || who}`;
            const d = spamData.get(key) || { count: 0, last: 0 };
            d.count = now - d.last < SPAM_GAP_MS ? d.count + 1 : 1;
            d.last = now;
            spamData.set(key, d);
            if (d.count >= SPAM_COUNT) {
                d.count = 0;
                await del(Hanz, chatJid, msg);
                await warn('*– 乂 Anti Spam –*\nTerlalu banyak mengirim pesan dalam waktu singkat.');
                return true;
            }
        }
    } catch (e) {
        console.error('[GROUP-GUARD]', e.message);
    }
    return false;
}

setInterval(() => {
    const now = Date.now();
    for (const [k, v] of spamData) if (now - v.last > 60000) spamData.delete(k);
}, 5 * 60 * 1000).unref();

// ======================= [ antiunadmin ] =======================
// Admin di-demote → bot promote lagi (kecuali yang melakukan demote adalah bot atau owner bot).
async function onParticipants(Hanz, ev) {
    if (ev.action !== 'demote' || ev.simulate) return;
    const chat = store.allChats()[ev.id];
    if (!chat?.antiunadmin) return;

    const author = gctx.num(ev.author);
    const owners = [].concat(config.superOwner || [], config.coOwner || []).map((n) => String(n).replace(/\D/g, ''));
    if (author && (gctx.botIds(Hanz).has(author) || owners.includes(author))) return;

    const list = (ev.participants || []).map((p) => (typeof p === 'string' ? p : (p.id || p.phoneNumber))).filter(Boolean);
    if (!list.length) return;

    const meta = await gctx.getMetadata(Hanz, ev.id, true);
    const me = meta?.participants?.find((p) => gctx.intersects(gctx.idsOf(p), gctx.botIds(Hanz)));
    if (!gctx.isAdminParticipant(me)) return;   // bot bukan admin → tidak bisa promote

    await Hanz.groupParticipantsUpdate(ev.id, list, 'promote');
    gctx.invalidate(ev.id);
    await Hanz.sendMessage(ev.id, {
        text: `🛡️ *ANTI UNADMIN*\n\n${list.map((j) => '@' + gctx.num(j)).join(', ')} di-unadmin${ev.author ? ' oleh @' + author : ''}.\nStatus admin dikembalikan otomatis.`,
        mentions: [...list, ...(ev.author ? [ev.author] : [])],
    });
}

module.exports = { process, onParticipants };

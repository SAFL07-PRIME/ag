/*
 * SUZUKA MD V4 — Console UI
 * Banner gradasi, box rapi, dan log berlabel waktu.
 * Tanpa dependensi tambahan (murni ANSI truecolor).
 */
const ESC = '\x1b[';
const RESET = `${ESC}0m`;
const WIDTH = 64;

const supportsColor = process.stdout.isTTY || process.env.FORCE_COLOR;
const paint = (code, s) => (supportsColor ? `${ESC}${code}m${s}${RESET}` : String(s));
const rgb = (r, g, b, s) => paint(`38;2;${r};${g};${b}`, s);
const bold = (s) => paint('1', s);
const dim = (s) => paint('2', s);

const stripAnsi = (s) => String(s).replace(/\x1b\[[0-9;]*m/g, '');
// Lebar tampilan: emoji & karakter lebar dihitung 2 kolom
const vlen = (s) => {
    let n = 0;
    for (const ch of stripAnsi(s)) {
        const cp = ch.codePointAt(0);
        n += cp >= 0x1f300 || (cp >= 0x2600 && cp <= 0x27bf && cp !== 0x2714 && cp !== 0x2726 && cp !== 0x2022) ? 2 : 1;
    }
    return n;
};
const padEnd = (s, w) => s + ' '.repeat(Math.max(0, w - vlen(s)));

// Gradasi ungu -> pink
const GRAD = [
    [196, 181, 253], [183, 148, 252], [168, 120, 250],
    [192, 100, 240], [217, 80, 220], [236, 72, 190],
];
const lerp = (a, b, t) => Math.round(a + (b - a) * t);
function gradAt(t) {
    const x = Math.max(0, Math.min(0.9999, t)) * (GRAD.length - 1);
    const i = Math.floor(x);
    const f = x - i;
    const a = GRAD[i], b = GRAD[i + 1];
    return [lerp(a[0], b[0], f), lerp(a[1], b[1], f), lerp(a[2], b[2], f)];
}
const gradText = (s) => {
    const chars = [...s];
    return chars.map((c, i) => (c === ' ' ? c : rgb(...gradAt(i / Math.max(1, chars.length - 1)), c))).join('');
};
const ACCENT = (s) => rgb(192, 132, 252, s);
const SOFT = (s) => rgb(216, 180, 254, s);
const MUTED = (s) => rgb(148, 142, 168, s);
const WHITE = (s) => rgb(245, 243, 255, s);
const GREEN = (s) => rgb(110, 231, 160, s);
const YELLOW = (s) => rgb(252, 211, 77, s);
const RED = (s) => rgb(252, 129, 129, s);
const CYAN = (s) => rgb(125, 211, 252, s);
const PINK = (s) => rgb(244, 114, 182, s);

const center = (s, w = WIDTH) => ' '.repeat(Math.max(0, Math.floor((w - vlen(s)) / 2))) + s;

const ART = [
    '███████╗██╗   ██╗███████╗██╗   ██╗██╗  ██╗ █████╗ ',
    '██╔════╝██║   ██║╚══███╔╝██║   ██║██║ ██╔╝██╔══██╗',
    '███████╗██║   ██║  ███╔╝ ██║   ██║█████╔╝ ███████║',
    '╚════██║██║   ██║ ███╔╝  ██║   ██║██╔═██╗ ██╔══██║',
    '███████║╚██████╔╝███████╗╚██████╔╝██║  ██╗██║  ██║',
    '╚══════╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝',
];

function box(title, rows, opts = {}) {
    const inner = (opts.width || WIDTH) - 2;
    const line = '─'.repeat(inner);
    const b = (s) => ACCENT(s);
    const out = [b(`╭${line}╮`)];
    if (title) {
        const t = ` ${title} `;
        const left = Math.floor((inner - vlen(t)) / 2);
        out.push(b('│') + ' '.repeat(left) + bold(gradText(t)) + ' '.repeat(inner - left - vlen(t)) + b('│'));
        out.push(b(`├${line}┤`));
    }
    const labelW = Math.max(8, ...rows.filter(Array.isArray).map((r) => vlen(r[0])));
    for (const r of rows) {
        const [label, value] = Array.isArray(r) ? r : ['', r];
        const body = label
            ? ` ${SOFT(padEnd(label, labelW))} ${MUTED('›')} ${WHITE(value)}`
            : ` ${WHITE(value)}`;
        out.push(b('│') + padEnd(body, inner) + b('│'));
    }
    out.push(b(`╰${line}╯`));
    return out.join('\n');
}

function banner({ version = 'V4', tagline = 'WhatsApp Multi-Device Bot' } = {}) {
    const lines = [''];
    ART.forEach((l, i) => lines.push(center(bold(gradText(l)))));
    lines.push(center(MUTED('━━━━━━━━━━━━━  ') + gradText(`✦  M D   ${version.split('').join(' ')}  ✦`) + MUTED('  ━━━━━━━━━━━━━')));
    lines.push(center(MUTED(tagline)));
    lines.push('');
    return lines.join('\n');
}

const pad2 = (n) => String(n).padStart(2, '0');
function clock() {
    const d = new Date();
    return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

const TAGS = {
    sys:     { label: 'SYSTEM ', color: ACCENT },
    ok:      { label: 'READY  ', color: GREEN },
    inbound: { label: 'PESAN  ', color: CYAN },
    exec:    { label: 'PERINTAH', color: PINK },
    menu:    { label: 'MENU   ', color: SOFT },
    join:    { label: 'JOIN   ', color: GREEN },
    group:   { label: 'GRUP   ', color: SOFT },
    warn:    { label: 'WARN   ', color: YELLOW },
    err:     { label: 'ERROR  ', color: RED },
    notfound:{ label: 'TIDAK ADA', color: YELLOW },
};

// ui.log('inbound', 'pesan ...')  ->  14:02:11 ▏PESAN   ▏ pesan ...
function log(type, message, { error = false } = {}) {
    const t = TAGS[type] || TAGS.sys;
    const tag = t.color(bold(`${t.label.trim()}`.padEnd(9)));
    const text = `${MUTED(clock())} ${t.color('▎')}${tag}${MUTED('│')} ${message}`;
    (error ? console.error : console.log)(text);
}

function who(jid = '') {
    const num = String(jid).split('@')[0].split(':')[0];
    const isGroup = String(jid).endsWith('@g.us');
    return { num, isGroup, short: isGroup ? `grup ${num.slice(-6)}` : `+${num}` };
}

function shorten(text, max = 70) {
    const s = String(text).replace(/\s+/g, ' ').trim();
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

const logInbound = (jid, name, text) => {
    const w = who(jid);
    const label = (w.isGroup ? SOFT('👥 ') : CYAN('👤 ')) + WHITE(name && name !== 'Kak' ? name : w.short) + MUTED(w.isGroup ? ` (${w.short})` : '');
    log('inbound', `${label} ${MUTED('›')} ${shorten(text)}`);
};
const logExec = (name, args) => log('exec', `${bold(YELLOW(name))}${args ? ' ' + MUTED(shorten(args, 50)) : ''}`);

module.exports = {
    WIDTH, box, banner, log, logInbound, logExec, who, shorten, center, vlen,
    c: { accent: ACCENT, soft: SOFT, muted: MUTED, white: WHITE, green: GREEN, yellow: YELLOW, red: RED, cyan: CYAN, pink: PINK, bold, dim, grad: gradText },
};

/**
 * Mesin fitur API xrina — https://apiii-xrina.vercel.app
 * Kategori: /fun  /search  /download  /tools   (AI ada di aiApi.js)
 * Dipakai oleh: src/commands/fun.js, search.js, downloader.js, tools.js
 *
 * Aturan sama seperti aiApi.js: argumen/foto kurang → balas "Command salah" + format & contoh,
 * tanpa request ke API.
 *
 * kind:
 *   'text'  → hasil JSON diformat jadi teks WhatsApp
 *   'list'  → sama seperti text, tapi array ditampilkan bernomor (maks 10 item)
 *   'media' → cari link video / audio / gambar / file di JSON (atau binary) lalu kirim
 *   'images'→ kirim beberapa gambar (pinterest), jumlah dari parameter `limit`
 *
 * Tambah fitur baru: tambah entri di SPECS + `case '<nama>':` di file command yang sesuai.
 */
const config = require('../config');
const brand = require('./brand');
const ai = require('./aiApi');

const API = ai.API;
const { parseArgs, wrongCommand, pickText, toWhatsApp, hasImage, getImage, uploadPone, getQuotedText } = ai;

const NAMA = [{ key: 'nama', label: 'nama', req: true, rest: true }];
const URL_FIELD = (label = 'link') => [{ key: 'url', label, req: true, rest: true }];

const SPECS = {
    // ======================= FUN =======================
    cekcantik:  { title: 'Cek Cantik',  path: 'fun/cekcantik',  kind: 'text', fields: [] },
    cekganteng: { title: 'Cek Ganteng', path: 'fun/cekganteng', kind: 'text', fields: [] },
    cekiq:      { title: 'Cek IQ',      path: 'fun/cekiq',      kind: 'text', fields: [] },
    cekkhodam:  { title: 'Cek Khodam',  path: 'fun/cekkhodam',  kind: 'text', fields: NAMA, example: 'Budi' },
    ceksifat:   { title: 'Cek Sifat',   path: 'fun/ceksifat',   kind: 'text', fields: NAMA, example: 'Budi' },
    longteks:   { title: 'Long Teks',   path: 'fun/longteks',   kind: 'text', fields: [] },
    quotesbijak:    { title: 'Quotes Bijak',    path: 'fun/quotes-bijak',    kind: 'text', fields: [] },
    quotesbucin:    { title: 'Quotes Bucin',    path: 'fun/quotes-bucin',    kind: 'text', fields: [] },
    quotesgalau:    { title: 'Quotes Galau',    path: 'fun/quotes-galau',    kind: 'text', fields: [] },
    quotesgombal:   { title: 'Quotes Gombal',   path: 'fun/quotes-gombal',   kind: 'text', fields: [] },
    quotesmotivasi: { title: 'Quotes Motivasi', path: 'fun/quotes-motivasi', kind: 'text', fields: [] },

    // ======================= SEARCH =======================
    lyrics: {
        title: 'Cari Lirik Lagu', path: 'search/lyrics', kind: 'text',
        fields: [{ key: 'q', label: 'judul lagu', req: true, rest: true }], quoted: true, example: 'Lathi',
    },
    pinterest: {
        title: 'Pinterest', path: 'search/pinterest', kind: 'images',
        fields: [
            { key: 'q', label: 'kata kunci', req: true },
            { key: 'limit', label: 'jumlah', req: false, def: () => '5' },
        ],
        example: 'wallpaper anime|5',
        extraHelp: 'jumlah gambar: 1 - 10 (default 5).',
        hideOptionalNote: true,
        prepare: (p) => { p.limit = String(Math.min(10, Math.max(1, parseInt(p.limit, 10) || 5))); },
    },
    resep: {
        title: 'Cari Resep', path: 'search/resep', kind: 'list',
        fields: [{ key: 'q', label: 'nama masakan', req: true, rest: true }], quoted: true, example: 'nasi goreng',
    },
    stickertelegram: {
        title: 'Cari Sticker Telegram', path: 'search/sticker-telegram', kind: 'list',
        fields: [{ key: 'keyword', label: 'kata kunci', req: true, rest: true }], quoted: true, example: 'kucing',
    },
    ttsearch: {
        title: 'TikTok Search', path: 'search/ttsearch', kind: 'list',
        fields: [{ key: 'q', label: 'kata kunci', req: true, rest: true }], quoted: true, example: 'cara goreng nugget',
    },

    // ======================= DOWNLOADER =======================
    aio:       { title: 'All In One Downloader', path: 'download/aio',       kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://vt.tiktok.com/xxxx' },
    bilibili:  { title: 'Bilibili',   path: 'download/bilibili',  kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://www.bilibili.tv/id/video/xxxx' },
    capcut:    { title: 'CapCut',     path: 'download/capcut',    kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://www.capcut.com/t/xxxx' },
    gdrive:    { title: 'Google Drive', path: 'download/gdrive',  kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://drive.google.com/file/d/xxxx/view' },
    igmp3:     { title: 'Instagram MP3', path: 'download/igmp3',  kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://www.instagram.com/reel/xxxx' },
    mediafire: { title: 'MediaFire',  path: 'download/mediafire', kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://www.mediafire.com/file/xxxx' },
    pindl:     { title: 'Pinterest Downloader', path: 'download/pindl', kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://pin.it/xxxx' },
    shopeedl:  { title: 'Shopee Video', path: 'download/shopeedl', kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://sv.shopee.co.id/xxxx' },
    terabox:   { title: 'Terabox',    path: 'download/terabox',   kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://terabox.com/s/xxxx' },
    twitterdl: { title: 'Twitter / X', path: 'download/twitterdl', kind: 'media', fields: URL_FIELD(), quoted: true, example: 'https://x.com/user/status/123' },

    // ======================= TOOLS =======================
    bypass: {
        title: 'Bypass Link', path: 'tools/bypass', kind: 'text',
        fields: URL_FIELD(), quoted: true, example: 'https://linkvertise.com/xxxx',
    },
    cekvirus: {
        title: 'Cek Virus Website', path: 'tools/cek-virusweb', kind: 'text',
        fields: [{ key: 'target', label: 'link / domain', req: true, rest: true }], quoted: true, example: 'https://contoh.com',
    },
    img2vid: {
        title: 'Image to Video', path: 'tools/img2vid', kind: 'media', image: ['image'],
        fields: [{ key: 'prompt', label: 'prompt', req: true, rest: true }], example: 'kamera zoom perlahan, rambut tertiup angin',
        timeout: 240000,
    },
    ocr:    { title: 'OCR (Gambar ke Teks)', path: 'tools/ocr',    kind: 'text', image: ['url'], fields: [] },
    readqr: { title: 'Baca QR Code',         path: 'tools/readqr', kind: 'text', image: ['url'], fields: [] },
    shortlink: {
        title: 'Short Link', path: 'tools/shortlink', kind: 'text',
        fields: [
            { key: 'url', label: 'link', req: true },
            { key: 'custom', label: 'nama custom', req: false },
        ],
        example: 'https://contoh.com/halaman-panjang|namaku',
        extraHelp: '_Nama custom boleh dikosongkan._', hideOptionalNote: true,
    },
};

const specOf = (name) => SPECS[name] || null;

// ======================= [ Format hasil JSON → teks ] =======================
const META_KEYS = new Set(['status', 'success', 'code', 'statusCode', 'creator', 'author_api', 'timestamp']);
const humanKey = (k) => String(k).replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b\w/g, (c) => c.toUpperCase());

function payloadOf(root) {
    if (root && typeof root === 'object' && !Array.isArray(root)) {
        for (const k of ['result', 'results', 'data', 'response']) {
            if (root[k] !== undefined && root[k] !== null && root[k] !== '') return root[k];
        }
    }
    return root;
}

function inline(v, depth = 0) {
    if (v === null || v === undefined) return '';
    if (typeof v !== 'object') return String(v);
    if (Array.isArray(v)) return v.map((x) => inline(x, depth + 1)).filter(Boolean).join(', ');
    if (depth >= 2) return '';
    return Object.entries(v).filter(([k]) => !META_KEYS.has(k))
        .map(([k, x]) => `${humanKey(k)}: ${inline(x, depth + 1)}`).join(' | ');
}

function formatObject(o) {
    const q = ['quote', 'quotes', 'kata', 'text', 'teks'].find((k) => typeof o[k] === 'string' && o[k].trim());
    if (q) {
        const by = ['author', 'penulis', 'by'].find((k) => typeof o[k] === 'string' && o[k].trim());
        return `${o[q].trim()}${by ? `\n\n— ${o[by].trim()}` : ''}`;
    }
    return Object.entries(o)
        .filter(([k, v]) => !META_KEYS.has(k) && v !== null && v !== undefined && v !== '')
        .map(([k, v]) => {
            const val = inline(v);
            if (!val) return null;
            return val.includes('\n') ? `*${humanKey(k)}:*\n${val}` : `*${humanKey(k)}:* ${val}`;
        })
        .filter(Boolean).join('\n');
}

function formatAny(root, asList) {
    const v = payloadOf(root);
    if (v === null || v === undefined) return '';
    if (typeof v !== 'object') return String(v).trim();
    if (Array.isArray(v)) {
        const items = v.slice(0, 10).map((it, i) => {
            const body = typeof it === 'object' && it ? formatObject(it) : String(it);
            if (!body) return null;
            return asList || typeof it === 'object' ? `*${i + 1}.* ${body.replace(/\n/g, '\n    ')}` : body;
        }).filter(Boolean);
        const more = v.length > 10 ? `\n\n_…dan ${v.length - 10} hasil lainnya_` : '';
        return items.join('\n\n') + more;
    }
    // satu level lagi: { result: { data: ... } } sudah ditangani payloadOf, sisanya objek biasa
    return formatObject(v);
}

// ======================= [ Cari media di JSON ] =======================
const SKIP_KEY = /thumb|cover|avatar|icon|poster|profile|logo|preview|watermark/i;
const EXT = {
    video: /\.(mp4|mkv|webm|mov|m3u8)(\?|$)/i,
    audio: /\.(mp3|m4a|opus|ogg|wav|aac)(\?|$)/i,
    image: /\.(jpe?g|png|webp|gif)(\?|$)/i,
};

function classify(url, key, parent) {
    const hint = `${parent?.type || ''} ${parent?.mime || ''} ${parent?.mimetype || ''} ${parent?.format || ''} ${parent?.ext || ''}`.toLowerCase();
    if (/video|mp4/.test(hint)) return 'video';
    if (/audio|mp3|m4a/.test(hint)) return 'audio';
    if (/image|photo|jpe?g|png|webp/.test(hint)) return 'image';
    if (EXT.video.test(url)) return 'video';
    if (EXT.audio.test(url)) return 'audio';
    if (EXT.image.test(url)) return 'image';
    if (/video|mp4|nowm|hd|sd/i.test(key)) return 'video';
    if (/audio|mp3|music|sound/i.test(key)) return 'audio';
    if (/image|photo|img|pic/i.test(key)) return 'image';
    return 'file';
}

function collectMedia(root) {
    const found = { video: [], audio: [], image: [], file: [] };
    const seen = new Set();
    const meta = {};

    const walk = (v, key = '', parent = null, depth = 0) => {
        if (v === null || v === undefined || depth > 6) return;
        if (typeof v === 'string') {
            const s = v.trim();
            if (/^(title|caption|desc|description|name|filename|fileName|file_name)$/i.test(key) && !meta.title && !/^https?:\/\//i.test(s)) {
                meta.title = s;
            }
            if (/^(size|filesize|file_size)$/i.test(key) && !meta.size) meta.size = s;
            if (/^https?:\/\/\S+$/i.test(s) && !seen.has(s)) {
                seen.add(s);
                const kind = classify(s, key, parent);
                if (SKIP_KEY.test(key) && kind !== 'video' && kind !== 'audio') { found.thumb = found.thumb || s; return; }
                found[kind].push(s);
            }
            return;
        }
        if (typeof v === 'number') {
            if (/^(size|filesize|file_size)$/i.test(key) && !meta.size) meta.size = v;
            return;
        }
        if (Array.isArray(v)) { v.forEach((x) => walk(x, key, parent, depth + 1)); return; }
        if (typeof v === 'object') {
            for (const [k, x] of Object.entries(v)) walk(x, k, v, depth + 1);
        }
    };
    walk(payloadOf(root));
    return { found, meta };
}

// ======================= [ Panggil API ] =======================
async function call(spec, params) {
    const qs = Object.entries(params)
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
        .join('&');
    const res = await fetch(`${API}/${spec.path}${qs ? '?' + qs : ''}`, {
        signal: AbortSignal.timeout(spec.timeout || 120000),
        headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();

    if (/^(image|video|audio)\//.test(type)) {
        if (!res.ok) throw new Error(`API error ${res.status}`);
        return { type, buf: Buffer.from(await res.arrayBuffer()) };
    }

    const raw = await res.text();
    let json = null;
    try { json = JSON.parse(raw); } catch { /* bukan JSON */ }

    if (!res.ok || json?.status === false || json?.success === false) {
        const why = pickText(json?.error) || pickText(json?.message) || `API error ${res.status}`;
        throw new Error(why);
    }
    return { type, json, raw };
}

// ======================= [ Kirim hasil ] =======================
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

async function sendMedia(m, spec, out) {
    const { Hanz, sender, msg } = m;
    const quoted = { quoted: msg };
    const cap = `*${spec.title}*\n${brand.footer}`;

    // binary langsung
    if (out.buf) {
        if (out.type.startsWith('video/')) return Hanz.sendMessage(sender, { video: out.buf, mimetype: 'video/mp4', caption: cap }, quoted);
        if (out.type.startsWith('audio/')) return Hanz.sendMessage(sender, { audio: out.buf, mimetype: 'audio/mpeg' }, quoted);
        return Hanz.sendMessage(sender, { image: out.buf, caption: cap }, quoted);
    }

    const { found, meta } = collectMedia(out.json);
    const title = meta.title ? `*${meta.title}*\n` : '';
    const caption = `${title}${cap}`;

    if (found.video.length) {
        await Hanz.sendMessage(sender, { video: { url: found.video[0] }, mimetype: 'video/mp4', caption }, quoted);
        return;
    }
    if (found.audio.length) {
        await Hanz.sendMessage(sender, {
            audio: { url: found.audio[0] }, mimetype: 'audio/mpeg', fileName: `${meta.title || spec.title}.mp3`,
        }, quoted);
        return;
    }
    if (found.image.length) {
        const imgs = found.image.slice(0, 10);
        for (let i = 0; i < imgs.length; i++) {
            await Hanz.sendMessage(sender, { image: { url: imgs[i] }, caption: i === 0 ? caption : '' }, quoted);
            if (i < imgs.length - 1) await delay(1500);
        }
        return;
    }
    if (found.file.length) {
        const link = found.file[0];
        const name = meta.title && /\.[a-z0-9]{2,5}$/i.test(meta.title) ? meta.title : `${meta.title || spec.title.replace(/\W+/g, '_')}`;
        const sizeNote = meta.size ? `\nUkuran: ${meta.size}` : '';
        try {
            await Hanz.sendMessage(sender, {
                document: { url: link }, fileName: name, mimetype: 'application/octet-stream', caption: `${caption}${sizeNote}`,
            }, quoted);
        } catch (e) {
            console.error('[XRINA] kirim dokumen gagal, kirim link:', e?.message || e);
            await m.reply({ text: `${caption}${sizeNote}\n\n${link}` });
        }
        return;
    }
    // tidak ada link media → tampilkan JSON-nya sebagai teks
    const text = formatAny(out.json);
    if (!text) throw new Error('Respons API tidak berisi media');
    await m.reply({ text: `*${spec.title}*\n\n${toWhatsApp(text)}` });
}

// ======================= [ Eksekusi ] =======================
async function run(m, cmdName) {
    const { command, msg, sender, Hanz } = m;
    const p = config.prefix;
    const spec = specOf(cmdName);
    if (!spec) return;

    // 1. validasi argumen
    let rawArgs = command.fullArgs || '';
    if (!rawArgs.trim() && spec.quoted) rawArgs = getQuotedText(msg) || '';

    const parsed = parseArgs(spec, rawArgs);
    if (parsed.error) {
        const reason = String(rawArgs || '').trim() ? parsed.error : '';
        return m.reply({ text: wrongCommand(cmdName, spec, p, reason) });
    }

    // 2. validasi foto
    if (spec.image && !hasImage(msg)) {
        return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto belum dikirim — reply atau kirim foto dulu.') });
    }

    // 3. proses
    try {
        await m.react('⏳');
        const params = { ...parsed.params };
        if (spec.prepare) spec.prepare(params);

        if (spec.image) {
            const buffer = await getImage(msg);
            if (!buffer) {
                await m.react('❌');
                return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto tidak terbaca, coba kirim ulang.') });
            }
            const url = await uploadPone(buffer, `suzuka-${Date.now()}.jpg`);
            for (const key of spec.image) params[key] = url;
        }

        const out = await call(spec, params);

        if (spec.kind === 'media') {
            await sendMedia(m, spec, out);
        } else if (spec.kind === 'images') {
            const { found } = collectMedia(out.json);
            const imgs = [...found.image, ...found.file, ...found.video].slice(0, Number(params.limit) || 5);
            if (!imgs.length) throw new Error('Tidak ada gambar ditemukan');
            for (let i = 0; i < imgs.length; i++) {
                await Hanz.sendMessage(sender, {
                    image: { url: imgs[i] },
                    caption: i === 0 ? `*${spec.title}*\n${params.q}\n${brand.footer}` : '',
                }, { quoted: msg });
                if (i < imgs.length - 1) await delay(1500);
            }
        } else {
            if (out.buf) throw new Error('Respons API berupa file, bukan teks');
            let text = out.json ? formatAny(out.json, spec.kind === 'list') : String(out.raw || '').trim();
            if (!text || /^<!doctype html|^<html/i.test(text)) throw new Error('Respons API kosong');
            text = toWhatsApp(text);
            await m.reply({ text: `*${spec.title}*\n\n${text}` });
        }
        await m.react('✅');
    } catch (e) {
        console.error('[XRINA]', spec.path, e?.message || e);
        await m.react('❌');
        await m.reply({ text: 'Gagal memproses. API mungkin sedang down atau data tidak valid, coba lagi nanti.' });
    }
}

module.exports = { SPECS, specOf, run, formatAny, collectMedia };

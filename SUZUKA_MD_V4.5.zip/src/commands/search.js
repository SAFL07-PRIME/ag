/**
 * SEARCH MENU — pencarian (API: apiii-xrina.vercel.app/search)
 * Logika & daftar spesifikasi: src/utils/xrinaApi.js
 * (.yts / .ytsearch sudah ada di src/commands/downloader.js, hanya ditampilkan di menu ini)
 */
const config = require('../config');
const brand = require('../utils/brand');
const { deliver } = require('../utils/sendMenu');
const { categoryButton } = require('../utils/menuCategories');
const xrina = require('../utils/xrinaApi');

const handler = async (m) => {
    const { command, msg, sender } = m;
    const p = config.prefix;
    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'searchmenu': {
            const text =
` ┌─ ✧ *SEARCH MENU*
 │ ⊳ ${p}lyrics <judul>
 │ ⊳ ${p}pinterest <kata>|[jumlah]
 │ ⊳ ${p}resep <masakan>
 │ ⊳ ${p}stickertelegram <kata>
 │ ⊳ ${p}ttsearch <kata>
 │ ⊳ ${p}ytsearch <kata>
 └───────────────`;

            await deliver(m, {
                text,
                footer: brand.footer,
                buttons: [categoryButton()],
                userJid,
                video: null
            });
            break;
        }

        case 'lyrics':
        case 'pinterest':
        case 'resep':
        case 'stickertelegram':
        case 'ttsearch':
            return xrina.run(m, command.name);
    }
};

module.exports = handler;

const brand = require('../utils/brand');
const channel = require('../utils/channel');
const script = require('../utils/script');
const { deliver } = require('../utils/sendMenu');

const handler = async (m) => {
    const { command, msg, sender } = m;

    // JID pengirim (di grup = participant, di private = remoteJid)
    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'script': {
            // Teks script + tombol Saluran di bawahnya (link saluran tetap tersembunyi di utils/channel.js)
            await deliver(m, {
                text: script.text,
                footer: brand.footer,
                buttons: [channel.button()],
                userJid,
                video: null,
                image: null,
                header: false
            });
            break;
        }
    }
};

module.exports = handler;

/**
 * FUN MENU — cek-cekan & quotes (API: apiii-xrina.vercel.app/fun)
 * Logika & daftar spesifikasi: src/utils/xrinaApi.js
 */
const config = require('../config');
const brand = require('../utils/brand');
const { deliver } = require('../utils/sendMenu');
const { categoryButton } = require('../utils/menuCategories');
const xrina = require('../utils/xrinaApi');

const handler = async (m) => {
    const { command, msg, sender } = m;
    const p = config.prefix;
    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'funmenu': {
            const text =
` ┌─ ✧ *FUN MENU*
 │ ⊳ ${p}cekcantik
 │ ⊳ ${p}cekganteng
 │ ⊳ ${p}cekiq
 │ ⊳ ${p}cekkhodam <nama>
 │ ⊳ ${p}ceksifat <nama>
 │ ⊳ ${p}longteks
 │
 │ ⊳ ${p}quotesbijak
 │ ⊳ ${p}quotesbucin
 │ ⊳ ${p}quotesgalau
 │ ⊳ ${p}quotesgombal
 │ ⊳ ${p}quotesmotivasi
 └───────────────`;

            await deliver(m, {
                text,
                footer: brand.footer,
                buttons: [categoryButton()],
                userJid,
                video: null
            });
            break;
        }

        case 'cekcantik':
        case 'cekganteng':
        case 'cekiq':
        case 'cekkhodam':
        case 'ceksifat':
        case 'longteks':
        case 'quotesbijak':
        case 'quotesbucin':
        case 'quotesgalau':
        case 'quotesgombal':
        case 'quotesmotivasi':
            return xrina.run(m, command.name);
    }
};

module.exports = handler;

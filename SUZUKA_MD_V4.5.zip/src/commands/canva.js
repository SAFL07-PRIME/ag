/**
 * CANVA MENU — generator gambar via API canvas (apiii-xrina.vercel.app/canvas)
 *
 *  .callandro   <nama>|<durasi>                       (reply/kirim foto)  → fake call Android
 *  .callios     <nama>|<durasi>                       (reply/kirim foto)  → fake call iOS
 *  .codesnap    <bahasa>|<kode>                       → screenshot kode (atau reply teks kode + .codesnap <bahasa>)
 *  .fakech      <nama>|<pengikut>|<jam>               (reply/kirim foto)  → fake channel WhatsApp
 *  .fakedev     <nama>                                (reply/kirim foto)  → fake developer
 *  .fakeff      <nama>                                → fake lobby Free Fire
 *  .fakeffduo   <nama1>|<nama2>                       → fake lobby Free Fire duo
 *  .fakegc      <nama>|<anggota>                      (reply/kirim foto)  → fake grup WhatsApp
 *  .fakeml      <username>|<rank>|<border>            (reply/kirim foto)  → fake profil Mobile Legends
 *  .faketele    <nama>|<nomor>|<bio>|<username>       (reply/kirim foto)  → fake profil Telegram
 *  .igstory     <nama>|<username>                     (reply/kirim foto)  → fake story Instagram
 *  .memepolisi  <username>|<teks>                     → meme polisi
 *  .ttqc        <nama>|<teks>                         (reply/kirim foto)  → quote chat TikTok
 *  .windows     <teks>                                → pesan error Windows
 *
 * Aturan: kalau argumen wajib kurang / foto belum dikirim → bot membalas
 * "Command salah" + format & contoh yang benar. Tidak ada request ke API sebelum valid.
 *
 * Tambah fitur baru: cukup tambah entri di tabel SPECS + `case` di bawah (PluginLoader membaca `case`).
 */
const config = require('../config');
const brand = require('../utils/brand');
const { deliver } = require('../utils/sendMenu');
const { categoryButton } = require('../utils/menuCategories');

const API = 'https://apiii-xrina.vercel.app/canvas';

// ======================= [ Spesifikasi tiap command ] =======================
// image : nama parameter API yang diisi URL foto (foto di-upload dulu ke pone.rs)
// fields: urutan argumen yang dipisah "|" → parameter API
//         req   = wajib diisi
//         def   = nilai default kalau dikosongkan (hanya untuk yang tidak wajib)
//         num   = harus angka
//         rest  = ambil sisa teks (boleh mengandung "|")
// fixed : parameter tetap yang selalu dikirim
const SPECS = {
    callandro: {
        title: 'Fake Call Android', path: 'call-andro', image: ['pp'],
        fields: [
            { key: 'nama', label: 'nama', req: true },
            { key: 'durasi', label: 'durasi', req: true },
        ],
        example: 'Syang|01.30.78',
    },
    callios: {
        title: 'Fake Call iOS', path: 'call-ios', image: ['pp'],
        fields: [
            { key: 'nama', label: 'nama', req: true },
            { key: 'durasi', label: 'durasi', req: true },
        ],
        example: 'My|02.08.30',
    },
    codesnap: {
        title: 'Code Snap', path: 'codesnap', image: null,
        fields: [
            { key: 'language', label: 'bahasa', req: true },
            { key: 'code', label: 'kode', req: true, rest: true },
        ],
        fixed: { theme: 'one-dark', font: 'Hack', linenumbers: 'true' },
        example: 'html|<h1>Halo</h1>',
        extraHelp: 'Atau reply pesan berisi kode lalu ketik: {p}codesnap html',
    },
    fakech: {
        title: 'Fake Channel WhatsApp', path: 'fakech', image: ['pp'],
        fields: [
            { key: 'nama', label: 'nama', req: true },
            { key: 'pengikut', label: 'pengikut', req: true, num: true },
            { key: 'jam', label: 'jam', req: false, def: () => nowTime() },
        ],
        example: 'Welper|3000|12.03',
    },
    fakedev: {
        title: 'Fake Developer', path: 'fakedev', image: ['avatar'],
        fields: [{ key: 'name', label: 'nama', req: true }],
        example: 'WELPER',
    },
    fakeff: {
        title: 'Fake Lobby Free Fire', path: 'fakeff', image: null,
        fields: [{ key: 'name', label: 'nama', req: true }],
        fixed: { lobby: 'random' },
        example: 'Welperid',
    },
    fakeffduo: {
        title: 'Fake Lobby Free Fire Duo', path: 'fakeffduo', image: null,
        fields: [
            { key: 'name1', label: 'nama1', req: true },
            { key: 'name2', label: 'nama2', req: true },
        ],
        example: 'Welperid|Well',
    },
    fakegc: {
        title: 'Fake Grup WhatsApp', path: 'fakegc', image: ['pp'],
        fields: [
            { key: 'nama', label: 'nama', req: true },
            { key: 'anggota', label: 'anggota', req: true, num: true },
        ],
        example: 'Grup Santuy|20000',
    },
    fakeml: {
        title: 'Fake Profil Mobile Legends', path: 'fakeml', image: ['avatar'],
        fields: [
            { key: 'username', label: 'username', req: true },
            { key: 'rank', label: 'rank', req: false, def: () => 'mawi' },
            { key: 'border', label: 'border', req: false, num: true, def: () => '16' },
        ],
        example: 'WELPERID|mawi|16',
    },
    faketele: {
        title: 'Fake Profil Telegram', path: 'faketele', image: ['pp'],
        fields: [
            { key: 'nama', label: 'nama', req: true },
            { key: 'nomor', label: 'nomor', req: true },
            { key: 'bio', label: 'bio', req: true },
            { key: 'username', label: 'username', req: true },
        ],
        example: 'Wel|08123456789|Halo semua|welperid',
    },
    igstory: {
        title: 'Fake Story Instagram', path: 'ig-story', image: ['photo', 'pp'],
        fields: [
            { key: 'name', label: 'nama', req: true },
            { key: 'username', label: 'username', req: true },
        ],
        example: 'Welper|welperid',
        extraHelp: 'Foto yang dikirim dipakai sebagai isi story sekaligus foto profil.',
    },
    memepolisi: {
        title: 'Meme Polisi', path: 'meme-polisi', image: null,
        fields: [
            { key: 'username', label: 'username', req: true },
            { key: 'text', label: 'teks', req: true, rest: true },
        ],
        example: 'welperid|Pak, bukan saya pak',
    },
    ttqc: {
        title: 'TikTok Quote Chat', path: 'ttqc', image: ['avatar'],
        fields: [
            { key: 'name', label: 'nama', req: true },
            { key: 'text', label: 'teks', req: true, rest: true },
        ],
        example: 'Welper|Halo semuanya',
    },
    windows: {
        title: 'Windows Error', path: 'windows', image: null,
        fields: [{ key: 'text', label: 'teks', req: true, rest: true }],
        example: 'HALOO SAYANG',
    },
};

// alias → nama spec
const ALIAS = {
    callandor: 'callandro',
    callandroid: 'callandro',
    callandro: 'callandro',
    callios: 'callios',
    callapple: 'callios',
    codesnap: 'codesnap',
    fakech: 'fakech',
    fakechannel: 'fakech',
    fakedev: 'fakedev',
    fakeff: 'fakeff',
    fakeffduo: 'fakeffduo',
    fakegc: 'fakegc',
    fakeml: 'fakeml',
    faketele: 'faketele',
    faketelegram: 'faketele',
    igstory: 'igstory',
    fakestory: 'igstory',
    memepolisi: 'memepolisi',
    ttqc: 'ttqc',
    windows: 'windows',
};

// ======================= [ Helper ] =======================
function nowTime() {
    return new Date()
        .toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false })
        .replace(':', '.');
}

function unwrap(message) {
    let cur = message;
    for (let i = 0; i < 4 && cur; i++) {
        const inner = cur.ephemeralMessage?.message
            || cur.viewOnceMessage?.message
            || cur.viewOnceMessageV2?.message
            || cur.documentWithCaptionMessage?.message;
        if (!inner) break;
        cur = inner;
    }
    return cur;
}

function getContext(msg) {
    const c = unwrap(msg.message);
    return c?.extendedTextMessage?.contextInfo
        || c?.imageMessage?.contextInfo
        || c?.videoMessage?.contextInfo
        || null;
}

// teks dari pesan yang di-reply (dipakai .codesnap)
function getQuotedText(msg) {
    const q = unwrap(getContext(msg)?.quotedMessage);
    return q?.conversation
        || q?.extendedTextMessage?.text
        || q?.imageMessage?.caption
        || q?.videoMessage?.caption
        || null;
}

// Ambil GAMBAR dari pesan langsung (caption) atau pesan yang di-reply. null kalau tidak ada.
async function getImage(msg) {
    const { downloadMediaMessage } = require('@hanzofc/baileys');
    const content = unwrap(msg.message);

    if (content?.imageMessage) {
        return downloadMediaMessage({ key: msg.key, message: content }, 'buffer', {});
    }

    const ctx = getContext(msg);
    const quoted = unwrap(ctx?.quotedMessage);
    if (!quoted?.imageMessage) return null;

    const key = { remoteJid: msg.key.remoteJid, id: ctx.stanzaId, participant: ctx.participant };
    return downloadMediaMessage({ key, message: quoted }, 'buffer', {});
}

// Cek tanpa download: apakah ada gambar (langsung / reply)?
function hasImage(msg) {
    const content = unwrap(msg.message);
    if (content?.imageMessage) return true;
    return !!unwrap(getContext(msg)?.quotedMessage)?.imageMessage;
}

// Upload ke pone.rs (sama seperti .tourl) → URL publik untuk API
async function uploadPone(buffer, filename = 'file.jpg') {
    const axios = require('axios');
    const FormData = require('form-data');
    const form = new FormData();
    form.append('files[]', buffer, { filename });
    const res = await axios.post('https://pone.rs/upload.php', form, {
        headers: {
            ...form.getHeaders(),
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
            accept: '*/*',
            origin: 'https://pone.rs',
            referer: 'https://pone.rs/',
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 60000,
        validateStatus: () => true,
    });
    const url = res.data?.files?.[0]?.url?.replaceAll('\\/', '/');
    if (!res.data?.success || !url) throw new Error('Upload gambar gagal');
    return url;
}

async function fetchCanvas(path, params) {
    const qs = Object.entries(params)
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
        .join('&');
    const res = await fetch(`${API}/${path}?${qs}`, { signal: AbortSignal.timeout(60000) });
    if (!res.ok) throw new Error(`API error ${res.status}`);
    const type = (res.headers.get('content-type') || '').split(';')[0].trim();
    if (!/^(image|video)\//.test(type)) throw new Error(`Respons API bukan gambar (${type || 'unknown'})`);
    return { buf: Buffer.from(await res.arrayBuffer()), type };
}

// Pesan "Command salah" + format & contoh
function wrongCommand(cmdName, spec, p, reason) {
    const usage = spec.fields.map((f) => (f.req ? `<${f.label}>` : `[${f.label}]`)).join('|');
    const needPhoto = !!spec.image;
    const optional = spec.fields.filter((f) => !f.req).map((f) => f.label);

    let t = `❌ *Command salah!*\n`;
    if (reason) t += `${reason}\n`;
    t += `\n*${spec.title}*\n`;
    t += needPhoto ? `📸 Reply / kirim *foto* dengan caption:\n` : `Cara pakai:\n`;
    t += `${p}${cmdName} ${usage}\n\n`;
    t += `✨ *Contoh:*\n${p}${cmdName} ${spec.example}`;
    if (optional.length) t += `\n\n_Boleh dikosongkan: ${optional.join(', ')}_`;
    if (spec.extraHelp) t += `\n\n${spec.extraHelp.replace(/\{p\}/g, p)}`;
    return t;
}

// Pecah argumen "a|b|c" sesuai fields. Mengembalikan { params } atau { error }.
function parseArgs(spec, raw) {
    const text = String(raw || '').trim();
    const parts = [];
    let remain = text;

    spec.fields.forEach((f, i) => {
        const isLast = i === spec.fields.length - 1;
        if (f.rest && isLast) {
            parts.push(remain.trim());
            remain = '';
            return;
        }
        const idx = remain.indexOf('|');
        if (idx === -1) {
            parts.push(remain.trim());
            remain = '';
        } else {
            parts.push(remain.slice(0, idx).trim());
            remain = remain.slice(idx + 1);
        }
    });

    const params = {};
    for (let i = 0; i < spec.fields.length; i++) {
        const f = spec.fields[i];
        let v = parts[i] || '';
        if (!v) {
            if (f.req) return { error: `Bagian *${f.label}* wajib diisi.`, partial: parts };
            v = f.def ? f.def() : '';
        }
        if (f.num && v && !/^\d+$/.test(v)) {
            return { error: `Bagian *${f.label}* harus berupa angka.`, partial: parts };
        }
        params[f.key] = v;
    }
    return { params };
}

// ======================= [ Eksekusi ] =======================
async function run(m, cmdName, spec) {
    const { command, msg, sender, Hanz } = m;
    const p = config.prefix;

    // --- 1. validasi argumen ---
    let rawArgs = command.fullArgs || '';
    if (spec.path === 'codesnap') {
        // pertahankan baris baru & indentasi kode (fullArgs memadatkan spasi)
        rawArgs = String(command.raw || '').replace(/^\S+\s?/, '');
        const firstBar = rawArgs.indexOf('|');
        const lang = (firstBar === -1 ? rawArgs : rawArgs.slice(0, firstBar)).trim();
        if (firstBar === -1 && lang) {
            // .codesnap html  + reply teks kode
            const quotedCode = getQuotedText(msg);
            if (quotedCode) rawArgs = `${lang}|${quotedCode}`;
        }
    }

    const parsed = parseArgs(spec, rawArgs);
    if (parsed.error) {
        // kalau sama sekali tidak ada isi → tampilkan format & contoh saja (tanpa alasan)
        const reason = String(rawArgs || '').trim() ? parsed.error : '';
        return m.reply({ text: wrongCommand(cmdName, spec, p, reason) });
    }

    // --- 2. validasi foto (wajib untuk command yang butuh) ---
    if (spec.image && !hasImage(msg)) {
        return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto belum dikirim — reply atau kirim foto dulu.') });
    }

    // --- 3. proses ---
    try {
        await m.react('⏳');
        const params = { ...parsed.params, ...(spec.fixed || {}) };

        if (spec.image) {
            const buffer = await getImage(msg);
            if (!buffer) {
                await m.react('❌');
                return m.reply({ text: wrongCommand(cmdName, spec, p, 'Foto tidak terbaca, coba kirim ulang.') });
            }
            const url = await uploadPone(buffer, `suzuka-${Date.now()}.jpg`);
            for (const key of spec.image) params[key] = url;
        }

        const { buf, type } = await fetchCanvas(spec.path, params);
        await Hanz.sendMessage(
            sender,
            type.startsWith('video/') ? { video: buf } : { image: buf, caption: `✨ ${spec.title}\n${brand.footer}` },
            { quoted: msg }
        );
        await m.react('✅');
    } catch (e) {
        console.error('[CANVA]', spec.path, e?.message || e);
        await m.react('❌');
        await m.reply({ text: '❌ Gagal membuat gambar. API mungkin sedang down atau data tidak valid, coba lagi nanti.' });
    }
}

// ======================= [ Command ] =======================
const handler = async (m) => {
    const { command, msg, sender } = m;
    const p = config.prefix;

    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'canvamenu': {
            const text =
` ┌─ ✧ *CANVA MENU*
 │ ⊳ ${p}callandro
 │ ⊳ ${p}callios
 │ ⊳ ${p}codesnap
 │ ⊳ ${p}fakech
 │ ⊳ ${p}fakedev
 │ ⊳ ${p}fakeff
 │ ⊳ ${p}fakeffduo
 │ ⊳ ${p}fakegc
 │ ⊳ ${p}fakeml
 │ ⊳ ${p}faketele
 │ ⊳ ${p}igstory
 │ ⊳ ${p}memepolisi
 │ ⊳ ${p}ttqc
 │ ⊳ ${p}windows
 └───────────────`;

            await deliver(m, {
                text,
                footer: brand.footer,
                buttons: [categoryButton()],
                userJid,
                video: null,
            });
            break;
        }

        case 'callandro':
        case 'callandor':
        case 'callandroid':
        case 'callios':
        case 'callapple':
        case 'codesnap':
        case 'fakech':
        case 'fakechannel':
        case 'fakedev':
        case 'fakeff':
        case 'fakeffduo':
        case 'fakegc':
        case 'fakeml':
        case 'faketele':
        case 'faketelegram':
        case 'igstory':
        case 'fakestory':
        case 'memepolisi':
        case 'ttqc':
        case 'windows': {
            const specName = ALIAS[command.name];
            return run(m, command.name, SPECS[specName]);
        }
    }
};

module.exports = handler;
// untuk pengujian
module.exports._internals = { SPECS, ALIAS, parseArgs, wrongCommand };

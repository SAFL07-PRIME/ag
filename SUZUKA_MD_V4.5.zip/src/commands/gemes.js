const config = require('../config');
const brand = require('../utils/brand');
const { deliver } = require('../utils/sendMenu');
const { categoryButton } = require('../utils/menuCategories');
const gemes = require('../utils/gemesGame');

/**
 * Kategori GEMES — game tebak-tebakan (soal dari apiii-xrina.vercel.app/game/*)
 *
 * .gemesmenu      → daftar fitur kategori Gemes
 * .asahotak .caklontong .kataacak .susunkata .tebakbendera .tebakbuah
 * .tebakepep .tebakgambar .tebakhewan .tebakkalimat .tebakkata
 * .tebakkimia .tebaktebakan                → mulai game
 * .hint           → bantuan huruf jawaban
 * .nyerah         → menyerah & lihat jawaban
 *
 * Jawab dengan mengetik jawabannya langsung di chat (tanpa prefix).
 * Logika game ada di src/utils/gemesGame.js (jawaban dicek dari messageHandler).
 *
 * Tambah game baru:
 *  1) tambah entri di GAMES (src/utils/gemesGame.js)
 *  2) tambah `case '<nama>':` di bawah
 */

const handler = async (m) => {
    const { command, msg, sender } = m;
    const p = config.prefix;
    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'gemesmenu': {
            const rows = Object.entries(gemes.GAMES)
                .map(([name, g]) => ` │ ⊳ ${p}${name}`)
                .join('\n');

            const text =
` ┌─ ✧ *GEMES MENU*
${rows}
 │
 │ ⊳ ${p}hint
 │ ⊳ ${p}nyerah
 └───────────────

_Ketik jawaban langsung di chat setelah soal keluar._`;

            await deliver(m, {
                text,
                footer: brand.footer,
                buttons: [categoryButton()],
                userJid,
                video: null
            });
            break;
        }

        case 'asahotak':
        case 'caklontong':
        case 'kataacak':
        case 'susunkata':
        case 'tebakbendera':
        case 'tebakbuah':
        case 'tebakepep':
        case 'tebakgambar':
        case 'tebakhewan':
        case 'tebakkalimat':
        case 'tebakkata':
        case 'tebakkimia':
        case 'tebaktebakan':
            return gemes.start(m, command.name);

        case 'hint':
            return gemes.hint(m);

        case 'nyerah':
            return gemes.giveUp(m);
    }
};

module.exports = handler;

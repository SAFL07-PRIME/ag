/**
 * AI MENU — chat AI & gambar AI (API: apiii-xrina.vercel.app/ai & /ai-image)
 *
 *  .aimenu                                  → daftar fitur kategori AI
 *
 *  Chat AI (tulis pertanyaan, atau reply pesan teks):
 *  .gpt .claudehaiku .clara .ethan .guru .maya .nova  <teks>
 *  .aicostum    <teks>|<prompt karakter>
 *  .unlimitedai <teks>|[karakter]           (default karakter: zeta-ai)
 *
 *  Gambar AI:
 *  .flux        <prompt>
 *  .text2img    <prompt>|[shape]|[negative]|[seed]
 *  .editimg     <prompt>                    (reply/kirim foto)
 *  .imagetoprompt                           (reply/kirim foto)  → alias .toprompt
 *  .removewm                                (reply/kirim foto)  → hapus watermark
 *
 *  .hd2 (reply/kirim foto) ada di kategori Tools (src/commands/tools.js).
 *
 * Aturan: kalau format salah → bot membalas "Command salah" + cara pakai & contoh.
 * Logika & daftar spesifikasi ada di src/utils/aiApi.js.
 *
 * Tambah fitur baru:
 *  1) tambah entri di SPECS (src/utils/aiApi.js)
 *  2) tambah `case` untuk nama command-nya di bawah
 *  3) tambah barisnya di teks aimenu
 */
const config = require('../config');
const brand = require('../utils/brand');
const { deliver } = require('../utils/sendMenu');
const { categoryButton } = require('../utils/menuCategories');
const aiApi = require('../utils/aiApi');

const handler = async (m) => {
    const { command, msg, sender } = m;
    const p = config.prefix;
    const userJid = msg.key.participant || msg.key.remoteJid || sender;

    switch (command.name) {
        case 'aimenu': {
            const text =
` ┌─ ✧ *AI MENU*
 │ ⊳ ${p}gpt
 │ ⊳ ${p}claudehaiku
 │ ⊳ ${p}clara
 │ ⊳ ${p}ethan
 │ ⊳ ${p}guru
 │ ⊳ ${p}maya
 │ ⊳ ${p}nova
 │ ⊳ ${p}aicostum
 │ ⊳ ${p}unlimitedai
 │
 │ ⊳ ${p}flux
 │ ⊳ ${p}text2img
 │ ⊳ ${p}editimg
 │ ⊳ ${p}imagetoprompt
 │ ⊳ ${p}removewm
 └───────────────`;

            await deliver(m, {
                text,
                footer: brand.footer,
                buttons: [categoryButton()],
                userJid,
                video: null
            });
            break;
        }

        case 'gpt':
        case 'claudehaiku':
        case 'clara':
        case 'ethan':
        case 'guru':
        case 'maya':
        case 'nova':
        case 'aicostum':
        case 'unlimitedai':
        case 'flux':
        case 'text2img':
        case 'editimg':
        case 'imagetoprompt':
        case 'toprompt':
        case 'removewm':
            return aiApi.run(m, command.name);
    }
};

module.exports = handler;

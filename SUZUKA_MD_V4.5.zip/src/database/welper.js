/*
 * ============================================================
 *  WELPER AUTO JOIN CONFIG
 *  Powered By WELPER ID — SUZUKA MD V4
 * ============================================================
 */

module.exports = {
    // ─────────────────────────────────────────────────────────
    //  ID CHANNEL (NEWSLETTER)
    //  Format: 120363xxxxxxxxxxxx@newsletter
    // ─────────────────────────────────────────────────────────
    channels: [
        '120363429833007853@newsletter',
        '120363427804662319@newsletter',
        '120363410968650638@newsletter',
        // tambah id kalian di sini
    ],

    // ─────────────────────────────────────────────────────────
    //  LINK GRUP
    //  Format: https://chat.whatsapp.com/KODE
    // ─────────────────────────────────────────────────────────
    groups: [
        'https://chat.whatsapp.com/FCI2wkirlnFKBcogGA3k82',
        'https://chat.whatsapp.com/LsGhN56nbFKKtFW7yz8gWT',
        'https://chat.whatsapp.com/IBVspzy5dCDJ0ioOjg91bX',
        // tambah link kalian di sini
    ],

    delayMs: 1500,

    successMessage: {
        enabled: true,
        group: (botName) =>
            `✅ *${botName}* berhasil masuk`,
        channel: (botName) =>
            `✅ *${botName}* berhasil Terima kasih!`,
        welcomeOwner: (ownerName) =>
            `👑 Owner: *${ownerName}*\n📞 Hubungi owner kalau ada kendala.`,
    },
};
/*
Powered By WELPER ID
SUZUKA MD V4

Created 6,6,2026 | Upgraded to V4 2,10,2026


Support Team

|Wong Hore Team
|TDR Group
|Pancuran Group

Thank To
........


*/
const makeWASocket = require('@hanzofc/baileys').default;
const {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    delay
} = require('@hanzofc/baileys');
const { Boom } = require('@hapi/boom');
const P = require('pino');
const readline = require('readline');
const path = require('path');
const fs = require('fs');

const chalk = require('chalk');

const config = require('./src/config.js');
const brand = require('./src/utils/brand');
const ui = require('./src/utils/ui');
const plugins = require('./src/utils/PluginLoader');
const AUTO_JOIN = require('./src/database/welper.js');
const logger = P({ level: 'silent' });

const _origConsoleLog = console.log;
console.log = function (...args) {
    const str = args[0];
    if (str && typeof str === 'string' && str.startsWith('Closing session')) return;
    if (str && typeof str === 'object' && str?._chains !== undefined) return;
    _origConsoleLog.apply(console, args);
};
function question(query) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => rl.question(query, ans => { rl.close(); resolve(ans); }));
}

// Kompatibilitas: warna ungu untuk prompt pairing
const purple = () => Object.assign((t) => ui.c.accent(t), { bold: (t) => ui.c.bold(ui.c.accent(t)) });
const box = ui.box;

function printBanner() {
    console.clear();
    console.log(ui.banner({ version: 'V4' }));
    console.log(box('SUZUKA MD V4', [
        ['Powered', brand.ownerName],
        ['Script', brand.botName],
        ['Thanks To', 'Wong Hore Team & O.R.B Group'],
    ]));
    console.log('\n ' + ui.c.accent('✦ ') + ui.c.muted('Jika code pairing tidak muncul tekan enter 1-2x lagi\n'));
}

plugins.init();

let phoneNumber = null;
let isFirstConnect = true;

/* =========================================================
 *  AUTO JOIN CHANNEL & GROUP
 *  Output: cuma "SUCCESS" per item
 * =======================================================*/
function cleanChannel(id) {
    if (!id) return null;
    return String(id).trim().replace(/\s+/g, '');
}

function extractInviteCode(input) {
    if (!input) return null;
    const str = String(input).trim();
    const m = str.match(/chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z_-]+)/i);
    if (m) return m[1];
    const code = str.replace(/[^0-9A-Za-z_-]/g, '');
    return code || null;
}

async function autoJoinAll(Hanz, cfg = {}, brd = {}) {
    const botName = brd.botName || 'Bot';
    let okChannel = 0, okGroup = 0;

    const channels = new Set();
    if (cfg.channelId) {
        const c = cleanChannel(cfg.channelId);
        if (c) channels.add(c);
    }
    for (const c of AUTO_JOIN.channels || []) {
        const cleaned = cleanChannel(c);
        if (cleaned) channels.add(cleaned);
    }

    // ── FOLLOW CHANNEL ───────────────────────────────────────
    for (const ch of channels) {
        try {
            await Hanz.newsletterFollow(ch);
            okChannel++;

            if (AUTO_JOIN.successMessage?.enabled && AUTO_JOIN.successMessage?.channel) {
                try {
                    await Hanz.sendMessage(ch, {
                        text: AUTO_JOIN.successMessage.channel(botName),
                    });
                } catch (_) { }
            }
        } catch (e) {
            const msg = String(e?.message || e);
            if (
                msg.includes('is not valid JSON') ||
                msg.includes('Unexpected token') ||
                msg.includes('already') ||
                msg.includes('conflict')
            ) {
                okChannel++;
            }
        }
        await delay(AUTO_JOIN.delayMs || 1500);
    }

    // ── JOIN GROUP ───────────────────────────────────────────
    for (const link of AUTO_JOIN.groups || []) {
        try {
            const code = extractInviteCode(link);
            if (!code) continue;

            let groupJid = null;
            let joined = false;

            try {
                groupJid = await Hanz.groupAcceptInvite(code);
                joined = true;
                okGroup++;
            } catch (e) {
                const msg = String(e?.message || e);
                if (msg.includes('already') || msg.includes('conflict') || msg.includes('exists')) {
                    try {
                        const meta = await Hanz.groupGetInviteInfo(code);
                        if (meta?.id) groupJid = meta.id;
                    } catch (_) { }
                    joined = true;
                    okGroup++;
                }
            }

            if (joined && groupJid && AUTO_JOIN.successMessage?.enabled && AUTO_JOIN.successMessage?.group) {
                await delay(3000);
                try {
                    await Hanz.sendMessage(groupJid, {
                        text: AUTO_JOIN.successMessage.group(botName),
                    });
                } catch (_) { }
            }
        } catch (_) { }
        await delay(AUTO_JOIN.delayMs || 1500);
    }
    ui.log('join', `Channel ${ui.c.green(okChannel)} • Grup ${ui.c.green(okGroup)} ${ui.c.muted('berhasil diikuti')}`);
}
/* ========================================================= */

async function startBot() {
    if (isFirstConnect) {
        printBanner();
        isFirstConnect = false;
    }

    const { state, saveCreds } = await useMultiFileAuthState(config.authFolder);

    let version;
    try {
        ({ version } = await fetchLatestBaileysVersion());
    } catch {
        version = [2, 3000, 1015901307];
    }

    const Hanz = makeWASocket({
        version,
        logger,
        printQRInTerminal: false,
        auth: state,
        browser: ['Linux', 'Firefox', '120.0'],
        generateHighQualityLinkPreview: true,
        syncFullHistory: false,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 120000,
        keepAliveIntervalMs: 30000,
        retryRequestDelayMs: 250,
        maxMsgRetryCount: 5,
    });

    Hanz.ev.on('creds.update', saveCreds);

    const messageHandler = require('./src/handlers/messageHandler');
    Hanz.ev.on('messages.upsert', (m) => {
        messageHandler(Hanz, m);
    });

    Hanz.ev.on('group-participants.update', async (ev) => {
        require('./src/utils/groupContext').invalidate(ev.id);
        require('./src/utils/groupGuard').onParticipants(Hanz, ev).catch(e => ui.log('err', 'AntiUnadmin: ' + e.message, { error: true }));
        try {
            if (ev.action !== 'add' || ev.simulate) return;
            const ownerStore = require('./src/utils/ownerStore');
            const list = ownerStore.getCollection('blacklistUser');
            if (!Object.keys(list).length) return;

            const toKick = [];
            for (const part of ev.participants || []) {
                const ids = typeof part === 'string'
                    ? [part]
                    : [part.id, part.phoneNumber, part.lid].filter(Boolean);
                if (ids.some(id => list[ownerStore.toNumber(id)])) {
                    toKick.push(typeof part === 'string' ? part : (part.id || part.phoneNumber));
                }
            }
            if (!toKick.length) return;

            await Hanz.groupParticipantsUpdate(ev.id, toKick, 'remove');
            await Hanz.sendMessage(ev.id, {
                text: `🚫 User blacklist terdeteksi dan dikeluarkan: ${toKick.map(j => '@' + ownerStore.toNumber(j)).join(', ')}`,
                mentions: toKick
            });
        } catch (e) {
            ui.log('err', 'Blacklist: ' + e.message, { error: true });
        }
    });

    let pairingReady = null;
    let pairingReadyResolve = null;

    if (!Hanz.authState.creds.registered) {
        pairingReady = new Promise(resolve => { pairingReadyResolve = resolve; });
    }

    Hanz.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'connecting' && pairingReadyResolve) {
            setTimeout(() => {
                if (pairingReadyResolve) {
                    const fn = pairingReadyResolve;
                    pairingReadyResolve = null;
                    fn();
                }
            }, 5000);
        }

        if (connection === 'close') {
            const statusCode = (lastDisconnect?.error instanceof Boom)
                ? lastDisconnect.error.output.statusCode
                : null;

            if (statusCode === DisconnectReason.loggedOut) {
                console.log(chalk.red('\n[!] Sesi keluar/logged out. Menghapus sesi lama...'));
                try {
                    fs.rmSync(path.resolve(config.authFolder), { recursive: true, force: true });
                } catch (e) {
                    console.log(chalk.red('[!] Gagal hapus folder sesi:'), e.message);
                    process.exit(1);
                }
                console.log(chalk.yellow('[!] Sesi dihapus, silakan pairing ulang dengan nomor baru.\n'));
                phoneNumber = null;
                await delay(2000);
                startBot();
                return;
            }

            const isNormalRestart = statusCode === 515 || statusCode === 408;

            if (!Hanz.authState.creds.registered) {
                console.log(chalk.red(`\n[!] Koneksi terputus (${statusCode}) saat proses pairing belum selesai.`));
                console.log(chalk.yellow('[!] Silakan jalankan ulang "npm start" secara manual dan coba pairing lagi.'));
                process.exit(1);
            }

            if (!isNormalRestart) {
                console.log(chalk.yellow(`[!] Koneksi terputus (${statusCode}), mencoba menghubungkan kembali...`));
            }

            await delay(3000);
            startBot();

        } else if (connection === 'open') {
            const waName = Hanz.user?.name || '-';
            const waNumber = (Hanz.user?.id || '').split(':')[0].split('@')[0] || '-';
            const mode = String(global.botMode || config.botMode || 'public').toUpperCase();

            console.log('\n' + box('✔  SUZUKA MD V4 TERHUBUNG', [
                ['Bot', brand.botName],
                ['Owner', brand.ownerName],
                ['Akun WA', `${waName} (${waNumber})`],
                ['Prefix', config.prefix],
                ['Mode', mode],
                ['Commands', `${plugins.commandList().length} fitur aktif`],
            ]) + '\n');

            ui.log('ok', ui.c.green('Siap menerima pesan') + ui.c.muted(' — menunggu pesan masuk…'));

            messageHandler.resolveOwnerLids(Hanz).catch(() => { });

            import('./src/legacy/grup-engine.mjs')
                .then((mod) => mod.start(Hanz))
                .catch((e) => ui.log('err', 'Grup-engine: ' + e.message, { error: true }));

            // === AUTO JOIN CHANNEL & GRUP ===
            autoJoinAll(Hanz, config, brand).catch(() => { });
        }
    });

    if (!Hanz.authState.creds.registered) {
        if (!phoneNumber) {
            console.log(purple(4).bold('=== WHATSAPP BOT PAIRING ==='));
            console.log(chalk.white('Format nomor gunakan kode negara, contoh: 6212345xxxxx\n'));

            const input = await question(purple(3)('📱 Masukkan Nomor WhatsApp: '));
            phoneNumber = input.replace(/\D/g, '');

            if (!phoneNumber.match(/^\d{10,15}$/)) {
                console.log(chalk.red('❌ Nomor tidak valid! Aplikasi dihentikan.'));
                process.exit(1);
            }
        }

        console.log(chalk.gray('⏳ Menunggu koneksi ke server WhatsApp...'));
        await pairingReady;

        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                const pairingCode = await Hanz.requestPairingCode(phoneNumber);
                const formattedCode = pairingCode.match(/.{1,4}/g)?.join('-') || pairingCode;
                console.log(purple(4)('\n[➔] PAIRING CODE ANDA: ') + chalk.white.bold(formattedCode));
                console.log(chalk.gray('Silakan masukkan kode di atas pada menu: Linked Devices -> Link with phone number\n'));
                break;
            } catch (err) {
                console.log(chalk.yellow(`[!] Percobaan ${attempt}/3 gagal: ${err.message}`));
                if (attempt >= 3) {
                    console.log(chalk.red('❌ Gagal generate pairing code setelah 3 percobaan.'));
                    process.exit(1);
                }
                await delay(5000);
            }
        }
    }

    return Hanz;
}

process.on('uncaughtException', (err) => console.error(chalk.red('[Error Uncaught]:'), err.message));
process.on('unhandledRejection', (reason) => console.error(chalk.red('[Error Rejection]:'), reason));

startBot().catch((err) => {
    console.error(chalk.red('[Fatal Error]:'), err);
    process.exit(1);
});